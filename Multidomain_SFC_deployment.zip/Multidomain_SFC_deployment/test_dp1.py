import sys
import networkx as nx
from Multidomain_SFC_deployment.Initialization.utils_plot import *

import networkx as nx

# 辅助函数：计算路径的capacity总和
def calculate_path_capacity(Multilayer_Network, path):
    if not path or len(path) == 1:
        return 0
    return sum(Multilayer_Network.edges[path[i], path[i + 1]]['capacity'] for i in range(len(path) - 1))

# 主函数：寻找最佳节点组合
def find_optimal_nodes_and_paths(Multilayer_Network, start_node, end_node, layers):
    min_total_capacity = float('inf')
    optimal_combination = None

    for n1 in layers[0]:
        for n2 in layers[1]:
            for n3 in layers[2]:
                try:
                    path_l1 = nx.shortest_path(Multilayer_Network, source=start_node, target=n1, weight='capacity')
                    path_l2 = nx.shortest_path(Multilayer_Network, source=n1, target=n2, weight='capacity')
                    path_l3 = nx.shortest_path(Multilayer_Network, source=n2, target=n3, weight='capacity')
                    path_l4 = nx.shortest_path(Multilayer_Network, source=n3, target=end_node, weight='capacity')
                except nx.NetworkXNoPath:
                    continue  # 如果不存在路径，则跳过此组合

                # 计算总capacity
                total_capacity = sum(Multilayer_Network.nodes[n]['capacity'] for n in [n1, n2, n3])
                total_capacity += sum(calculate_path_capacity(Multilayer_Network, path) for path in [path_l1, path_l2, path_l3, path_l4])

                # 检查是否是最佳组合
                if total_capacity < min_total_capacity:
                    min_total_capacity = total_capacity
                    optimal_combination = (n1, n2, n3, path_l1, path_l2, path_l3, path_l4)

    return optimal_combination, min_total_capacity




# 示例用法
Multilayer_Network = nx.Graph()
Multilayer_Network.add_node(101, capacity=1)
Multilayer_Network.add_node(102, capacity=4)
Multilayer_Network.add_node(103, capacity=3)
Multilayer_Network.add_node(104, capacity=2)

Multilayer_Network.add_node(201, capacity=5)
Multilayer_Network.add_node(202, capacity=2)
Multilayer_Network.add_node(203, capacity=2)
Multilayer_Network.add_node(204, capacity=3)

Multilayer_Network.add_node(301, capacity=7)
Multilayer_Network.add_node(302, capacity=1)
Multilayer_Network.add_node(303, capacity=3)
Multilayer_Network.add_node(304, capacity=4)


Multilayer_Network.add_edge(101, 102, capacity=3)
Multilayer_Network.add_edge(102, 103, capacity=4)
Multilayer_Network.add_edge(103, 104, capacity=5)
Multilayer_Network.add_edge(104, 101, capacity=4)
Multilayer_Network.add_edge(101, 103, capacity=4)

Multilayer_Network.add_edge(201, 202, capacity=3)
Multilayer_Network.add_edge(202, 203, capacity=4)
Multilayer_Network.add_edge(203, 204, capacity=5)
Multilayer_Network.add_edge(204, 201, capacity=4)
Multilayer_Network.add_edge(201, 203, capacity=4)

Multilayer_Network.add_edge(301, 302, capacity=3)
Multilayer_Network.add_edge(302, 303, capacity=4)
Multilayer_Network.add_edge(303, 304, capacity=5)
Multilayer_Network.add_edge(304, 301, capacity=4)
Multilayer_Network.add_edge(301, 303, capacity=4)

Multilayer_Network.add_edge(101, 201, capacity=3)
Multilayer_Network.add_edge(102, 202, capacity=4)
Multilayer_Network.add_edge(103, 203, capacity=5)
Multilayer_Network.add_edge(104, 204, capacity=4)

Multilayer_Network.add_edge(201, 301, capacity=3)
Multilayer_Network.add_edge(202, 302, capacity=4)
Multilayer_Network.add_edge(203, 303, capacity=5)
Multilayer_Network.add_edge(204, 304, capacity=4)

#draw_graph(Multilayer_Network)


# 添加其他节点和链路...

start_node = 101
end_node = 304
Layer_Node = [
    [101, 102, 103, 104],
    [201, 202, 203, 204],
    [301, 302, 303, 304]
]

optimal_combination, min_total_capacity = find_optimal_nodes_and_paths(Multilayer_Network, start_node, end_node, Layer_Node)
print(optimal_combination,min_total_capacity)