import networkx as nx

def shortest_path_with_bandwidth_constraint(graph, source, target, bandwidth_constraint):
    # 获取所有路径
    all_paths = list(nx.all_simple_paths(graph, source=source, target=target))

    # 通过 Dijkstra 算法计算最短路径
    shortest_path = nx.shortest_path(graph, source=source, target=target, weight='weight')

    # 初始化最短路径和带宽
    min_delay_path = None
    min_delay = float('inf')

    # 遍历所有路径，找到满足带宽约束的最短路径
    for path in all_paths:
        delay = sum(graph[path[i]][path[i+1]]['weight'] for i in range(len(path)-1))
        if delay < min_delay and check_bandwidth_constraint(graph, path, bandwidth_constraint):
            min_delay = delay
            min_delay_path = path

    return min_delay_path, min_delay

def check_bandwidth_constraint(graph, path, bandwidth_constraint):
    # 检查路径上的每一条边的带宽是否满足约束
    for i in range(len(path)-1):
        if graph[path[i]][path[i+1]]['bandwidth'] < bandwidth_constraint:
            return False
    return True

# 创建一个带权图
G = nx.Graph()

# 添加节点
G.add_nodes_from([1, 2, 3, 4, 5])

# 添加带宽和时延信息的边
G.add_edge(1, 2, weight=10, bandwidth=100)
G.add_edge(2, 3, weight=15, bandwidth=150)
G.add_edge(3, 4, weight=20, bandwidth=200)
G.add_edge(4, 5, weight=25, bandwidth=250)

# 设置源节点和终端节点以及带宽请求
source_node = 1
target_node = 5
bandwidth_request = 180

# 寻找最短路径并满足带宽约束
result_path, result_delay = shortest_path_with_bandwidth_constraint(G, source_node, target_node, bandwidth_request)

# 打印结果
print("最短路径:", result_path)
print("路径时延:", result_delay)
