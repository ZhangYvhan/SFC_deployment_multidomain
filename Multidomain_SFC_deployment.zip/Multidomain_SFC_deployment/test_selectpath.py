import networkx as nx

def find_optimal_solution(graph, node_types, node_capacities, link_capacities):
    selected_nodes = {}
    selected_links = {}

    # 选择节点和找到通信链路
    for node_type in node_types:
        selected_node = find_optimal_node(graph, node_types[node_type], node_capacities)
        selected_nodes[node_type] = selected_node
    print("node_types:",node_types)
    for i in range(len(node_types)-1):
        start_type = node_types[i]
        end_type = node_types[i+1]
        start_node = selected_nodes[start_type]
        end_node = selected_nodes[end_type]

        # 找到通信链路
        path = nx.shortest_path(graph, source=start_node, target=end_node, weight='capacity')
        selected_links[(start_type, end_type)] = path

    # 计算总算力
    total_capacity = calculate_total_capacity(selected_nodes, selected_links, graph)

    return selected_nodes, selected_links, total_capacity

def find_optimal_node(graph, node_type, node_capacities):
    # 在指定类型的节点中选择算力最小的节点
    nodes_of_type = [node for node in graph.nodes if node_types[node] == node_type]
    return min(nodes_of_type, key=lambda x: node_capacities[x])

def calculate_total_capacity(selected_nodes, selected_links, graph):
    # 计算选中的物理节点和链路上的总算力
    total_capacity = 0

    for node_type, node in selected_nodes.items():
        total_capacity += graph.nodes[node]['capacity']

    for (start_type, end_type), path in selected_links.items():
        for i in range(len(path)-1):
            total_capacity += graph.edges[path[i], path[i+1]]['capacity']

    return total_capacity

# 示例用法
G = nx.Graph()

# 添加节点和边以及算力属性
for i in range(1, 4):
    for j in range(1, 6):
        node_name = 'n{0}{1}'.format(i, j)
        G.add_node(node_name, type='type{0}'.format(i), capacity=i * 5 + j)

for i in range(1, 4):
    for j in range(1, 6):
        node_name = 'n{0}{1}'.format(i, j)
        if j < 5:
            G.add_edge(node_name, 'n{0}{1}'.format(i, j+1), capacity=i+j)
        if i < 3:
            G.add_edge(node_name, 'n{0}{1}'.format(i+1, j), capacity=i+j)

# 定义节点类型和算力属性
node_types = {node: G.nodes[node]['type'] for node in G.nodes}
node_capacities = {node: G.nodes[node]['capacity'] for node in G.nodes}
link_capacities = {edge[0]: {edge[1]: G.edges[edge]['capacity'] for edge in G.edges if edge[0] == edge[0]} for edge in G.edges}

print("G.nodes.data():",G.nodes.data())
print("G.edges.data():",G.edges.data())
print("node_types:",node_types)
print("node_capacities:",node_capacities)
print("link_capacities:",link_capacities)

selected_nodes, selected_links, total_capacity = find_optimal_solution(G, node_types, node_capacities, link_capacities)

print("选中的节点:", selected_nodes)
print("选中的链路:", selected_links)
print("总算力:", total_capacity)
