import sys
import networkx as nx
from Multidomain_SFC_deployment.Initialization.utils_plot import *

def DP_generate_alg(Multilayer_Network, start_node, end_node, Layer_Node):
    # 定义一个非常大的初始值，表示无穷大
    INF = sys.maxsize

    # 初始化动态规划数组
    dp = []

    # 递归函数，返回从当前节点到目标节点的最小权重和以及选择的节点和选择的链路
    def min_weight(current_layer, current_node, target_node, remaining_layers):
        # 检查当前状态是否已经计算过
        if (current_layer, current_node, target_node, tuple(remaining_layers)) in dp:
            return dp[(current_layer, current_node, target_node, tuple(remaining_layers))]

        # 如果没有可选的层，返回当前节点到目标节点的权重和选择的节点和链路
        if not remaining_layers:
            return Multilayer_Network[current_node][target_node]['weight'], [current_node], [(current_node, target_node)]

        # 初始化最小权重和
        min_weight_value = INF
        # 初始化选择的节点列表
        selected_nodes = []
        # 初始化选择的链路列表
        selected_links = []

        # 遍历剩余层中的每一层，找到最小权重和和选择的节点和链路
        for next_layer in remaining_layers:
            for next_node in next_layer:
                # 计算当前节点到下一层节点的权重
                current_weight = Multilayer_Network[current_node][next_node]['capacity']
                # 递归计算下一层节点到目标节点的最小权重和
                remaining_layers_next = [layer for layer in remaining_layers if layer != next_layer]
                next_weight, next_nodes, next_links = min_weight(next_layer, next_node, target_node, remaining_layers_next)

                # 更新最小权重和
                if current_weight + next_weight < min_weight_value:
                    min_weight_value = current_weight + next_weight
                    # 更新选择的节点列表
                    selected_nodes = [current_node] + next_nodes
                    # 更新选择的链路列表
                    selected_links = [(current_node, next_node)] + next_links

        # 缓存计算结果
        dp[(current_layer, current_node, target_node, tuple(remaining_layers))] = min_weight_value, selected_nodes, selected_links

        return min_weight_value, selected_nodes, selected_links

    # 初始化最小总权重和选择的节点和链路
    min_total_weight, min_node_path, min_link_path = INF, [], []

    # 遍历每一层的节点，选择使得总权重最小的节点
    for node1 in Layer_Node[0]:
        for node2 in Layer_Node[1]:
            for node3 in Layer_Node[2]:
                # 计算每一种选择的总权重和选择的节点和链路
                total_weight, nodes, links = min_weight(Layer_Node[0], start_node, node1, [Layer_Node[1]]) + \
                                             min_weight(Layer_Node[0], node1, node2, [Layer_Node[1]]) + \
                                             min_weight(Layer_Node[1], node2, node3, [Layer_Node[2]]) + \
                                             min_weight(Layer_Node[2], node3, end_node, [])

                # 更新最小总权重和选择的节点和链路
                if total_weight < min_total_weight:
                    min_total_weight = total_weight
                    min_node_path = nodes
                    min_link_path = links

    return min_node_path, min_total_weight, min_link_path

# 示例用法
Multilayer_Network = nx.Graph()
Multilayer_Network.add_node(101, capacity=1)
Multilayer_Network.add_node(102, capacity=4)
Multilayer_Network.add_node(103, capacity=3)
Multilayer_Network.add_node(104, capacity=2)

Multilayer_Network.add_node(201, capacity=1)
Multilayer_Network.add_node(202, capacity=2)
Multilayer_Network.add_node(203, capacity=2)
Multilayer_Network.add_node(204, capacity=3)

Multilayer_Network.add_node(301, capacity=2)
Multilayer_Network.add_node(302, capacity=1)
Multilayer_Network.add_node(303, capacity=3)
Multilayer_Network.add_node(304, capacity=1)


Multilayer_Network.add_edge(101, 102, capacity=3)
Multilayer_Network.add_edge(102, 103, capacity=4)
Multilayer_Network.add_edge(103, 104, capacity=5)
Multilayer_Network.add_edge(104, 101, capacity=4)
Multilayer_Network.add_edge(101, 103, capacity=4)

Multilayer_Network.add_edge(201, 202, capacity=3)
Multilayer_Network.add_edge(202, 203, capacity=4)
Multilayer_Network.add_edge(203, 204, capacity=5)
Multilayer_Network.add_edge(204, 201, capacity=4)
Multilayer_Network.add_edge(201, 203, capacity=4)

Multilayer_Network.add_edge(301, 302, capacity=3)
Multilayer_Network.add_edge(302, 303, capacity=4)
Multilayer_Network.add_edge(303, 304, capacity=5)
Multilayer_Network.add_edge(304, 301, capacity=4)
Multilayer_Network.add_edge(301, 303, capacity=4)

Multilayer_Network.add_edge(101, 201, capacity=3)
Multilayer_Network.add_edge(102, 202, capacity=4)
Multilayer_Network.add_edge(103, 203, capacity=5)
Multilayer_Network.add_edge(104, 204, capacity=4)

Multilayer_Network.add_edge(201, 301, capacity=3)
Multilayer_Network.add_edge(202, 302, capacity=4)
Multilayer_Network.add_edge(203, 303, capacity=5)
Multilayer_Network.add_edge(204, 304, capacity=4)

#draw_graph(Multilayer_Network)


# 添加其他节点和链路...

start_node = 101
end_node = 304
Layer_Node = [
    [101, 102, 103, 104],
    [201, 202, 203, 204],
    [301, 302, 303, 304]
]

min_node_path, min_total_capacity = DP_generate_alg(Multilayer_Network, start_node, end_node, Layer_Node)

print("最小总算力节点路径:", min_node_path)
print("最小总算力:", min_total_capacity)
