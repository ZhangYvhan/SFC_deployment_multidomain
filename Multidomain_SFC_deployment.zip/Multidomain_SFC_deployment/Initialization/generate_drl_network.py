#BT Europe
#USA carrier backbone network  重点跑这个代码
#GEANT pan-European network
import matplotlib.pyplot as plt
import networkx as nx
import random
import numpy as np
import argparse
import pandas as pd
#from utils import draw_graph
from Global import *
from utils_plot import draw_graph

def gml_reader(seed, inputfile, outputfile):
    random.seed(seed)
    file = inputfile
    #从后缀名为gml的文件中读取信息
    if not file.endswith(".gml"):
        raise ValueError("{} is not a GraphML file".format(file))
    #把内容保存在network中
    network = nx.read_gml(file)
    #print(network)
    #print(network.nodes['node1']['domain'])
    #print(network.edges[('node1', 'node2')]['type'])
    cpu = (NODE_C_L, NODE_C_H)
    memory = (NODE_M_L, NODE_M_H)
    storage = (NODE_S_L, NODE_S_H)
    process_d = (NODE_PD_L, NODE_PD_H)
    bandwidth = (LINK_B_L, LINK_B_H)
    trans_d = (LINK_TD_L, LINK_TD_H)
    cpu_cost = (NODE_CCOST_L, NODE_CCOST_H)
    mem_cost = (NODE_MCOST_L, NODE_MCOST_H)
    sto_cost = (NODE_SCOST_L, NODE_SCOST_H)
    link_cost = (LINK_COST_L, LINK_COST_H)
    # TODO assume undirected graph
    #创建一个图
    newnetwork = nx.Graph()
    #字典
    mapping = dict()

    #节点属性
    for num, node in enumerate(network.nodes()):
        #每个节点对应一个标号
        mapping[node] = num+1
        newnetwork.add_node(num+1, cpu=random.randint(*cpu),memory=random.randint(*memory),storage=random.randint(*storage),
                            process_d=float(random.randint(*process_d)/1000), domain = network.nodes[node]['domain'],
                            software = random.sample(SOFTWARES,2), cpu_cost = random.randint(*cpu_cost), mem_cost = random.randint(*mem_cost), compute_power = 0)
    #边的属性
    #print(network.edges())
    for num,e in enumerate(network.edges()):
        #print(network.edges[e]['type'])
        num = num+1
        if num in [12, 13, 15, 16, 17, 25, 32, 34, 41]:
            newnetwork.add_edge(mapping[e[0]], mapping[e[1]], bandwidth=random.randint(*bandwidth),
                                trans_d=random.randint(*trans_d)*2, type = network.edges[e]['type'], length = int(5),
                                number = int(1), link_cost = random.randint(*link_cost)*5)
        else:
            newnetwork.add_edge(mapping[e[0]], mapping[e[1]], bandwidth=random.randint(*bandwidth),
                                trans_d=random.randint(*trans_d), type = network.edges[e]['type'], length = int(1),
                                number = int(1), link_cost = random.randint(*link_cost))
            #print(network.edges[e]['type'])
    nx.write_gpickle(newnetwork, outputfile)
    return newnetwork


def gml_reader_small_network(seed, inputfile, outputfile):
    random.seed(seed)
    file = inputfile
    # 从后缀名为gml的文件中读取信息
    if not file.endswith(".gml"):
        raise ValueError("{} is not a GraphML file".format(file))
    # 把内容保存在network中
    network = nx.read_gml(file)
    # print(network)
    # print(network.nodes['node1']['domain'])
    # print(network.edges[('node1', 'node2')]['type'])
    #节点上的属性

    cpu = (NODE_C_L, NODE_C_H)
    memory = (NODE_M_L, NODE_M_H)
    storage = (NODE_S_L, NODE_S_H)
    process_d = (NODE_PD_L, NODE_PD_H)
    Inta_bandwidth = (Inta_LINK_B_L, Inta_LINK_B_H)
    Inte_bandwidth = (Inte_LINK_B_L, Inte_LINK_B_H)
    Inta_trans_d = (Inta_LINK_TD_L, Inta_LINK_TD_H)
    Inte_trans_d = (Inte_LINK_TD_L, Inte_LINK_TD_H)
    cpu_cost = (NODE_CCOST_L, NODE_CCOST_H)
    mem_cost = (NODE_MCOST_L, NODE_MCOST_H)
    sto_cost = (NODE_SCOST_L, NODE_SCOST_H)

    #link_cost = (LINK_COST_L, LINK_COST_H)
    # TODO assume undirected graph
    # 创建一个图
    newnetwork = nx.Graph()
    # 字典
    mapping = dict()

    software_len = len(SOFTWARES)
    # softwares_Vars = {}
    # softwares_num_Vars = {}
    # 节点属性
    for num, node in enumerate(network.nodes()):
        # 每个节点对应一个标号
        mapping[node] = num
        softwares_elements = random.sample(SOFTWARES, 2)
        softwares = [0 for i in range(software_len)]
        for item in softwares_elements:
            softwares[SOFTWARES.index(item)] = 1
        software_nums = [0 for i in range(software_len)]
        for item in softwares_elements:
            software_nums[SOFTWARES.index(item)] = 10
        newnetwork.add_node(num,
                            cpu=random.randint(*cpu),
                            memory=random.randint(*memory),
                            storage=random.randint(*storage),
                            process_d=random.randint(*process_d),
                            domain=network.nodes[node]['domain'],
                            software0=softwares[0],
                            software1=softwares[1],
                            software2=softwares[2],
                            software3=softwares[3],
                            software4=softwares[4],
                            software5=softwares[5],
                            software6=softwares[6],
                            software7=softwares[7],
                            software8=softwares[8],
                            software9=softwares[9],
                            software0_num=software_nums[0],
                            software1_num=software_nums[1],
                            software2_num=software_nums[2],
                            software3_num=software_nums[3],
                            software4_num=software_nums[4],
                            software5_num=software_nums[5],
                            software6_num=software_nums[6],
                            software7_num=software_nums[7],
                            software8_num=software_nums[8],
                            software9_num=software_nums[9],
                            cpu_cost=1.0,
                            mem_cost=1.0,
                            sto_cost=1.0,
                            )

    # 边的属性
    for num, e in enumerate(network.edges()):
        # print(network.edges[e]['type'])
        #num = num + 1
        if ((mapping[e[0]] == 6 and mapping[e[1]] == 11) or (mapping[e[0]] == 11 and mapping[e[1]] == 6)
                or (mapping[e[0]] == 6 and mapping[e[1]] == 9) or (mapping[e[0]] == 9 and mapping[e[1]] == 6)
                or (mapping[e[0]] == 7 and mapping[e[1]] == 9) or (mapping[e[0]] == 9 and mapping[e[1]] == 7)
                or (mapping[e[0]] == 8 and mapping[e[1]] == 10) or (mapping[e[0]] == 10 and mapping[e[1]] == 8)
                or (mapping[e[0]] == 9 and mapping[e[1]] == 10) or (mapping[e[0]] == 10 and mapping[e[1]] == 9)
                or (mapping[e[0]] == 12 and mapping[e[1]] == 13) or (mapping[e[0]] == 13 and mapping[e[1]] == 12)
                or (mapping[e[0]] == 16 and mapping[e[1]] == 17) or (mapping[e[0]] == 17 and mapping[e[1]] == 16)
                or (mapping[e[0]] == 16 and mapping[e[1]] == 22) or (mapping[e[0]] == 22 and mapping[e[1]] == 16)
                or (mapping[e[0]] == 21 and mapping[e[1]] == 22) or (mapping[e[0]] == 22 and mapping[e[1]] == 21)):

            trans_d = random.randint(*Inte_trans_d)
            bandwidth = random.randint(*Inte_bandwidth)
            # print(e)
            # print(mapping[e[0]])
            # exit(1)
            newnetwork.add_edge(mapping[e[0]], mapping[e[1]], bandwidth=bandwidth,
                                trans_d=trans_d, type=network.edges[e]['type'])
        else:
            bandwidth = random.randint(*Inta_bandwidth)
            trans_d = random.randint(*Inta_trans_d)
            newnetwork.add_edge(mapping[e[0]], mapping[e[1]], bandwidth=bandwidth,
                                trans_d=trans_d, type=network.edges[e]['type'])
            # print(network.edges[e]['type'])
    nx.write_gpickle(newnetwork, outputfile)
    return newnetwork

def Get_Network_Matrix(network):
    Network_Matrix = []
    num_node = len(network.nodes.data())
    G_node_information = [0 for i in range(num_node)]
    G_link_information = []
    G_total_information = []
    for i in range(num_node):
        list = []
        for j in range(num_node):
            list.append(0)
        G_link_information.append(list)
        G_total_information.append(list)
    # print(G_node_information)
    # print(G_link_information)
    # print(G_total_information)
    for item in network.nodes.data():
        # print(item)
        # exit(0)
        G_node_information[item[0] - 1] = item[1]
        G_total_information[item[0] - 1][item[0] - 1] = item[1]
    for item in network.edges.data():
        G_link_information[item[0] - 1][item[1] - 1] = item[2]
        G_link_information[item[1] - 1][item[0] - 1] = item[2]
        G_total_information[item[0] - 1][item[1] - 1] = item[2]
        G_total_information[item[1] - 1][item[0] - 1] = item[2]
    Network_Matrix.append(G_node_information)
    Network_Matrix.append(G_link_information)
    Network_Matrix.append(G_total_information)
    return Network_Matrix

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int,  nargs='?',
                        default=0)
    # parser.add_argument('--inputfile', type=str, nargs='?',
    #                     const=1,default="E:/zyh/Pythonproject/Model_SFC/multi-Domain_SFC_deployment/network_USA.gml")

    parser.add_argument('--inputfile', type=str, nargs='?',
                        const=1, default="D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Initialization/network_USA_drl_9.gml")
    # parser.add_argument('--outputfile', type=str, nargs='?',
    #                     const=1, default=r'E:/zyh/Pythonproject/Model_SFC/multi-Domain_SFC_deployment/network_USA.gpickle')
    parser.add_argument('--outputfile', type=str, nargs='?',
                        const=1,
                        default=r'D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Initialization/network_USA_drl_9.gpickle')

    args = parser.parse_args()
    #原始

    if args.inputfile.endswith(".gml"):
        G = gml_reader_small_network(args.seed, args.inputfile, args.outputfile)
    else:
        pass
    #G = nx.read_gpickle(r'E:/zyh/Pythonproject/Model_SFC/multi-Domain_SFC_deployment/network_USA.gpickle')
    #resources_node = [{res: max_val for res, max_val in res.items()}
                      #for _, res in G.nodes(data=True)]

    print(len(G.nodes))
    print(len(G.edges))

    # 给节点、链路和整体信息赋初值

    #获得只包含节点的信息
    #获得只包含链路的信息
    #获得既包括节点又包括链路的信息
    Network_Matrix = Get_Network_Matrix(G)
    print(Network_Matrix[0])
    # pos = {0: (0, 0), 1: (0, 1), 2: (1, 0.5),
    #  3: (1,-0.5), 4: (0,-1),
    #  5: (-1,-0.5), 6: (-1,0.5), 7: (0,2),
    #  8: (1,1.5), 9: (2,1),
    #  10: (2,0), 11: (2,-1),
    #  12: (1,-1.5), 13: (0,-2),
    #  14: (-1,-1.5), 15: (-2,-1),
    #  16: (-2,0), 17: (-2,1),
    #  18: (-1,1.5), 19: (0,3), 20: (1,2.5),
    #  21: (2,2), 22: (3,1.5),
    #  23: (3,0.5), 24: (3,-0.5),
    #  25: (3,-1.5), 26: (2,-2),
    #  27: (1,-2.5), 28: (0,-3),
    #  29: (-1,-2.5), 30: (-2,-2),
    #  31: (-3,-1.5), 32: (-3,-0.5),
    #  33: (-3,0.5), 34: (-3,1.5),
    #  35: (-2,2), 36: (-1,2.5), 37: (0,4),
    #  38: (1,3.5), 39: (2,3),
    #  40: (3,2.5), 41: (4,2),
    #  42: (4,1), 43: (4,0),
    #  44: (4,-1), 45: (4,-2),
    #  46: (3,-2.5), 47: (2,-3),
    #  48: (1,-3.5), 49: (0,-4),
    #  50: (-1,-3.5), 51: (-2,-3),
    #  52: (-3,-2.5), 53: (-4,-2),
    #  54: (-4,-1), 55: (-4,0),
    #  56: (-4,1), 57: (-4,2),
    #  58: (-3,2.5), 59: (-2,3),
    #  60: (-1,3.5)}
    # nx.draw(G,pos,with_labels=True)
    draw_graph(G)
    print(G.nodes)
    print(G.edges)
    #draw_graph(G)
    # print(G.nodes)
    # print(G.edges)

