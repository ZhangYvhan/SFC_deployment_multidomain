#生成业务
#泊松到达过程是一种随机过程，常用于模拟某些类型的业务或事件的到达的随机性。
#泊松到达的特征是事件在时间上的随机性 和独立性，要模拟业务的泊松到达，可以使用以下步骤
#泊松到达的速率参数 λ 表示单位时间内事件发生的平均次数，在业务上，可以是每小时、每天或其他适当的时间单位，确保了解业务背景，以确定 λ
#使用随机数生成器生成服务泊松分布的随机数。泊松分布的概率质量函数为，P（X=k）= (e^(-λ)*λ^k)/k!，其中k表示发生的事件数

#使用python的Numpy库可以使用'numpy.random.poisson'函数生成泊松分布的随机数
import random

import numpy as np

#设定随机种子
np.random.seed(0)


λ = 5 #泊松到达的速率
arrivals = np.random.poisson(λ, size=10)#生成1000个随机数
print("arrivals:", arrivals)
print(np.mean(arrivals))


# #模拟时间点：在泊松到达中，事件发生的时间是随机的。根据生成的泊松分布的随机数，模拟事件的到达时间点
# inter_arrival_times = np.random.exponential(20,size=1000)
# arrival_times = np.cumsum(inter_arrival_times) #累积到达的时间点
#
# print(arrival_times)




