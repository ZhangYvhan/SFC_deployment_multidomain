#BT Europe
#USA carrier backbone network  重点跑这个代码
#GEANT pan-European network

import networkx as nx
import random
import numpy as np
import argparse
import pandas as pd
from Multidomain_SFC_deployment.Initialization.utils_plot import draw_graph
from Multidomain_SFC_deployment.Initialization.Global import *

def gml_reader(seed, inputfile, outputfile):
    random.seed(seed)
    file = inputfile
    #从后缀名为gml的文件中读取信息
    if not file.endswith(".gml"):
        raise ValueError("{} is not a GraphML file".format(file))
    #把内容保存在network中
    network = nx.read_gml(file)
    #print(network)
    #print(network.nodes['node1']['domain'])
    #print(network.edges[('node1', 'node2')]['type'])
    cpu = (NODE_C_L, NODE_C_H)
    memory = (NODE_M_L, NODE_M_H)
    storage = (NODE_S_L, NODE_S_H)
    process_d = (NODE_PD_L, NODE_PD_H)
    Inta_bandwidth = (Inta_LINK_B_L, Inta_LINK_B_H)
    Inte_bandwidth = (Inte_LINK_B_L, Inte_LINK_B_H)
    Inta_trans_d = (Inta_LINK_TD_L, Inta_LINK_TD_H)
    Inte_trans_d = (Inte_LINK_TD_L, Inte_LINK_TD_H)
    cpu_cost = (NODE_CCOST_L, NODE_CCOST_H)
    mem_cost = (NODE_MCOST_L, NODE_MCOST_H)
    sto_cost = (NODE_SCOST_L, NODE_SCOST_H)
    # TODO assume undirected graph
    #创建一个图
    newnetwork = nx.Graph()
    #字典
    mapping = dict()

    #节点属性
    for num, node in enumerate(network.nodes()):
        #每个节点对应一个标号
        mapping[node] = num+1
        process_dd = random.randint(*process_d)
        newnetwork.add_node(num+1, cpu=random.randint(*cpu),memory=random.randint(*memory),storage=random.randint(*storage),
                            process_d=process_dd, domain = network.nodes[node]['domain'],
                            software = random.sample(SOFTWARES,2), cpu_cost = random.randint(*cpu_cost),
                            mem_cost = random.randint(*mem_cost), sto_cost = random.randint(*sto_cost), compute_power = 0, penalty_factor = process_dd)
    #边的属性
    #print(network.edges())
    for num,e in enumerate(network.edges()):
        #print(network.edges[e]['type'])
        num = num+1
        if ((mapping[e[0]] == 6 and mapping[e[1]] == 11) or (mapping[e[0]] == 11 and mapping[e[1]] == 6)
            or (mapping[e[0]] == 6 and mapping[e[1]] == 9) or (mapping[e[0]] == 9 and mapping[e[1]] == 6)
            or (mapping[e[0]] == 7 and mapping[e[1]] == 9) or (mapping[e[0]] == 9 and mapping[e[1]] == 7)
            or (mapping[e[0]] == 8 and mapping[e[1]] == 10) or (mapping[e[0]] == 10 and mapping[e[1]] == 8)
            or (mapping[e[0]] == 9 and mapping[e[1]] == 10) or (mapping[e[0]] == 10 and mapping[e[1]] == 9)
            or (mapping[e[0]] == 12 and mapping[e[1]] == 13) or (mapping[e[0]] == 13 and mapping[e[1]] == 12)
            or (mapping[e[0]] == 16 and mapping[e[1]] == 17) or (mapping[e[0]] == 17 and mapping[e[1]] == 16)
            or (mapping[e[0]] == 16 and mapping[e[1]] == 22) or (mapping[e[0]] == 22 and mapping[e[1]] == 16)
            or (mapping[e[0]] == 21 and mapping[e[1]] == 22) or (mapping[e[0]] == 22 and mapping[e[1]] == 21)):

            trans_d = random.randint(*Inte_trans_d)
            bandwidth = random.randint(*Inte_bandwidth)
            # print(e)
            # print(mapping[e[0]])
            #exit(1)
            newnetwork.add_edge(mapping[e[0]], mapping[e[1]], bandwidth=bandwidth, reci_bandwidth=1.0/bandwidth*2, penalty_factor = 1.0/bandwidth*2,
                                trans_d=trans_d, type = network.edges[e]['type'], compute_power = 0)
        else:
            bandwidth = random.randint(*Inta_bandwidth)
            trans_d = random.randint(*Inta_trans_d)
            newnetwork.add_edge(mapping[e[0]], mapping[e[1]], bandwidth=bandwidth, reci_bandwidth=1.0/bandwidth, penalty_factor = 1.0/bandwidth,
                                trans_d=trans_d, type = network.edges[e]['type'], compute_power = 0)
            #print(network.edges[e]['type'])
    nx.write_gpickle(newnetwork, outputfile)
    return newnetwork



def Get_Network_Matrix(network):
    Network_Matrix = []
    num_node = len(network.nodes.data())
    G_node_information = [0 for i in range(num_node)]
    G_link_information = []
    G_total_information = []
    for i in range(num_node):
        list = []
        for j in range(num_node):
            list.append(0)
        G_link_information.append(list)
        G_total_information.append(list)
    # print(G_node_information)
    # print(G_link_information)
    # print(G_total_information)
    for item in network.nodes.data():
        G_node_information[item[0] - 1] = item[1]
        G_total_information[item[0] - 1][item[0] - 1] = item[1]
    for item in network.edges.data():
        G_link_information[item[0] - 1][item[1] - 1] = item[2]
        G_link_information[item[1] - 1][item[0] - 1] = item[2]
        G_total_information[item[0] - 1][item[1] - 1] = item[2]
        G_total_information[item[1] - 1][item[0] - 1] = item[2]
    print("G_node_information:",G_node_information)
    print("G_link_information",G_link_information)
    Network_Matrix.append(G_node_information)
    Network_Matrix.append(G_link_information)
    Network_Matrix.append(G_total_information)
    return Network_Matrix

def Get_Network_Nodes(G, software):
    software_node = []
    for node in G.nodes:
        if software in G.nodes[node]['software']:
            software_node.append(node)
    return software_node



if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int,  nargs='?',
                        default=0)
    # parser.add_argument('--inputfile', type=str, nargs='?',
    #                     const=1,default="E:/zyh/Pythonproject/Model_SFC/multi-Domain_SFC_deployment/network_USA.gml")

    parser.add_argument('--inputfile', type=str, nargs='?',
                        const=1, default="D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Initialization/network_USA_9.gml")
    # parser.add_argument('--outputfile', type=str, nargs='?',
    #                     const=1, default=r'E:/zyh/Pythonproject/Model_SFC/multi-Domain_SFC_deployment/network_USA.gpickle')
    parser.add_argument('--outputfile', type=str, nargs='?',
                        const=1,
                        default=r'D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Initialization/network_USA_9.gpickle')

    args = parser.parse_args()
    #原始

    if args.inputfile.endswith(".gml"):
        G = gml_reader(args.seed, args.inputfile, args.outputfile)
    else:
        pass

    #print(len(G.nodes))
    #print(len(G.edges))

    # 给节点、链路和整体信息赋初值
    # 获得包含某一软件的物理节点
    #print(Get_Network_Nodes(G,'RED'))

    #获得只包含节点的信息
    #获得只包含链路的信息
    #获得既包括节点又包括链路的信息
    Network_Matrix = Get_Network_Matrix(G)
    print(Network_Matrix[0])

    draw_graph(G)
    print(G.nodes)
    print(G.edges)


