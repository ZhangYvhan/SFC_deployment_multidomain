import os
import json
import numpy as np
import networkx as nx

#从json文件中读取数据，以字典形式展现
def read_json(fpath):
    with open(fpath, 'r') as f:
        attrs_dict = json.load(f)
    return attrs_dict

#向json中写入数据
def write_json(dict_data, fpath):
    with open(fpath, 'w',newline='') as f:
        json.dump(dict_data, f)

#把图G的节点和连线
def draw_graph(G, width=1, show=True, save_path=None):
    import matplotlib.pyplot as plt
    pos = nx.spring_layout(G,seed=0)
    plt.figure(figsize=(12, 8), dpi=200)
    size = 30
    edge_colors = "grey"

    options = {
        'pos': pos,
        "node_color": 'blue',
        "node_size": size,
        #"line_color": "grey",
        "linewidths": 0,
        "width": width,
        'with_labels': True,
        "font_size":10,
        "font_color":"black",
        "cmap": plt.cm.brg,
        'edge_color': edge_colors,
        'edge_cmap': plt.cm.Blues, 
        'alpha': 0.5,
        #
    }
    # 节点的属性
    #node_labels = nx.get_node_attributes(G, "cpu")
    #print(node_labels)
    #边属性
    edge_labels = nx.get_edge_attributes(G,"latency")
    #print(edge_labels)
    #画出整个图

    nx.draw(G,**options)
    #nx.draw_networkx_labels(G, pos, labels=node_labels,)
    nx.draw_networkx_labels(G, pos)
    #nx.draw_networkx_edge_labels(G, pos, labels=edge_labels,)

    if show:
        plt.show()
    if save_path is not None:
        plt.savefig(save_path)

if __name__ == '__main__':
    pass