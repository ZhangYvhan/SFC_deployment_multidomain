#Unified network parameter
#让network_USA_drl_*.gpickle中的参数和network_USA_*.gpickle中的参数保持一致

#node: cpu, memory, storage, process_d, software*, software*_num, cpu_cost, mem_cost, sto_cost

#link: bandwidth, trans_d

import networkx as nx
from Global import SOFTWARES

# 加载两个gpickle文件
source_graph_gpickle_path = 'D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Initialization/network_USA_9.gpickle'
target_graph_gpickle_path = 'D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Initialization/network_USA_drl_9.gpickle'
updated_target_graph = 'updated_network_USA_drl_9.gpickle'

source_graph = nx.read_gpickle(source_graph_gpickle_path)
target_graph = nx.read_gpickle(target_graph_gpickle_path)

software_len = len(SOFTWARES)
# 遍历源图的节点，复制特定属性到目标图
for node_id, attributes in source_graph.nodes(data=True):
    # print(node_id)
    # print(node_id,attributes)
    # exit(1)

    if target_graph.has_node(node_id-1) and 'cpu' in attributes:
        # 将源图中节点的cpu属性值赋给目标图中对应节点的cpu属性
        target_graph.nodes[node_id-1]['cpu'] = attributes['cpu']
        target_graph.nodes[node_id - 1]['memory'] = attributes['memory']
        target_graph.nodes[node_id - 1]['storage'] = attributes['storage']
        target_graph.nodes[node_id - 1]['process_d'] = attributes['process_d']

        target_graph.nodes[node_id - 1]['cpu_cost'] = float(1.0)
        target_graph.nodes[node_id - 1]['mem_cost'] = 1.0
        target_graph.nodes[node_id - 1]['sto_cost'] = 1.0

        softwares_elements = attributes['software']

        softwares = [0 for i in range(software_len)]
        for item in softwares_elements:
            softwares[SOFTWARES.index(item)] = 1
        software_nums = [0 for i in range(software_len)]
        for item in softwares_elements:
            software_nums[SOFTWARES.index(item)] = 10

        target_graph.nodes[node_id - 1]['software0'] = softwares[0]
        target_graph.nodes[node_id - 1]['software1'] = softwares[1]
        target_graph.nodes[node_id - 1]['software2'] = softwares[2]
        target_graph.nodes[node_id - 1]['software3'] = softwares[3]
        target_graph.nodes[node_id - 1]['software4'] = softwares[4]
        target_graph.nodes[node_id - 1]['software5'] = softwares[5]
        target_graph.nodes[node_id - 1]['software6'] = softwares[6]
        target_graph.nodes[node_id - 1]['software7'] = softwares[7]
        target_graph.nodes[node_id - 1]['software8'] = softwares[8]
        target_graph.nodes[node_id - 1]['software9'] = softwares[9]

        target_graph.nodes[node_id - 1]['software0_num'] = software_nums[0]
        target_graph.nodes[node_id - 1]['software1_num'] = software_nums[1]
        target_graph.nodes[node_id - 1]['software2_num'] = software_nums[2]
        target_graph.nodes[node_id - 1]['software3_num'] = software_nums[3]
        target_graph.nodes[node_id - 1]['software4_num'] = software_nums[4]
        target_graph.nodes[node_id - 1]['software5_num'] = software_nums[5]
        target_graph.nodes[node_id - 1]['software6_num'] = software_nums[6]
        target_graph.nodes[node_id - 1]['software7_num'] = software_nums[7]
        target_graph.nodes[node_id - 1]['software8_num'] = software_nums[8]
        target_graph.nodes[node_id - 1]['software9_num'] = software_nums[9]

#遍历图中的边，复制特定属性到目标图
for u, v, attributes in source_graph.edges(data=True):
    #print("u,v:",u,v)
    if target_graph.has_edge(u-1, v-1) and 'bandwidth' in attributes:
        # 将源图中边的bandwidth属性值赋给目标图中对应边的bandwidth属性
        target_graph[u-1][v-1]['bandwidth'] = attributes['bandwidth']
        target_graph[u - 1][v - 1]['trans_d'] = attributes['trans_d']

# 保存更新后的目标图
nx.write_gpickle(target_graph, updated_target_graph)


G2_path = "updated_network_USA_drl_8.gpickle"


G2= nx.read_gpickle(G2_path)

# 打印节点信息


print("\nG2节点信息:")
for node_id, attributes in G2.nodes(data=True):
    attributes_str = ', '.join(f"{key}: {value}" for key, value in attributes.items())
    attributes_str_type = ', '.join(f"{type(value)}" for key, value in attributes.items())
    print(f"节点ID: {node_id}, 属性: {{ {attributes_str} }},类型：{attributes_str_type}")

# 打印边信息

print("\nG2边信息:")
for u, v, attributes in G2.edges(data=True):
    attributes_str = ', '.join(f"{key}: {value}" for key, value in attributes.items())
    print(f"边: ({u}, {v}), 属性: {{ {attributes_str} }}")
