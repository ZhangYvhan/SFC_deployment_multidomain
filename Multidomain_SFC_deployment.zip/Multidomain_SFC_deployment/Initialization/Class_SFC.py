#SFC 类
from Multidomain_SFC_deployment.Initialization.Global import *
import random

class ServiceFunctionChain:
    def __init__(self, start_point, end_point, bandwidth_demand, latency_demand, lifecycle, sfc_len):
        self.arrival = -1  # 业务功能链的到达时间
        self.start_point = start_point  # 起点
        self.end_point = end_point  # 终点
        self.bandwidth_demand = bandwidth_demand  # 带宽需求
        self.latency_demand = latency_demand  # 时延需求
        self.lifecycle = lifecycle  # 生命周期
        self.sfc_len = sfc_len  # sfc的长度
        self.vnf_list = []  # 存储VNF的列表

        self.deploy_nodes = []  # 用于保存业务功能链部署的节点的位置
        self.deploy_edges = []  # 用于保存业务功能链部署的链路的位置
        self.migrate_nodes = []  # 软件从哪个物理节点迁移过来

        self.deploy_nodes_delay = []  # 每个vnf部署的时延
        self.deploy_edges_delay = []  # 每个链路使用的时延
        self.deploy_nodes_cost = []  # 每个vnf部署的成本
        self.deploy_nodes_sto_cost = [] #每个SFC的迁移成本
        self.migrate_cost = []  # 用于保存业务功能链软件迁移成本

        self.deploy_total_delay = 0  # 用于保存业务功能链被成功部署时的端到端时延
        self.deploy_total_cost = 0  # 用于保存业务功能链被成功部署时的资源使用成本
        self.deploy_sto_cost = 0 # 使用的sto的成本的总和
        self.deploy_total_vnf_delay = 0 # sfc的处理时延
        self.deploy_total_link_delay = 0 # sfc的链路时延

        self.migrate_total_cost = 0  # 迁移的总成本
        self.migrate_total_number = 0  # 迁移的总数量




    def add_vnf(self, vnf_name):
        vnf = vnf_name
        self.vnf_list.append(vnf)

    def return_list(self):
        chain_info = []
        chain_info.append(self.arrival)
        chain_info.append(self.start_point)
        chain_info.append(self.end_point)
        chain_info.append(self.bandwidth_demand)
        chain_info.append(self.latency_demand)
        chain_info.append(self.lifecycle)
        chain_info.append(self.vnf_list)

        chain_info.append(self.deploy_nodes)
        chain_info.append(self.deploy_edges)
        chain_info.append(self.migrate_nodes)

        chain_info.append(self.deploy_nodes_delay)
        chain_info.append(self.deploy_edges_delay)
        chain_info.append(self.deploy_nodes_cost)
        chain_info.append(self.deploy_nodes_sto_cost)
        chain_info.append(self.migrate_cost)

        chain_info.append(self.deploy_total_delay)
        chain_info.append(self.deploy_total_vnf_delay)
        chain_info.append(self.deploy_total_link_delay)
        chain_info.append(self.deploy_total_cost)
        chain_info.append(self.deploy_sto_cost)
        chain_info.append(self.migrate_total_cost)
        chain_info.append(self.migrate_total_number)

        return chain_info
    def return_info(self):
        chain_info = f"业务功能链：\n"
        chain_info += f"业务功能链到达时间: {self.arrival}\n"
        chain_info += f"起点: {self.start_point}\n"
        chain_info += f"终点: {self.end_point}\n"
        chain_info += f"带宽需求: {self.bandwidth_demand} Mbps\n"
        chain_info += f"时延需求: {self.latency_demand} ms\n"
        chain_info += f"生命周期: {self.lifecycle} 周期\n"
        chain_info += f"VNF列表: {self.vnf_list}\n"

        chain_info += f"业务功能链部署的节点的位置: {self.deploy_nodes}\n"
        chain_info += f"业务功能链部署的链路的位置: {self.deploy_edges}\n"
        chain_info += f"业务功能链中的软件从哪里迁移过来的: {self.migrate_nodes}\n"

        chain_info += f"业务功能链每个VNF放置后的节点时延: {self.deploy_nodes_delay}\n"
        chain_info += f"业务功能链每两个相邻VNF之间使用的链路时延: {self.deploy_edges_delay}\n"
        chain_info += f"业务功能链每个VNF放置后的节点的资源使用成本: {self.deploy_nodes_cost}\n"
        chain_info += f"业务功能链部署时使用的存储资源成本：{self.deploy_nodes_sto_cost}\n"
        chain_info += f"业务功能链每个VNF放置后需要被迁移的软件的成本: {self.migrate_cost}\n"

        chain_info += f"业务功能链部署的总通信时延，包括节点处理时延和链路传输时延: {self.deploy_total_delay}\n"
        chain_info += f"业务功能链上的VNF的处理时延：{self.deploy_total_vnf_delay}\n"
        chain_info += f"业务功能链上的link时延：{self.deploy_total_link_delay}\n"
        chain_info += f"业务功能链部署的总通信成本，包括节点资源的使用成本: {self.deploy_total_cost}\n"

        chain_info += f"业务功能链使用的总存储资源成本，包括所有的sto资源使用成本: {self.deploy_sto_cost}\n"
        chain_info += f"业务功能链每个VNF放置后所有需要迁移的软件成本的和: {self.migrate_total_cost}\n"
        chain_info += f"业务功能链每个VNF放置后所有需要迁移的软件次数的和: {self.migrate_total_number}\n"
        # for vnf in self.vnf_list:
        #     chain_info += f"- VNF名称: {vnf[0]}, 属性: {vnf[1]}\n"
        return chain_info

def Generate_SFCs_Info(inputfile, sfc_num):
    #random.seed(SEED)
    sfc_len = [SFC_LEN_L, SFC_LEN_H]
    vnfs = VNFS
    #sfc_num = [SFC_NUM_L, SFC_NUM_H]
    bandwidth = [R_B_L, R_B_H]
    latency = [D_L, D_H]
    lifecycle = [TTL_L, TTL_H]
    DOMAIN_NODE = Get_Domain_Nodes(inputfile)

    SFCs_Info = []
    for i in range(sfc_num):
        start_domain, end_domain = random.sample([1, 2, 3], 2)
        start_point = random.choice(DOMAIN_NODE[start_domain-1])
        end_point = random.choice(DOMAIN_NODE[end_domain-1])
        bandwidth_demand = random.randint(*bandwidth)
        latency_demand = random.randint(*latency)
        lifecycle_demand = random.randint(*lifecycle)
        vnfs_list = random.sample(vnfs, random.randint(*sfc_len))
        SFC_Info = ServiceFunctionChain(start_point, end_point, bandwidth_demand, latency_demand, lifecycle_demand,sfc_len)
        SFC_Info.vnf_list = vnfs_list
        SFCs_Info.append(SFC_Info)
    return SFCs_Info

# 创建一个业务功能链示例
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--inputfile', type=str, nargs='?',
                        const=1, default="D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Initialization/network_USA.gml")
    args = parser.parse_args()
    SFCs_Info = Generate_SFCs_Info(args.inputfile,3)
    for item in SFCs_Info:
        print(item.return_info())
        print(item.bandwidth_demand)
