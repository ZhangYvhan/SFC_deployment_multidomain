Creator  "sndlib.ext.generators.gml.ProblemGmlGenerator USA carrier backbone network"
Version  "1.0"

graph [
  label     "multi-domain-USA carrier backbone network"
  name      "multi-domain-USA carrier backbone network"
  directed  1


  node [
    id     1
    label  "node1"
    domain 1
  ]
  node [
    id     2
    label  "node2"
    domain 1
  ]
  node [
    id     3
    label  "node3"
    domain 1
  ]
  node [
    id     4
    label  "node4"
    domain 1
  ]
  node [
    id     5
    label  "node5"
    domain 1
  ]
  node [
    id     6
    label  "node6"
    domain 1
  ]
  node [
    id     7
    label  "node7"
    domain 1
  ]
  node [
    id     8
    label  "node8"
    domain 1
  ]

  node [
    id     9
    label  "node9"
    domain 2
  ]
  node [
    id     10
    label  "node10"
    domain 3
  ]

  node [
    id     11
    label  "node11"
    domain 2
  ]
  node [
    id     12
    label  "node12"
    domain 2
  ]

  node [
    id     13
    label  "node13"
    domain 3
  ]

  node [
    id     14
    label  "node14"
    domain 3
  ]

  node [
    id     15
    label  "node15"
    domain 2
  ]
  node [
    id     16
    label  "node16"
    domain 2
  ]
  node [
    id     17
    label  "node17"
    domain 3
  ]
  node [
    id     18
    label  "node18"
    domain 3
  ]

  node [
    id     19
    label  "node19"
    domain 2
  ]
  node [
    id     20
    label  "node20"
    domain 2
  ]

  node [
    id     21
    label  "node21"
    domain 2
  ]
  node [
    id     22
    label  "node22"
    domain 3
  ]
  node [
    id     23
    label  "node23"
    domain 3
  ]

  node [
    id     24
    label  "node24"
    domain 3
  ]

  edge [
    id      1
    source  1
    target  2
    type    1
  ]
  edge [
    id      2
    source  1
    target  6
    type    1
  ]
  edge [
    id      3
    source  2
    target  3
    type    1
  ]
  edge [
    id      4
    source  2
    target  6
    type    1
  ]
  edge [
    id      5
    source  3
    target  4
    type    1
  ]
  edge [
    id      6
    source  3
    target  5
    type    1
  ]
  edge [
    id      7
    source  3
    target  7
    type    1
  ]
  edge [
    id      8
    source  4
    target  5
    type    1
  ]
   edge [
    id      9
    source  4
    target  7
    type    1
  ]
  edge [
    id      10
    source  5
    target  8
    type    1
  ]
  edge [
    id      11
    source  6
    target  7
    type    1
  ]
  edge [
    id      12
    source  6
    target  9
    type    2
  ]
  edge [
    id      13
    source  6
    target  11
    type    2
  ]
   edge [
    id      14
    source  7
    target  8
    type    1
  ]
  edge [
    id      15
    source  7
    target  9
    type    2
  ]

  edge [
    id      16
    source  8
    target  10
    type    2
  ]
  edge [
    id      17
    source  9
    target  10
    type    2
  ]
  edge [
    id      18
    source  9
    target  11
    type    1
  ]
  edge [
    id      19
    source  9
    target  12
    type    1
  ]
  edge [
    id      20
    source  10
    target  13
    type    1
  ]
  edge [
    id      21
    source  10
    target  14
    type    1
  ]
  edge [
    id      22
    source  11
    target  12
    type    1
  ]
  edge [
    id      23
    source  11
    target  15
    type    1
  ]
  edge [
    id      24
    source  11
    target  19
    type    1
  ]
  edge [
    id      25
    source  12
    target  13
    type    2
  ]
  edge [
    id      26
    source  12
    target  16
    type    1
  ]
  edge [
    id      27
    source  13
    target  14
    type    1
  ]
  edge [
    id      28
    source  13
    target  17
    type    1
  ]
  edge [
    id      29
    source  14
    target  18
    type    1
  ]
  edge [
    id      30
    source  15
    target  20
    type    1
  ]
  edge [
    id      31
    source  15
    target  16
    type    1
  ]
  edge [
    id      32
    source  16
    target  17
    type    2
  ]
  edge [
    id      33
    source  16
    target  21
    type    1
  ]
  edge [
    id      34
    source  16
    target  22
    type    2
  ]
  edge [
    id      35
    source  17
    target  18
    type    1
  ]
  edge [
    id      36
    source  17
    target  22
    type    1
  ]
  edge [
    id      37
    source  17
    target  23
    type    1
  ]
  edge [
    id      38
    source  18
    target  24
    type    1
  ]
  edge [
    id      39
    source  19
    target  20
    type    1
  ]
  edge [
    id      40
    source  20
    target  21
    type    1
  ]

  edge [
    id      41
    source  21
    target  22
    type    2
  ]
  edge [
    id      42
    source  22
    target  23
    type    1
  ]
  edge [
    id      43
    source  23
    target  24
    type    1
  ]
]