import random
import networkx as nx
import argparse
#物理节点资源
#物理节点的计算资源的上下限
NODE_C_L = 200
NODE_C_H = 300

#物理节点的内存资源的上下限
NODE_M_L = 200
NODE_M_H = 300

#物理节点存储资源的上下限
NODE_S_L = 100
NODE_S_H = 200

#节点的处理时延的上下限
NODE_PD_L = 30
NODE_PD_H = 100

#节点上的单位成本需求
NODE_CCOST_L = 1
NODE_CCOST_H = 1
NODE_MCOST_L = 1
NODE_MCOST_H = 1
NODE_SCOST_L = 1
NODE_SCOST_H = 1

#链路资源
#域内链路带宽资源的上下限
Inta_LINK_B_L = 1000
Inta_LINK_B_H = 2000

#域间链路带宽资源的上下限
Inte_LINK_B_L = 2000
Inte_LINK_B_H = 4000

#域内链路的传输时延的上下限
Inta_LINK_TD_L = 1
Inta_LINK_TD_H = 6

#域间链路的传输时延的上下限
Inte_LINK_TD_L = 10
Inte_LINK_TD_H = 20

#业务功能链的请求
#业务功能请求的计算资源的上下限
R_C_L = 5
R_C_H = 10

#业务功能请求的内存资源的上下限
R_M_L = 5
R_M_H = 10

#软件请求的存储资源的上下限
R_S_L = 20
R_S_H = 80

#对链路带宽资源的请求的上下限
R_B_L = 10
R_B_H = 40

#链路上的带宽成本需求
LINK_COST_L = 1
LINK_COST_H = 2

#业务端到端时延的请求的上下限 [200,400], [200,300],[300,400],[400,500]
D_L = 200
D_H = 400



#生命周期的上下限
TTL_L = 10000
TTL_H = 10000

# 业务功能链的长度
SFC_LEN_L = 3
SFC_LEN_H = 3

#业务功能链的数量
SFC_NUM_L = 160
SFC_NUM_H = 160

#时隙的设定
SLOT_NUM_L = 1000
SLOT_NUM_H = 1000

#业务功能链的到达速率
λ = SFC_NUM_L/SLOT_NUM_L


#[0.05, 0.1, 0.15, 0.2]

#随机种子
SEED = 0



#时延和成本加权权重
W1 = 50
W2 = 100

#资源的利用率的上限和下限
UTI_L = 0.2
UTI_H = 0.8

SFCMAP_INTER_NUM = 10

#用来防止分母为0
ϵ = 0.000001

PENALTY_FACTOR = 1.2
#clickos 论文中找VNF和软件资源之间的关系
#VNF的列表[]
#每个VNF对计算、内存资源的需求，对软件的需求
VNFS = ['Firewall',
        'NAT',
        'Load balancer',
        'DPI',
        'Traffic shaper',
        'Tunnel',
        'Multicast',
        'Monitoring',
        'Congestion control',
        'IPv6/IPv4 proxy']
VNFS_INFO = {'Firewall':[["IPFilter"]],
             'NAT':[["Rewriter"]],
             'Load balancer':[["RateSplitter"]],
             'DPI':[["Classifier"]],
             "Traffic shaper":[["BandwidthShaper"]],
             "Tunnel":[["IPEncap"]],
             "Multicast":[["IPMulticastEtherEncap"]],
             'Monitoring':[["IPRateMonitor"]],
             'Congestion control':[["RED"]],
             'IPv6/IPv4 proxy':[["ProtocoTranslator46"]]}
SOFTWARES = ["IPFilter",
             "Rewriter",
             "RateSplitter",
             "Classifier",
             "BandwidthShaper",
             "IPEncap",
             "IPMulticastEtherEncap",
             "IPRateMonitor",
             "RED",
             "ProtocoTranslator46"]



#获得VNF的信息
def Get_VNFs_INFO(cpu, mem, storage_low, storage_high):
    random.seed(SEED)
    vnfs_info = VNFS_INFO
    software_info = Get_Software_Info(storage_low, storage_high)
    #print("**********************")
    #print(software_info)
    for item in vnfs_info:
        #print(item)
        resource_require = []
        resource_require.append(random.randint(*cpu))
        resource_require.append(random.randint(*mem))
        resource_require.append(software_info[VNFS_INFO[item][0][0]])
        vnfs_info[item].append(resource_require)
    #print(vnfs_info)
    return vnfs_info


#获得软件的信息
def Get_Software_Info(storage_low, storage_high):
    SOFTWARES_INFO = {}
    for item in range(len(SOFTWARES)):
        #print(item)
        storage_require_value = random.randint(storage_low, storage_high)
        SOFTWARES_INFO[SOFTWARES[item]] = storage_require_value
    #print(SOFTWARES_INFO)
    return SOFTWARES_INFO

#每个域中的节点,每个域中的节点根据生成网络中的节点而定
def Get_Domain_Nodes(inputfile):
    file = inputfile
    if not file.endswith(".gml"):
        raise ValueError("{} is not a GraphML file".format(file))
    network = nx.read_gml(file)
    DOMAIN_NODE = []
    DOMAIN1 = []
    DOMIAN2 = []
    DOMAIN3 = []
    for num, item in enumerate(network.nodes):
        if network.nodes[item]['domain'] == 1:
            DOMAIN1.append(num+1)
        elif network.nodes[item]['domain'] == 2:
            DOMIAN2.append(num+1)
        elif network.nodes[item]['domain'] == 3:
            DOMAIN3.append(num+1)
    DOMAIN_NODE.append(DOMAIN1)
    DOMAIN_NODE.append(DOMIAN2)
    DOMAIN_NODE.append(DOMAIN3)


    return  DOMAIN_NODE

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--inputfile', type=str, nargs='?',
                        const=1, default="D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Initialization/network_USA.gml")
    args = parser.parse_args()
    DOMAIN_NODE = Get_Domain_Nodes(args.inputfile)
    for item in DOMAIN_NODE:
        print(item)
    # SOFTWARES_INFO = Get_Software_Info(R_S_L, R_S_H)
    # for item in SOFTWARES_INFO:
    #     print(item,":",SOFTWARES_INFO[item])
    cpu = [R_C_L, R_C_H]
    mem = [R_M_L, R_M_H]
    vnfs_info = Get_VNFs_INFO(cpu, mem, R_S_L, R_S_H)
    print(vnfs_info)
    print(len(vnfs_info))




