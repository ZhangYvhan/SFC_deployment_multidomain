#BestFit算法
#BestFit算法在Greedy的算法上进一步改进
#获得可以支持VNF运行的物理节点的集合Q，并计算所有物理节点到上一节点的满足带宽需求的链路，如果链路存在，则计算最小时延，链路不存在则将该物理节点从链路中去除
#假设将VNF放置在Q的所有物理节点上，如果节点上有支持VNF的软件资源，则计算将VNF放置在此物理节点上的资源使用成本、处理时延和从上一物理节点到该节点的时延，
# 如果节点上没有支持VNF的软件资源，则将计算VNF放置在此物理节点上的资源使用成本，处理时延和从上一物理节点到该节点的时延，最近软件的迁移成本（软件迁移成本用链路的长度来表示）和软件的资源使用成本
#比较这些数据，哪个比较小就放置在哪个节点上


# %描述算法，实际上也是算法的流程
# %业务功能链的源节点和终端节点在初始时已经确定，分别放在相应的物理节点上
# %对于业务功能链的每个VNF，对于物理节点上有支撑这个VNF运行的软件资源时，判断物理节点上的计算和内存资源是否满足此VNF的运行，对于物理节点上没有支撑这个VNF运行的软件资源时，判断物理节点上的计算、内存和存储资源是否满足此VNF的运行，获得支持VNF运行的物理节点
# %判断物理节点与上一个VNF的放置位置（对于第一个VNF来说，VNF和源节点所在的位置）之间是否存在带宽大于业务请求带宽的路径，如果存在，记录时延最短的路径，否则，将相应物理节点从可行的物理节点中移除
# %假设VNF将放置在每一个可行的物理节点上，如果物理节点上存在支持VNF运行的软件，则计算VNF在此节点上的处理时延，资源使用成本和链路时延，如果物理节点上没有支持VNF运行的软件，则计算VNF在此节点上的处理时延，资源使用成本，链路时延和软件迁移成本，对比VNF在每个物理节点上放置的时延和成本之和，将VNF放置在能使通信性能最优的物理节点上。

import numpy as np
from Multidomain_SFC_deployment.Initialization.Class_SFC import *
from Multidomain_SFC_deployment.Initialization.generate_network import *
from Multidomain_SFC_deployment.Initialization.Global import *
from Multidomain_SFC_deployment.Algorithm.utils import *
import argparse
import copy
import pandas as pd

np.random.seed(SEED)   #随机种子设定，可以通过随机种子的设定来重复实验

parser = argparse.ArgumentParser()
parser.add_argument('--inputfile', type=str, nargs='?',
                        const=1, default="D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Initialization/network_USA_9.gml")
parser.add_argument('--outputfile', type=str, nargs='?',
                        const=1,
                        default=r'D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Initialization/network_USA_9.gpickle')
args = parser.parse_args()  #网络环境的链接
if args.inputfile.endswith(".gml"):
    G_initial = gml_reader(SEED, args.inputfile, args.outputfile) #生成网络拓扑
else:
    pass

G_success = copy.deepcopy(G_initial) #深拷贝网络，使G_success用来表示上一次成功执行的业务功能链之后的网络的状态
G_execute = copy.deepcopy(G_success) #深拷贝网络，使用G_execute表示当前用来执行的网络的状态


poisson_samples = np.random.poisson(lam=λ, size=SLOT_NUM_L)     #获得每个时隙中的业务功能链的数量，可以通过改变业务功能链到达的速率来重复实验

sum = 0
for t in range(SLOT_NUM_L):
    if (t+1)%100 == 0:
        sum+=poisson_samples[t]
        print(sum)
    else:
        sum+=poisson_samples[t]
#exit(1)


#需要将所有请求的业务功能链保存到一个文档中去
Request_total_SFCs = []  #用来保存所有请求的SFC的列表
Accept_SFCs = [] #用来保存所有被成功接收的SFC的列表
Reject_SFCs = [] #用来保存所有被拒绝的SFC的列表

#获得所有VNF需要的信息
cpu = [R_C_L, R_C_H]
mem = [R_M_L, R_M_H]
All_Vnfs_Info = Get_VNFs_INFO(cpu, mem, R_S_L, R_S_H)
#print(All_Vnfs_Info)


for t in range(SLOT_NUM_L):
    sfc_t_nums = poisson_samples[t] #获得当前时隙中的需要部署的业务功能链的数量
    SFCs_Info = Generate_SFCs_Info(args.inputfile, sfc_t_nums) #获得当前时隙中的业务功能链的信息

    print("****************time slot****************",t)

    # 依次部署业务功能链，记录业务功能链部署时的时延，部署的成本，迁移的成本，迁移的次数
    for sfc_num,sfc in enumerate(SFCs_Info): #这个循环中部署请求的业务功能链
        print("##########sfc", sfc_num)
        FLAG = True #业务可以被成功部署
        sfc.arrival = t #给定业务到达的时间
        Request_total_SFCs.append(sfc.return_list()) #添加新到达的SFC
        #print(Request_total_SFCs)

        start = sfc.start_point
        end = sfc.end_point

        b_r = sfc.bandwidth_demand  #业务功能链的带宽请求
        d_r = sfc.latency_demand    #业务功能链的时延需求
        VNF_List = sfc.vnf_list #获取业务功能链每个VNF需要的信息

        # print("开始节点：", start," ","结束节点：", end," ", "带宽请求：", b_r," ", "时延请求：",d_r)
        # print("请求的VNFs：", VNF_List)

        #依次放置vnf,并保存每个VNF所在的位置，所使用的链路
        #记录每个VNF放置时使用的成本
        for idex, vnf in enumerate(VNF_List):
            #获得能满足vnf放置的节点并保存节点和上一个节点连接的链路
            #[['IPFilter'], [39, 35, 74]]
            vnf_request = All_Vnfs_Info[vnf]
            #print(vnf_request)
            #
            if idex == 0:
                vnf_place_node, vnf_communication_link = Bestfit_find_node1(G_initial, G_execute, vnf_request, start, b_r)
                #print("放置vnf的节点的性能",vnf_place_node)

                sfc.deploy_nodes.append(vnf_place_node[0])
                sfc.deploy_edges.append(vnf_communication_link)
                sfc.migrate_nodes.append(vnf_place_node[5])
                sfc.deploy_nodes_cost.append(vnf_place_node[1])
                sfc.deploy_nodes_sto_cost.append(vnf_place_node[6])
                sfc.deploy_nodes_delay.append(vnf_place_node[3])
                sfc.migrate_cost.append(vnf_place_node[2])

                #更新网络资源，包括更新物理节点资源和链路资源
                #物理节点更新
                G_execute.nodes[vnf_place_node[0]]['cpu'] = G_execute.nodes[vnf_place_node[0]]['cpu'] - vnf_request[1][0]
                G_execute.nodes[vnf_place_node[0]]['memory'] = G_execute.nodes[vnf_place_node[0]]['memory'] - vnf_request[1][1]

                if vnf_place_node[5] != 0:
                    G_execute.nodes[vnf_place_node[0]]['software'].append(vnf_request[0][0])
                    G_execute.nodes[vnf_place_node[0]]['storage'] = G_execute.nodes[vnf_place_node[0]]['storage'] - \
                                                                   vnf_request[1][2]

                #物理链路更新
                if vnf_communication_link == None:
                    FLAG = False
                else:
                    for link_index in range(len(vnf_communication_link)-1):
                        G_execute.edges[(vnf_communication_link[link_index],vnf_communication_link[link_index+1])]['bandwidth'] -= b_r




            else:
                vnf_place_node, vnf_communication_link = Bestfit_find_node1(G_initial, G_execute, vnf_request,
                                                                                sfc.deploy_nodes[idex-1], b_r)
                # print("放置vnf的节点的性能", vnf_place_node)
                sfc.deploy_nodes.append(vnf_place_node[0])
                sfc.deploy_edges.append(vnf_communication_link)
                sfc.migrate_nodes.append(vnf_place_node[5])
                sfc.deploy_nodes_cost.append(vnf_place_node[1])
                sfc.deploy_nodes_sto_cost.append(vnf_place_node[6])
                sfc.deploy_nodes_delay.append(vnf_place_node[3])
                sfc.migrate_cost.append(vnf_place_node[2])

                #更新网络资源，包括更新物理节点资源和链路资源
                # 物理节点更新
                G_execute.nodes[vnf_place_node[0]]['cpu'] = G_execute.nodes[vnf_place_node[0]]['cpu'] - vnf_request[1][
                    0]
                G_execute.nodes[vnf_place_node[0]]['memory'] = G_execute.nodes[vnf_place_node[0]]['memory'] - \
                                                               vnf_request[1][1]
                if vnf_place_node[5] != 0:
                    G_execute.nodes[vnf_place_node[0]]['software'].append(vnf_request[0][0])
                    G_execute.nodes[vnf_place_node[0]]['storage'] = G_execute.nodes[vnf_place_node[0]]['storage'] - \
                                                                    vnf_request[1][2]
                # 物理链路更新
                if vnf_communication_link == None:
                    FLAG = False
                else:
                    for link_index in range(len(vnf_communication_link) - 1):
                        G_execute.edges[(vnf_communication_link[link_index], vnf_communication_link[link_index + 1])]['bandwidth'] -= b_r




        sfc.deploy_edges.append(Get_Shortest_delay_path(G_execute, vnf_place_node[0], end, b_r))
        if Get_Shortest_delay_path(G_execute, vnf_place_node[0], end, b_r) == None:
            FLAG = False
        # print("sfc部署使用的物理节点：",sfc.deploy_nodes)
        # print("sfc部署使用的物理链路：",sfc.deploy_edges)
        # print("sfc部署需要迁移的软件：",sfc.migrate_nodes)

        #计算当前这个VNF的时延和成本
        #首先计算时延，当时延满足需求时，则继续计算成本，并将SFC保存到被成功部署的队列中去，更新G_sucess
        #print(FLAG)
        if FLAG==False:
            Reject_SFCs.append(sfc)
            G_execute = copy.deepcopy(G_success)

        else:
            sfc_total_delay = 0
            vnf_process_delay = 0
            link_commu_delay = 0
            for idex, place_node in enumerate(sfc.deploy_nodes):
                #sfc.deploy_nodes_delay.append(G_execute.nodes[sfc.deploy_nodes[idex]]['process_d'])
                #vnf_process_delay += G_execute.nodes[sfc.deploy_nodes[idex]]['process_d']
                vnf_process_delay += sfc.deploy_nodes_delay[idex]
            #print("sfc.deploy_edges:",sfc.deploy_edges)
            for vnf_adjecent_link in sfc.deploy_edges:
                vnf_adjecent_link_delay = 0
                for idex in range(len(vnf_adjecent_link)-1):
                    vnf_adjecent_link_delay += G_execute.edges[(vnf_adjecent_link[idex],vnf_adjecent_link[idex+1])]['trans_d']
                sfc.deploy_edges_delay.append(vnf_adjecent_link_delay)
                link_commu_delay += vnf_adjecent_link_delay

            sfc_total_delay = vnf_process_delay+link_commu_delay
            sfc.deploy_total_vnf_delay = vnf_process_delay
            sfc.deploy_total_link_delay = link_commu_delay
            sfc.deploy_total_delay = sfc_total_delay

            # print("vnf_process_delay:", vnf_process_delay)
            # print("link_commu_delay:", link_commu_delay)
            # print("sfc_total_delay:", sfc_total_delay)
            # print("sfc.deploy_nodes_delay", sfc.deploy_nodes_delay)
            # print("sfc.deploy_edges_delay", sfc.deploy_edges_delay)

            #当时延不满足需求时，则不计算成本，将SFC保存到被拒绝的队列中去，更新G_execute
            if sfc_total_delay<d_r:
                Accept_SFCs.append(sfc) #将sfc添加到被接收的集合中去
                G_success = copy.deepcopy(G_execute)

                total_cost = 0
                deploy_total_cost = 0
                migrate_total_cost = 0
                sto_total_cost = 0
                #计算部署的成本
                for idex in range(len(sfc.deploy_nodes_cost)):
                    deploy_total_cost += sfc.deploy_nodes_cost[idex]
                    migrate_total_cost += sfc.migrate_cost[idex]
                    sto_total_cost += sfc.deploy_nodes_sto_cost[idex]
                total_cost = deploy_total_cost + migrate_total_cost
                sfc.deploy_total_cost = deploy_total_cost
                sfc.deploy_sto_cost = sto_total_cost
                sfc.migrate_total_cost = migrate_total_cost



                zero_count = sfc.migrate_nodes.count(0)
                sfc.migrate_total_number = len(sfc.migrate_nodes)-zero_count
            else:
                Reject_SFCs.append(sfc)
                G_execute = copy.deepcopy(G_success)


            #计算SFC部署的成本，部署的时延

            #print(sfc.return_info())
            #exit(0)




#保存所有的被接收的业务功能链的信息
print("所有请求的业务功能链的数量：",len(Request_total_SFCs))
print("被拒绝的业务功能链的数量：",len(Reject_SFCs))
#计算被接收的业务功能链的数量，以及业务功能链的各项指标
print("被接收的业务功能链的数量：",len(Accept_SFCs))

# for sfc in Reject_SFCs:
#     print(sfc.latency_demand)
#     print(sfc.deploy_total_delay)
# for sfc in Reject_SFCs:
#     print("sfc.start_point:",sfc.start_point)
#     print("sfc.end_point",sfc.end_point)

#Get_Network_information(G_execute)

#将被接受的业务功能链的信息保存到以Geedy_lambda_seed_lensfc的.xlsx文件中去
# 使用字符串格式化构建文件名
Accept_SFCs_data = {}
Accept_SFCs_data["到达时间"] = []
Accept_SFCs_data["起点"] = []
Accept_SFCs_data["终点"] = []
Accept_SFCs_data["带宽需求"] = []
Accept_SFCs_data["时延需求"] = []
Accept_SFCs_data["生命周期"] = []
Accept_SFCs_data["VNFs列表"] = []

Accept_SFCs_data["部署的节点的位置"] = []
Accept_SFCs_data["部署的链路的位置"] = []
Accept_SFCs_data["软件从哪里迁移过来"] = []

Accept_SFCs_data["每个VNF放置的时延"] = []
Accept_SFCs_data["相邻VNF间的链路时延"] = []
Accept_SFCs_data["每个VNF放置后的资源使用成本"] = []
Accept_SFCs_data["每个VNF放置后使用的storage成本"] = []
Accept_SFCs_data["每个VNF放置后的迁移的软件的成本"] = []

Accept_SFCs_data["部署的总通信时延，包含链路时延和处理时延"] = []
Accept_SFCs_data["部署的VNF总时延，包含处理时延"] = []
Accept_SFCs_data["部署的link链路总时延，包含传输时延"] = []
Accept_SFCs_data["部署的总通信成本，包括节点资源使用成本"] = []
Accept_SFCs_data["部署后的总资源使用成本"] = []
Accept_SFCs_data["每个VNF放置后所需要的软件的迁移成本总和"] = []
Accept_SFCs_data["每个VNF放置后所需要迁移的软件的次数"] = []

accept_file_name = f'D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Evaluation_data9/Bestfit/Bestfit_accept_{λ}_{SEED}_{SFC_LEN_L}_200400_9.xlsx'

for sfc in Accept_SFCs:
    Accept_SFCs_data["到达时间"].append(sfc.arrival)
    Accept_SFCs_data["起点"].append(sfc.start_point)
    Accept_SFCs_data["终点"].append(sfc.end_point)
    Accept_SFCs_data["带宽需求"].append(sfc.bandwidth_demand)
    Accept_SFCs_data["时延需求"].append(sfc.latency_demand)
    Accept_SFCs_data["生命周期"].append(sfc.lifecycle)
    Accept_SFCs_data["VNFs列表"].append(sfc.vnf_list)

    Accept_SFCs_data["部署的节点的位置"].append(sfc.deploy_nodes)
    Accept_SFCs_data["部署的链路的位置"].append(sfc.deploy_edges)
    Accept_SFCs_data["软件从哪里迁移过来"].append(sfc.migrate_nodes)

    Accept_SFCs_data["每个VNF放置的时延"].append(sfc.deploy_nodes_delay)
    Accept_SFCs_data["相邻VNF间的链路时延"].append(sfc.deploy_edges_delay)
    Accept_SFCs_data["每个VNF放置后的资源使用成本"].append(sfc.deploy_nodes_cost)
    Accept_SFCs_data["每个VNF放置后使用的storage成本"].append(sfc.deploy_nodes_sto_cost)

    Accept_SFCs_data["每个VNF放置后的迁移的软件的成本"].append(sfc.migrate_cost)

    Accept_SFCs_data["部署的总通信时延，包含链路时延和处理时延"].append(sfc.deploy_total_delay)
    Accept_SFCs_data["部署的VNF总时延，包含处理时延"].append(sfc.deploy_total_vnf_delay)
    Accept_SFCs_data["部署的link链路总时延，包含传输时延"].append(sfc.deploy_total_link_delay)
    Accept_SFCs_data["部署的总通信成本，包括节点资源使用成本"].append(sfc.deploy_total_cost)
    Accept_SFCs_data["部署后的总资源使用成本"].append(sfc.deploy_sto_cost)
    Accept_SFCs_data["每个VNF放置后所需要的软件的迁移成本总和"].append(sfc.migrate_total_cost)
    Accept_SFCs_data["每个VNF放置后所需要迁移的软件的次数"].append(sfc.migrate_total_number)

Save_accept_data_to_execl(Accept_SFCs_data, accept_file_name)

network_status_filename = f'D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Evaluation_data9/Bestfit/Network_status_Bestfit_{λ}_{SEED}_{SFC_LEN_L}_200400_9.xlsx'
Network_status_data = {}

Network_status_data["节点"] = []
Network_status_data["cpu"] = []
Network_status_data["memory"] = []
Network_status_data["storage"] = []
Network_status_data["cpu_uti"] = []
Network_status_data["memory_uti"] = []
Network_status_data["storage_uti"] = []
Network_status_data["domain"] = []

for node in G_execute.nodes:
    Network_status_data["节点"].append(node)
    Network_status_data["cpu"].append(G_initial.nodes[node]['cpu']-G_execute.nodes[node]['cpu'])
    Network_status_data["memory"].append(G_initial.nodes[node]['memory']-G_execute.nodes[node]['memory'])
    Network_status_data["storage"].append(G_initial.nodes[node]['storage']-G_execute.nodes[node]['storage'])
    Network_status_data["cpu_uti"].append((G_initial.nodes[node]['cpu']-G_execute.nodes[node]['cpu'])*1.0/G_initial.nodes[node]['cpu'])
    Network_status_data["memory_uti"].append((G_initial.nodes[node]['memory']-G_execute.nodes[node]['memory'])*1.0/G_initial.nodes[node]['memory'])
    Network_status_data["storage_uti"].append((G_initial.nodes[node]['storage']-G_execute.nodes[node]['storage'])*1.0/G_initial.nodes[node]['storage'])
    Network_status_data["domain"].append(G_execute.nodes[node]['domain'])


Save_accept_data_to_execl(Network_status_data, network_status_filename)























