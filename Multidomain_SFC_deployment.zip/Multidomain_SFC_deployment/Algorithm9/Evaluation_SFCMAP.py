#首先通过对初始物理图的拷贝构建一个多层图，图的层数为|F|+1
#通过不同层中的相同节点间的层间链路来连接不同的层，创建层间节点代表每层中每个VNF可能放置的位置
#给多层图的节点和链路分配成本和时延权重，对于每个请求，开始节点和结束节点分别放在第一层和最后一层网络上
#在这个多层加权图中找一条从开始节点到最终节点的最短链路
#如果没有找到最终解或者违反时延约束，则对选择的节点和链路进行相应的惩罚，并进行下一次迭代
#当迭代次数结束或者业务功能链被成功部署时，结束这个过程


# %描述算法，实际上也是算法的流程
# %首先通过对初始物理图的拷贝构建一个|F|+1层的多层图
# %在每两层中的相同节点间建立层间链路，在每两层中的相同节点间建立物理节点，使其通过相应层间链路连接相邻层
# %给多层图的节点分配成本和时延权重，给每条链路分配时延权重
# %对于每个请求，源节点和终端节点分别放在第一层和最后一层上网络上
# %在这个多层加权图中，找到一条从开始节点到最终节点时延和成本最短的链路
# %将业务功能链部署到这条链路上
# %如果没有找到最终解或者违反时延约束，则对选择的节点和链路进行相应的惩罚，并进行下一次迭代
# %当迭代次数结束后或者业务功能链被成功部署时，结束这个过程
# %在本论文中，将迭代次数设置为30次，将惩罚因子设置为1.5

import numpy as np
from Multidomain_SFC_deployment.Initialization.Class_SFC import *
from Multidomain_SFC_deployment.Initialization.generate_network import *
from Multidomain_SFC_deployment.Initialization.Global import *
from Multidomain_SFC_deployment.Algorithm.utils import *
import argparse
import copy
import pandas as pd

np.random.seed(SEED)   #随机种子设定，可以通过随机种子的设定来重复实验

parser = argparse.ArgumentParser()
parser.add_argument('--inputfile', type=str, nargs='?',
                        const=1, default="D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Initialization/network_USA_9.gml")
parser.add_argument('--outputfile', type=str, nargs='?',
                        const=1,
                        default=r'D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Initialization/network_USA_9.gpickle')
args = parser.parse_args()  #网络环境的链接
if args.inputfile.endswith(".gml"):
    G_initial = gml_reader(SEED, args.inputfile, args.outputfile) #生成网络拓扑
else:
    pass

G_success = copy.deepcopy(G_initial) #深拷贝网络，使G_success用来表示上一次成功执行的业务功能链之后的网络的状态
G_execute = copy.deepcopy(G_success) #深拷贝网络，使用G_execute表示当前用来执行的网络的状态


poisson_samples = np.random.poisson(lam=λ, size=SLOT_NUM_L)     #获得每个时隙中的业务功能链的数量，可以通过改变业务功能链到达的速率来重复实验

#需要将所有请求的业务功能链保存到一个文档中去
Request_total_SFCs = []  #用来保存所有请求的SFC的列表
Accept_SFCs = [] #用来保存所有被成功接收的SFC的列表
Reject_SFCs = [] #用来保存所有被拒绝的SFC的列表

#获得所有VNF需要的信息
cpu = [R_C_L, R_C_H]
mem = [R_M_L, R_M_H]
All_Vnfs_Info = Get_VNFs_INFO(cpu, mem, R_S_L, R_S_H)
#print(All_Vnfs_Info)


for t in range(SLOT_NUM_L):
    sfc_t_nums = poisson_samples[t] #获得当前时隙中的需要部署的业务功能链的数量
    SFCs_Info = Generate_SFCs_Info(args.inputfile, sfc_t_nums) #获得当前时隙中的业务功能链的信息

    print("****************time slot****************",t)

    # 依次部署业务功能链，记录业务功能链部署时的时延，部署的成本，迁移的成本，迁移的次数
    for sfc_num,sfc in enumerate(SFCs_Info): #这个循环中部署请求的业务功能链
        print("##########sfc", sfc_num)
        FLAG = True
        sfc.arrival = t  # 给定业务到达的时间
        Request_total_SFCs.append(sfc.return_list())  # 添加新到达的SFC
        # print(Request_total_SFCs)

        start = sfc.start_point
        end = sfc.end_point

        b_r = sfc.bandwidth_demand  # 业务功能链的带宽请求
        d_r = sfc.latency_demand  # 业务功能链的时延需求
        VNF_List = sfc.vnf_list  # 获取业务功能链每个VNF需要的信息
        #SFCMAP算法中部署一个SFC最多迭代SFCMAP_INTER_NUM次
        for iter_nums in range(SFCMAP_INTER_NUM):
            FLAG = True #业务可以被成功部署
            # print("开始节点：", start," ","结束节点：", end," ", "带宽请求：", b_r," ", "时延请求：",d_r)
            # print("请求的VNFs：", VNF_List)

            #依次放置vnf,并保存每个VNF所在的位置，所使用的链路
            #记录每个VNF放置时使用的成本
            for idex, vnf in enumerate(VNF_List):
                #获得能满足vnf放置的节点并保存节点和上一个节点连接的链路
                #[['IPFilter'], [39, 35, 74]]
                vnf_request = All_Vnfs_Info[vnf]
                #print(vnf_request)
                #
                if idex == 0:
                    vnf_place_node, vnf_communication_link, vnf_communication_link1 = SFCMAP_find_node1(G_initial, G_execute, vnf_request, start, b_r)
                    #print("放置vnf的节点的性能",vnf_place_node)
                    #print("可能放置的链路",vnf_communication_link, vnf_communication_link1)

                    sfc.deploy_nodes.append(vnf_place_node[0])
                    sfc.deploy_edges.append(vnf_communication_link)
                    sfc.migrate_nodes.append(vnf_place_node[5])
                    sfc.deploy_nodes_cost.append(vnf_place_node[1])
                    sfc.deploy_nodes_sto_cost.append(vnf_place_node[6])
                    sfc.deploy_nodes_delay.append(vnf_place_node[3])
                    sfc.migrate_cost.append(vnf_place_node[2])

                    #更新网络资源，包括更新物理节点资源和链路资源
                    #物理节点更新
                    G_execute.nodes[vnf_place_node[0]]['cpu'] = G_execute.nodes[vnf_place_node[0]]['cpu'] - vnf_request[1][0]
                    G_execute.nodes[vnf_place_node[0]]['memory'] = G_execute.nodes[vnf_place_node[0]]['memory'] - vnf_request[1][1]

                    if vnf_place_node[5] != 0:
                        G_execute.nodes[vnf_place_node[0]]['software'].append(vnf_request[0][0])
                        G_execute.nodes[vnf_place_node[0]]['storage'] = G_execute.nodes[vnf_place_node[0]]['storage'] - \
                                                                       vnf_request[1][2]

                    #物理链路更新
                    if vnf_communication_link == None:
                        FLAG = False
                        #对已有的选中的连接和节点进行惩罚
                        #改变G_sucess和G_execute
                        #将G_execute回到初始状态
                        G_execute = copy.deepcopy(G_success)


                        #对G_execute中选中已经选中的节点进行惩罚
                        # if len(sfc.deploy_nodes)>0:
                        #     for place_node in sfc.deploy_nodes:
                        #         G_execute.nodes[place_node]['penalty_factor'] = PENALTY_FACTOR*G_execute.nodes[place_node]['penalty_factor']

                        #对当前选中的节点进行惩罚
                        G_execute.nodes[vnf_place_node[0]]['penalty_factor'] = PENALTY_FACTOR * G_execute.nodes[vnf_place_node[0]][
                            'penalty_factor']

                        #对当前选中的链接进行惩罚
                        if len(vnf_communication_link1)>1:
                            for link_index in range(len(vnf_communication_link1)-1):
                                G_execute.edges[(vnf_communication_link1[link_index],vnf_communication_link1[link_index+1])]['penalty_factor'] = PENALTY_FACTOR * G_execute.edges[(vnf_communication_link1[link_index],vnf_communication_link1[link_index+1])]['penalty_factor']
                        #将得到的新网络复制给最后被成功部署的网络
                        G_success = copy.deepcopy(G_execute)
                        #对所有选择的节点和链路进行惩罚
                        sfc.deploy_nodes = []
                        sfc.deploy_edges = []
                        sfc.migrate_nodes = []
                        sfc.deploy_nodes_cost = []
                        sfc.deploy_nodes_delay = []
                        sfc.migrate_cost = []
                        break
                    else:
                        for link_index in range(len(vnf_communication_link)-1):
                            G_execute.edges[(vnf_communication_link[link_index],vnf_communication_link[link_index+1])]['bandwidth'] -= b_r

                else:
                    vnf_place_node, vnf_communication_link, vnf_communication_link1 = SFCMAP_find_node1(G_initial, G_execute, vnf_request,
                                                                                    sfc.deploy_nodes[idex-1], b_r)
                    # print("放置vnf的节点的性能", vnf_place_node)
                    #print("可能放置的链路", vnf_communication_link, vnf_communication_link1)
                    sfc.deploy_nodes.append(vnf_place_node[0])
                    sfc.deploy_edges.append(vnf_communication_link)
                    sfc.migrate_nodes.append(vnf_place_node[5])
                    sfc.deploy_nodes_cost.append(vnf_place_node[1])
                    sfc.deploy_nodes_sto_cost.append(vnf_place_node[6])
                    sfc.deploy_nodes_delay.append(vnf_place_node[3])
                    sfc.migrate_cost.append(vnf_place_node[2])

                    #print("sfc_deploy_Edges",sfc.deploy_edges)

                    #更新网络资源，包括更新物理节点资源和链路资源
                    # 物理节点更新
                    G_execute.nodes[vnf_place_node[0]]['cpu'] = G_execute.nodes[vnf_place_node[0]]['cpu'] - vnf_request[1][
                        0]
                    G_execute.nodes[vnf_place_node[0]]['memory'] = G_execute.nodes[vnf_place_node[0]]['memory'] - \
                                                                   vnf_request[1][1]
                    if vnf_place_node[5] != 0:
                        G_execute.nodes[vnf_place_node[0]]['software'].append(vnf_request[0][0])
                        G_execute.nodes[vnf_place_node[0]]['storage'] = G_execute.nodes[vnf_place_node[0]]['storage'] - \
                                                                        vnf_request[1][2]
                    # 物理链路更新
                    if vnf_communication_link == None:
                        FLAG = False
                        sfc.deploy_nodes = []
                        sfc.deploy_edges = []
                        sfc.migrate_nodes = []
                        sfc.deploy_nodes_cost = []
                        sfc.deploy_nodes_delay = []
                        sfc.migrate_cost = []
                        # 将G_execute回到初始状态
                        G_execute = copy.deepcopy(G_success)
                        # 对当前选中的节点进行惩罚
                        G_execute.nodes[vnf_place_node[0]]['penalty_factor'] = PENALTY_FACTOR * \
                                                                               G_execute.nodes[vnf_place_node[0]]['penalty_factor']

                        # 对当前选中的链接进行惩罚
                        if len(vnf_communication_link1) > 1:
                            for link_index in range(len(vnf_communication_link1) - 1):
                                G_execute.edges[
                                    (vnf_communication_link1[link_index], vnf_communication_link1[link_index + 1])][
                                    'penalty_factor'] = PENALTY_FACTOR * G_execute.edges[
                                    (vnf_communication_link1[link_index], vnf_communication_link1[link_index + 1])][
                                    'penalty_factor']

                        # 将得到的新网络复制给最后被成功部署的网络
                        G_success = copy.deepcopy(G_execute)
                        # 对所有选择的节点和链路进行惩罚
                        sfc.deploy_nodes = []
                        sfc.deploy_edges = []
                        sfc.migrate_nodes = []
                        sfc.deploy_nodes_cost = []
                        sfc.deploy_nodes_delay = []
                        sfc.migrate_cost = []
                        break
                    else:
                        for link_index in range(len(vnf_communication_link) - 1):
                            G_execute.edges[(vnf_communication_link[link_index], vnf_communication_link[link_index + 1])]['bandwidth'] -= b_r
            if FLAG == True:
                vnf_communication_link, vnf_communication_link1 = Get_Shortest_delay_path1(G_execute, vnf_place_node[0],
                                                                                           end, b_r)
                sfc.deploy_edges.append(vnf_communication_link)
            else:
                # 将G_execute回到初始状态
                G_execute = copy.deepcopy(G_success)
                #对当前选中的节点进行惩罚
                G_execute.nodes[vnf_place_node[0]]['penalty_factor'] = PENALTY_FACTOR * G_execute.nodes[vnf_place_node[0]]['penalty_factor']


                # 将得到的新网络复制给最后被成功部署的网络
                G_success = copy.deepcopy(G_execute)
                # 对所有选择的节点和链路进行惩罚
                sfc.deploy_nodes = []
                sfc.deploy_edges = []
                sfc.migrate_nodes = []
                sfc.deploy_nodes_cost = []
                sfc.deploy_nodes_delay = []
                sfc.migrate_cost = []
                break
            vnf_communication_link, vnf_communication_link1 = Get_Shortest_delay_path1(G_execute, vnf_place_node[0], end, b_r)
            if vnf_communication_link == None:
                FLAG = False
                G_execute = copy.deepcopy(G_success)
                #对当前选中的节点进行惩罚
                G_execute.nodes[vnf_place_node[0]]['penalty_factor'] = PENALTY_FACTOR * \
                                                                       G_execute.nodes[vnf_place_node[0]][
                                                                           'penalty_factor']
                # 对当前选中的链接进行惩罚
                if len(vnf_communication_link1) > 1:
                    for link_index in range(len(vnf_communication_link1) - 1):
                        G_execute.edges[
                            (vnf_communication_link1[link_index], vnf_communication_link1[link_index + 1])][
                            'penalty_factor'] = PENALTY_FACTOR * G_execute.edges[
                            (vnf_communication_link1[link_index], vnf_communication_link1[link_index + 1])][
                            'penalty_factor']
                # 将得到的新网络复制给最后被成功部署的网络
                G_success = copy.deepcopy(G_execute)
                sfc.deploy_nodes = []
                sfc.deploy_edges = []
                sfc.migrate_nodes = []
                sfc.deploy_nodes_cost = []
                sfc.deploy_nodes_delay = []
                sfc.migrate_cost = []
                break


            if FLAG == True:
                #计算时延
                sfc_total_delay = 0
                vnf_process_delay = 0
                link_commu_delay = 0
                for idex, place_node in enumerate(sfc.deploy_nodes):
                    # sfc.deploy_nodes_delay.append(G_execute.nodes[sfc.deploy_nodes[idex]]['process_d'])
                    # vnf_process_delay += G_execute.nodes[sfc.deploy_nodes[idex]]['process_d']
                    vnf_process_delay += sfc.deploy_nodes_delay[idex]
                #print("sfc.deploy_edges:",sfc.deploy_edges)
                for vnf_adjecent_link in sfc.deploy_edges:
                    vnf_adjecent_link_delay = 0
                    if len(vnf_adjecent_link)>1:
                        for idex in range(len(vnf_adjecent_link) - 1):
                            vnf_adjecent_link_delay += \
                            G_execute.edges[(vnf_adjecent_link[idex], vnf_adjecent_link[idex + 1])]['trans_d']
                        sfc.deploy_edges_delay.append(vnf_adjecent_link_delay)
                        link_commu_delay += vnf_adjecent_link_delay
                    else: link_commu_delay+=0

                sfc_total_delay = vnf_process_delay + link_commu_delay
                sfc.deploy_total_delay = sfc_total_delay
                sfc.deploy_total_link_delay = link_commu_delay
                sfc.deploy_total_vnf_delay = vnf_process_delay
                #判断时延是否满足要求
                if sfc_total_delay < d_r:
                    Accept_SFCs.append(sfc)  # 将sfc添加到被接收的集合中去
                    #需要改变G_execute中的惩罚因子
                    for node in G_execute.nodes:
                        G_execute.nodes[node]["penalty_factor"] = G_execute.nodes[node]["process_d"]
                    for edge in G_execute.edges:
                        G_execute.edges[edge]["penalty_factor"] = G_execute.edges[edge]["trans_d"]

                    G_success = copy.deepcopy(G_execute)

                    total_cost = 0
                    deploy_total_cost = 0
                    migrate_total_cost = 0
                    sto_total_cost = 0
                    # 计算部署的成本
                    for idex in range(len(sfc.deploy_nodes_cost)):
                        deploy_total_cost += sfc.deploy_nodes_cost[idex]
                        migrate_total_cost += sfc.migrate_cost[idex]
                        sto_total_cost += sfc.deploy_nodes_sto_cost[idex]
                    total_cost = deploy_total_cost + migrate_total_cost
                    sfc.deploy_total_cost = total_cost
                    sfc.deploy_sto_cost = sto_total_cost
                    sfc.migrate_total_cost = migrate_total_cost

                    zero_count = sfc.migrate_nodes.count(0)
                    sfc.migrate_total_number = len(sfc.migrate_nodes) - zero_count
                    break
                #时延不满足要求的话将FLAG设置为False
                else:
                    G_execute = copy.deepcopy(G_success)
                    # 对G_execute中选中已经选中的节点进行惩罚
                    # if len(sfc.deploy_nodes) > 0:
                    #     for place_node in sfc.deploy_nodes:
                    #         G_execute.nodes[place_node]['penalty_factor'] = PENALTY_FACTOR * \
                    #                                                         G_execute.nodes[place_node][
                    #                                                             'penalty_factor']
                    #对G_execute中选中的链路进行惩罚
                    if len(sfc.deploy_edges) > 0:
                        for path in sfc.deploy_edges:
                            if len(path)>1:
                                for path_idex in range(len(path)-1):
                                    G_execute.edges[
                                        (path[path_idex], path[path_idex+1])][
                                        'penalty_factor'] = PENALTY_FACTOR*G_execute.edges[
                                        (path[path_idex], path[path_idex+1])][
                                        'penalty_factor']
                    # 将得到的新网络复制给最后被成功部署的网络
                    G_success = copy.deepcopy(G_execute)
                    sfc.deploy_nodes = []
                    sfc.deploy_edges = []
                    sfc.migrate_nodes = []
                    sfc.deploy_nodes_cost = []
                    sfc.deploy_nodes_delay = []
                    sfc.migrate_cost = []
                    FLAG = False


            else:
                #获得所有的边

                print("sfc_deploy_nodes:",sfc.deploy_nodes)
                print("sfc_deploy_edges:",sfc.deploy_edges)

        # print("sfc部署使用的物理节点：",sfc.deploy_nodes)
        # print("sfc部署使用的物理链路：",sfc.deploy_edges)
        # print("sfc部署需要迁移的软件：",sfc.migrate_nodes)

        #计算当前这个VNF的时延和成本
        #首先计算时延，当时延满足需求时，则继续计算成本，并将SFC保存到被成功部署的队列中去，更新G_sucess
        #print(FLAG)



        if FLAG==False:
            Reject_SFCs.append(sfc)
            G_execute = copy.deepcopy(G_success)


            #计算SFC部署的成本，部署的时延

            #print(sfc.return_info())
            #exit(0)




#保存所有的被接收的业务功能链的信息
print("所有请求的业务功能链的数量：",len(Request_total_SFCs))
print("被拒绝的业务功能链的数量：",len(Reject_SFCs))
#计算被接收的业务功能链的数量，以及业务功能链的各项指标
print("被接收的业务功能链的数量：",len(Accept_SFCs))

# for sfc in Reject_SFCs:
#     print(sfc.latency_demand)
#     print(sfc.deploy_total_delay)
# for sfc in Reject_SFCs:
#     print("sfc.start_point:",sfc.start_point)
#     print("sfc.end_point",sfc.end_point)

#Get_Network_information(G_execute)

#将被接受的业务功能链的信息保存到以Geedy_lambda_seed_lensfc的.xlsx文件中去
# 使用字符串格式化构建文件名
Accept_SFCs_data = {}
Accept_SFCs_data["到达时间"] = []
Accept_SFCs_data["起点"] = []
Accept_SFCs_data["终点"] = []
Accept_SFCs_data["带宽需求"] = []
Accept_SFCs_data["时延需求"] = []
Accept_SFCs_data["生命周期"] = []
Accept_SFCs_data["VNFs列表"] = []

Accept_SFCs_data["部署的节点的位置"] = []
Accept_SFCs_data["部署的链路的位置"] = []
Accept_SFCs_data["软件从哪里迁移过来"] = []

Accept_SFCs_data["每个VNF放置的时延"] = []
Accept_SFCs_data["相邻VNF间的链路时延"] = []
Accept_SFCs_data["每个VNF放置后的资源使用成本"] = []
Accept_SFCs_data["每个VNF放置后使用的storage成本"] = []
Accept_SFCs_data["每个VNF放置后的迁移的软件的成本"] = []

Accept_SFCs_data["部署的总通信时延，包含链路时延和处理时延"] = []
Accept_SFCs_data["部署的VNF总时延，包含处理时延"] = []
Accept_SFCs_data["部署的link链路总时延，包含传输时延"] = []
Accept_SFCs_data["部署的总通信成本，包括节点资源使用成本"] = []
Accept_SFCs_data["部署后的总资源使用成本"] = []
Accept_SFCs_data["每个VNF放置后所需要的软件的迁移成本总和"] = []
Accept_SFCs_data["每个VNF放置后所需要迁移的软件的次数"] = []

accept_file_name = f'D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Evaluation_data9/SFCMAP/SFCMAP_accept_{λ}_{SEED}_{SFC_LEN_L}_200400_9.xlsx'

for sfc in Accept_SFCs:
    Accept_SFCs_data["到达时间"].append(sfc.arrival)
    Accept_SFCs_data["起点"].append(sfc.start_point)
    Accept_SFCs_data["终点"].append(sfc.end_point)
    Accept_SFCs_data["带宽需求"].append(sfc.bandwidth_demand)
    Accept_SFCs_data["时延需求"].append(sfc.latency_demand)
    Accept_SFCs_data["生命周期"].append(sfc.lifecycle)
    Accept_SFCs_data["VNFs列表"].append(sfc.vnf_list)

    Accept_SFCs_data["部署的节点的位置"].append(sfc.deploy_nodes)
    Accept_SFCs_data["部署的链路的位置"].append(sfc.deploy_edges)
    Accept_SFCs_data["软件从哪里迁移过来"].append(sfc.migrate_nodes)

    Accept_SFCs_data["每个VNF放置的时延"].append(sfc.deploy_nodes_delay)
    Accept_SFCs_data["相邻VNF间的链路时延"].append(sfc.deploy_edges_delay)
    Accept_SFCs_data["每个VNF放置后的资源使用成本"].append(sfc.deploy_nodes_cost)
    Accept_SFCs_data["每个VNF放置后使用的storage成本"].append(sfc.deploy_nodes_sto_cost)

    Accept_SFCs_data["每个VNF放置后的迁移的软件的成本"].append(sfc.migrate_cost)

    Accept_SFCs_data["部署的总通信时延，包含链路时延和处理时延"].append(sfc.deploy_total_delay)
    Accept_SFCs_data["部署的VNF总时延，包含处理时延"].append(sfc.deploy_total_vnf_delay)
    Accept_SFCs_data["部署的link链路总时延，包含传输时延"].append(sfc.deploy_total_link_delay)
    Accept_SFCs_data["部署的总通信成本，包括节点资源使用成本"].append(sfc.deploy_total_cost)
    Accept_SFCs_data["部署后的总资源使用成本"].append(sfc.deploy_sto_cost)
    Accept_SFCs_data["每个VNF放置后所需要的软件的迁移成本总和"].append(sfc.migrate_total_cost)
    Accept_SFCs_data["每个VNF放置后所需要迁移的软件的次数"].append(sfc.migrate_total_number)

Save_accept_data_to_execl(Accept_SFCs_data, accept_file_name)

network_status_filename = f'D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Evaluation_data9/SFCMAP/Network_status_SFCMAP_{λ}_{SEED}_{SFC_LEN_L}_200400_9.xlsx'
Network_status_data = {}

Network_status_data["节点"] = []
Network_status_data["cpu"] = []
Network_status_data["memory"] = []
Network_status_data["storage"] = []
Network_status_data["cpu_uti"] = []
Network_status_data["memory_uti"] = []
Network_status_data["storage_uti"] = []
Network_status_data["domain"] = []

for node in G_execute.nodes:
    Network_status_data["节点"].append(node)
    Network_status_data["cpu"].append(G_initial.nodes[node]['cpu']-G_execute.nodes[node]['cpu'])
    Network_status_data["memory"].append(G_initial.nodes[node]['memory']-G_execute.nodes[node]['memory'])
    Network_status_data["storage"].append(G_initial.nodes[node]['storage']-G_execute.nodes[node]['storage'])
    Network_status_data["cpu_uti"].append((G_initial.nodes[node]['cpu']-G_execute.nodes[node]['cpu'])*1.0/G_initial.nodes[node]['cpu'])
    Network_status_data["memory_uti"].append((G_initial.nodes[node]['memory']-G_execute.nodes[node]['memory'])*1.0/G_initial.nodes[node]['memory'])
    Network_status_data["storage_uti"].append((G_initial.nodes[node]['storage']-G_execute.nodes[node]['storage'])*1.0/G_initial.nodes[node]['storage'])
    Network_status_data["domain"].append(G_execute.nodes[node]['domain'])


Save_accept_data_to_execl(Network_status_data, network_status_filename)























