import sys
import networkx as nx
from Multidomain_SFC_deployment.Initialization.utils_plot import *

import networkx as nx


def find_optimal_path_with_constraints(G, start, end, layers):
    def path_capacity(G, path):
        return sum(G[u][v]['capacity'] for u, v in zip(path[:-1], path[1:]))

    # 初始化动态规划表
    dp = {(node,): (G.nodes[node]['capacity'], [node]) for node in layers[0]}

    # 逐层构建路径
    for layer in layers[1:]:
        new_dp = {}
        for node in layer:
            node_mod = node % 100
            for prev_nodes, (cap, path) in dp.items():
                if all(node_mod != prev_node % 100 for prev_node in prev_nodes):
                    last_node = prev_nodes[-1]
                    try:
                        new_path = nx.shortest_path(G, last_node, node, weight='capacity')
                        total_capacity = cap + path_capacity(G, new_path)
                        new_nodes = prev_nodes + (node,)
                        if new_nodes not in new_dp or total_capacity < new_dp[new_nodes][0]:
                            new_dp[new_nodes] = (total_capacity, path + new_path[1:])
                    except nx.NetworkXNoPath:
                        continue
        dp = new_dp

    # 找到结束节点的最优路径
    final_paths = {}
    for nodes, (cap, path) in dp.items():
        try:
            last_node = nodes[-1]
            path_to_end = nx.shortest_path(G, last_node, end, weight='capacity')
            total_capacity = cap + path_capacity(G, path_to_end[1:])
            final_paths[nodes] = (total_capacity, path + path_to_end[1:])
        except nx.NetworkXNoPath:
            continue

    # 选择最小capacity的路径
    optimal_nodes, (min_capacity, optimal_path) = min(final_paths.items(), key=lambda x: x[1][0])

    return optimal_path, min_capacity, optimal_nodes


# 定义层级节点
layers = [[101, 102, 103, 104], [201, 202, 203, 204], [301, 302, 303, 304]]


# 示例用法
Multilayer_Network = nx.Graph()
Multilayer_Network.add_node(101, capacity=1)
Multilayer_Network.add_node(102, capacity=4)
Multilayer_Network.add_node(103, capacity=3)
Multilayer_Network.add_node(104, capacity=2)

Multilayer_Network.add_node(201, capacity=5)
Multilayer_Network.add_node(202, capacity=2)
Multilayer_Network.add_node(203, capacity=2)
Multilayer_Network.add_node(204, capacity=3)

Multilayer_Network.add_node(301, capacity=2)
Multilayer_Network.add_node(302, capacity=1)
Multilayer_Network.add_node(303, capacity=3)
Multilayer_Network.add_node(304, capacity=1)


Multilayer_Network.add_edge(101, 102, capacity=3)
Multilayer_Network.add_edge(102, 103, capacity=4)
Multilayer_Network.add_edge(103, 104, capacity=5)
Multilayer_Network.add_edge(104, 101, capacity=4)
Multilayer_Network.add_edge(101, 103, capacity=4)

Multilayer_Network.add_edge(201, 202, capacity=3)
Multilayer_Network.add_edge(202, 203, capacity=4)
Multilayer_Network.add_edge(203, 204, capacity=5)
Multilayer_Network.add_edge(204, 201, capacity=4)
Multilayer_Network.add_edge(201, 203, capacity=4)

Multilayer_Network.add_edge(301, 302, capacity=3)
Multilayer_Network.add_edge(302, 303, capacity=4)
Multilayer_Network.add_edge(303, 304, capacity=5)
Multilayer_Network.add_edge(304, 301, capacity=4)
Multilayer_Network.add_edge(301, 303, capacity=4)

Multilayer_Network.add_edge(101, 201, capacity=0)
Multilayer_Network.add_edge(102, 202, capacity=0)
Multilayer_Network.add_edge(103, 203, capacity=0)
Multilayer_Network.add_edge(104, 204, capacity=0)

Multilayer_Network.add_edge(201, 301, capacity=0)
Multilayer_Network.add_edge(202, 302, capacity=0)
Multilayer_Network.add_edge(203, 303, capacity=0)
Multilayer_Network.add_edge(204, 304, capacity=0)
# 执行算法
optimal_path, optimal_capacity, optimal_nodes = find_optimal_path_with_constraints(Multilayer_Network, 101, 304, layers)
print(optimal_path, optimal_capacity, optimal_nodes)


#在Multilayer_Network中，需要分别在节点101，102，103，104中选择一个节点n1，
# 在201，202，203，204节点中选择一个节点n2，在301，302，303，304节点中选择一个节点n3，
# 并选择从start节点（101）节点到n1的路径l1，从n1到n2节点的路径l2，从n2到n3节点的路径l3，
# 从n3到end节点（304）的路径l4，使得选择节点n1,n2,n3上的capacity值加上路径l1,l2,l3,l4上的capacity值最小，
# 同时需要满足选择的物理节点n1,n2,n3的节点编号对100取余后的值不相等，请给出能运行的python代码


#draw_graph(Multilayer_Network)


# 添加其他节点和链路...

start_node = 101
end_node = 304
Layer_Node = [
    [101, 102, 103, 104],
    [201, 202, 203, 204],
    [301, 302, 303, 304]
]
