import networkx as nx
import itertools

# 创建图对象
Multilayer_Network = nx.Graph()

# 添加节点和边，这里只包含部分节点和边，你可以根据需要扩展
# 请确保图中包含了101，102，103，104，201，202，203，204，301，302，303，304等节点和相应的边
Multilayer_Network.add_node(10011, capacity=56)
#Multilayer_Network.add_node(10011, capacity=1000)
Multilayer_Network.add_node(10012, capacity=66)
#Multilayer_Network.add_node(10012, capacity=1000)
Multilayer_Network.add_node(10013, capacity=50)


Multilayer_Network.add_node(10021, capacity=60)
# Multilayer_Network.add_node(10022, capacity=1000)
# Multilayer_Network.add_node(10023, capacity=1000)
# Multilayer_Network.add_node(10024, capacity=1000)
Multilayer_Network.add_node(10022, capacity=62)
Multilayer_Network.add_node(10023, capacity=93)
Multilayer_Network.add_node(10024, capacity=87)

Multilayer_Network.add_node(10031, capacity=41)
Multilayer_Network.add_node(10032, capacity=70)
Multilayer_Network.add_node(10033, capacity=70)
#Multilayer_Network.add_node(10033, capacity=1000)

Multilayer_Network.add_node(20011, capacity=50)
Multilayer_Network.add_node(20012, capacity=71)
Multilayer_Network.add_node(20013, capacity=56)
# Multilayer_Network.add_node(20012, capacity=1000)
# Multilayer_Network.add_node(20013, capacity=1000)

Multilayer_Network.add_node(20021, capacity=62)
#Multilayer_Network.add_node(20021, capacity=1000)
Multilayer_Network.add_node(20022, capacity=60)
# Multilayer_Network.add_node(20023, capacity=1000)
# Multilayer_Network.add_node(20024, capacity=1000)
Multilayer_Network.add_node(20023, capacity=95)
Multilayer_Network.add_node(20024, capacity=84)

Multilayer_Network.add_node(20031, capacity=43)
Multilayer_Network.add_node(20032, capacity=75)
#Multilayer_Network.add_node(20032, capacity=1000)
Multilayer_Network.add_node(20033, capacity=65)

Multilayer_Network.add_node(30011, capacity=56)
Multilayer_Network.add_node(30012, capacity=65)
# Multilayer_Network.add_node(30011, capacity=1000)
# Multilayer_Network.add_node(30013, capacity=1000)
Multilayer_Network.add_node(30013, capacity=51)

Multilayer_Network.add_node(30021, capacity=63)
Multilayer_Network.add_node(30022, capacity=64)
# Multilayer_Network.add_node(30021, capacity=1000)
# Multilayer_Network.add_node(30022, capacity=1000)
Multilayer_Network.add_node(30023, capacity=90)
Multilayer_Network.add_node(30024, capacity=80)

Multilayer_Network.add_node(30031, capacity=54)
Multilayer_Network.add_node(30032, capacity=85)
Multilayer_Network.add_node(30033, capacity=82)
# Multilayer_Network.add_node(30032, capacity=1000)
# Multilayer_Network.add_node(30033, capacity=1000)

# Multilayer_Network.add_edge(101, 101, capacity = 0)
# Multilayer_Network.add_edge(102, 102, capacity = 0)
# Multilayer_Network.add_edge(103, 103, capacity = 0)
# Multilayer_Network.add_edge(104, 104, capacity = 0)
#
# Multilayer_Network.add_edge(201, 201, capacity = 0)
# Multilayer_Network.add_edge(202, 202, capacity = 0)
# Multilayer_Network.add_edge(203, 203, capacity = 0)
# Multilayer_Network.add_edge(204, 204, capacity = 0)
#
# Multilayer_Network.add_edge(301, 301, capacity = 0)
# Multilayer_Network.add_edge(302, 302, capacity = 0)
# Multilayer_Network.add_edge(303, 303, capacity = 0)
# Multilayer_Network.add_edge(304, 304, capacity = 0)

Multilayer_Network.add_edge(10011, 10012, capacity = 6)
Multilayer_Network.add_edge(10011, 10013, capacity = 6)
Multilayer_Network.add_edge(10012, 10013, capacity = 1)
Multilayer_Network.add_edge(10012, 10022, capacity = 17)
Multilayer_Network.add_edge(10013, 10021, capacity = 15)
Multilayer_Network.add_edge(10021, 10022, capacity = 2)
Multilayer_Network.add_edge(10021, 10023, capacity = 3)
Multilayer_Network.add_edge(10022, 10024, capacity = 4)
Multilayer_Network.add_edge(10023, 10024, capacity = 5)
Multilayer_Network.add_edge(10024, 10031, capacity = 14)
Multilayer_Network.add_edge(10024, 10032, capacity = 16)
Multilayer_Network.add_edge(10031, 10032, capacity = 1)
Multilayer_Network.add_edge(10031, 10033, capacity = 3)
Multilayer_Network.add_edge(10032, 10033, capacity = 5)

Multilayer_Network.add_edge(20011, 20012, capacity = 6)
Multilayer_Network.add_edge(20011, 20013, capacity = 6)
Multilayer_Network.add_edge(20012, 20013, capacity = 1)
Multilayer_Network.add_edge(20012, 20022, capacity = 17)
Multilayer_Network.add_edge(20013, 20021, capacity = 15)
Multilayer_Network.add_edge(20021, 20022, capacity = 2)
Multilayer_Network.add_edge(20021, 20023, capacity = 3)
Multilayer_Network.add_edge(20022, 20024, capacity = 4)
Multilayer_Network.add_edge(20023, 20024, capacity = 5)
Multilayer_Network.add_edge(20024, 20031, capacity = 14)
Multilayer_Network.add_edge(20024, 20032, capacity = 16)
Multilayer_Network.add_edge(20031, 20032, capacity = 1)
Multilayer_Network.add_edge(20031, 20033, capacity = 3)
Multilayer_Network.add_edge(20032, 20033, capacity = 5)

Multilayer_Network.add_edge(30011, 30012, capacity = 6)
Multilayer_Network.add_edge(30011, 30013, capacity = 6)
Multilayer_Network.add_edge(30012, 30013, capacity = 1)
Multilayer_Network.add_edge(30012, 30022, capacity = 17)
Multilayer_Network.add_edge(30013, 30021, capacity = 15)
Multilayer_Network.add_edge(30021, 30022, capacity = 2)
Multilayer_Network.add_edge(30021, 30023, capacity = 3)
Multilayer_Network.add_edge(30022, 30024, capacity = 4)
Multilayer_Network.add_edge(30023, 30024, capacity = 5)
Multilayer_Network.add_edge(30024, 30031, capacity = 14)
Multilayer_Network.add_edge(30024, 30032, capacity = 16)
Multilayer_Network.add_edge(30031, 30032, capacity = 1)
Multilayer_Network.add_edge(30031, 30033, capacity = 3)
Multilayer_Network.add_edge(30032, 30033, capacity = 5)


Multilayer_Network.add_edge(10011, 20011, capacity=0)
Multilayer_Network.add_edge(10012, 20012, capacity=0)
Multilayer_Network.add_edge(10013, 20013, capacity=0)
Multilayer_Network.add_edge(10021, 20021, capacity=0)
Multilayer_Network.add_edge(10022, 20022, capacity=0)
Multilayer_Network.add_edge(10023, 20023, capacity=0)
Multilayer_Network.add_edge(10024, 20024, capacity=0)
Multilayer_Network.add_edge(10031, 20031, capacity=0)
Multilayer_Network.add_edge(10032, 20032, capacity=0)
Multilayer_Network.add_edge(10033, 20033, capacity=0)

Multilayer_Network.add_edge(30011, 20011, capacity=0)
Multilayer_Network.add_edge(30012, 20012, capacity=0)
Multilayer_Network.add_edge(30013, 20013, capacity=0)
Multilayer_Network.add_edge(30021, 20021, capacity=0)
Multilayer_Network.add_edge(30022, 20022, capacity=0)
Multilayer_Network.add_edge(30023, 20023, capacity=0)
Multilayer_Network.add_edge(30024, 20024, capacity=0)
Multilayer_Network.add_edge(30031, 20031, capacity=0)
Multilayer_Network.add_edge(30032, 20032, capacity=0)
Multilayer_Network.add_edge(30033, 20033, capacity=0)

# 定义起始节点和结束节点
start_node = 10013
end_node = 30033

def find_optimal_path(network):
    # 定义起始和结束节点
    layer1_nodes = [10011, 10012, 10013, 10021,10022,10023,10024,10031,10032,10033]
    layer2_nodes = [20011, 20012, 20013, 20021,20022,20023,20024,20031,20032,20033]
    layer3_nodes = [30011, 30012, 30013, 30021,30022,30023,30024,30031,30032,30033]
    # 初始化最小容量和对应的路径
    min_total_capacity = float('inf')
    optimal_path = None
    optimal_nodes = None

    # 遍历所有可能的节点组合
    for n1 in layer1_nodes:
        for n2 in layer2_nodes:
            for n3 in layer3_nodes:
                # 确保节点编号对 100 取余后的值不相等
                if len({n1 % 10000, n2 % 10000, n3 % 10000}) == 3:
                    try:
                        # 计算路径
                        path_l1 = nx.shortest_path(network, start_node, n1, weight='capacity')
                        path_l2 = nx.shortest_path(network, n1, n2, weight='capacity')
                        path_l3 = nx.shortest_path(network, n2, n3, weight='capacity')
                        path_l4 = nx.shortest_path(network, n3, end_node, weight='capacity')

                        # 计算总容量
                        total_capacity = network.nodes[n1]['capacity'] + network.nodes[n2]['capacity'] + network.nodes[n3]['capacity']
                        total_capacity += sum(network[u][v]['capacity'] for u, v in zip(path_l1, path_l1[1:]))
                        total_capacity += sum(network[u][v]['capacity'] for u, v in zip(path_l2, path_l2[1:]))
                        total_capacity += sum(network[u][v]['capacity'] for u, v in zip(path_l3, path_l3[1:]))
                        total_capacity += sum(network[u][v]['capacity'] for u, v in zip(path_l4, path_l4[1:]))

                        # 更新最小容量和对应的路径
                        if total_capacity < min_total_capacity:
                            min_total_capacity = total_capacity
                            optimal_path = (path_l1, path_l2, path_l3, path_l4)
                            optimal_nodes = (n1, n2, n3)

                    except nx.NetworkXNoPath:
                        # 如果没有路径，则跳过此组合
                        continue

    return optimal_nodes, optimal_path, min_total_capacity

start_node = 10013
end_node = 30033

# 分层节点


# 应用函数并获取结果
optimal_nodes, optimal_path, min_total_capacity = find_optimal_path(Multilayer_Network)
print(optimal_nodes, optimal_path, min_total_capacity)


#对链路的路径转化为一个列表中
#对列表中的相同的元素去重
#获得去重后的列表

Length = []
for length in optimal_path:
    for item in length:
        Length.append(item)
print(Length)

for i, item in enumerate(Length):
    Length[i] = item%10000

print("Length:",Length)

#对列表中的元素去重

# 使用有序方法去重
unique_list = []
seen = set()
for item in Length:
    if item not in seen:
        unique_list.append(item)
        seen.add(item)

deploy_node = []
for node in optimal_nodes:
    deploy_node.append(node%10000)

print(deploy_node)

print(unique_list)




