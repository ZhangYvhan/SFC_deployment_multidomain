import argparse
import copy
import math
import sys

import numpy as np
from Multidomain_SFC_deployment.Initialization.Global import *
from Multidomain_SFC_deployment.Initialization.generate_network import *

#求两个节点间的时延最短的路径，返回路径和总时延
def Get_Shortest_delay (G_execute, node1, node2):
    shortest_paths = nx.shortest_simple_paths(G_execute, source=node1, target=node2, weight='trans_d')
    #print("shortest_paths:",shortest_paths)
    shortest_path = next(shortest_paths)
    #print("shortest_path:",shortest_path)
    total_delay = sum(G_execute[shortest_path[i]][shortest_path[i + 1]]['trans_d'] for i in range(len(shortest_path) - 1))
    return total_delay

#求两个节点间满足链路带宽的最短简单的链路时延最短的路径，并返回链路
def Get_Shortest_delay_path(G_execute, node1, node2, b_r):
    k = 0
    for path in nx.shortest_simple_paths(G_execute, source=node1, target=node2, weight='reci_bandwidth'):
        # 计算路径上的链路带宽
        #print("path:", path)
        if len(path)>1:
            path_bandwidth = min(G_execute[u][v]['bandwidth'] for u, v in zip(path, path[1:]))
            k = k+1
            # 判断路径是否满足带宽要求
            if path_bandwidth >= b_r:
                #print("Shortest Path:", path)
                #print("Path Bandwidth:", path_bandwidth)
                break
            if k>=5:
                path = None
                break
        else:
            return path
    #print(path)
    return  path
#求两个节点间满足链路带宽的最短简单的链路时延最短的路径，并返回链路
def Get_Shortest_delay_path1(G_execute, node1, node2, b_r):
    k = 0
    for path in nx.shortest_simple_paths(G_execute, source=node1, target=node2, weight='penalty_factor'):
        # 计算路径上的链路带宽
        #print("path:", path)
        path1 = path
        if len(path)>1:
            path_bandwidth = min(G_execute[u][v]['bandwidth'] for u, v in zip(path, path[1:]))
            k = k+1
            # 判断路径是否满足带宽要求
            if path_bandwidth >= b_r:
                #print("Shortest Path:", path)
                #print("Path Bandwidth:", path_bandwidth)
                break
            if k>=5:
                path = None
                break
        else:
            return path, path1
    #print(path)
    return  path, path1



#对于每一个VNF，在网络中找到部署它的最优的节点
#[['BandwidthShaper'], [38, 39, 46]]

def Greedy_find_best_node1(G_initial,G_execute, vnf, location, b_r):
    #假设VNF可以部署在所有的节点上
    vnf_place_nodes = []
    #VNF的需求
    vnf_software = vnf[0][0]
    vnf_cpu = vnf[1][0]
    vnf_mem = vnf[1][1]
    vnf_software_sto = vnf[1][2]

    #成本函数的定义为 10/3*x+1/3

    #记录每个VNF放置在每个节点上的时延、资源使用成本以及软件迁移成本
    ##包含CPU使用成本，MEM使用成本,STO使用成本，STO迁移成本，节点上的处理时延
    #如果节点不满足条件，则将节点上的成本和时延以及迁移成本定义为无穷大
    for idex, node in enumerate(G_execute.nodes):
        place_node  = []
        #print(G_execute.nodes[node]['software'])
        if vnf_software in G_execute.nodes[node]['software']:
            if G_execute.nodes[node]['cpu'] >= vnf_cpu and G_execute.nodes[node]['memory'] >= vnf_mem:
                #计算cpu的利用率
                cpu_uti = (G_initial.nodes[node]['cpu']-G_execute.nodes[node]['cpu'])/G_initial.nodes[node]['cpu']
                mem_uti = (G_initial.nodes[node]['memory']-G_execute.nodes[node]['memory'])/G_initial.nodes[node]['memory']
                sto_uti = (G_initial.nodes[node]['storage'] - G_execute.nodes[node]['storage']) / G_initial.nodes[node]['storage']

                # 计算cpu资源使用成本
                if cpu_uti <= 0.2:
                    cpu_cost = vnf_cpu * 1
                elif 0.2 < cpu_uti<= 0.8:
                    cpu_cost = vnf_cpu * ((10.0/3)*cpu_uti+1.0/3)
                else:
                    cpu_cost = vnf_cpu * 3

                # 计算mem资源使用成本
                if mem_uti <= 0.2:
                    mem_cost = vnf_mem * 1
                elif 0.2 < mem_uti<= 0.8:
                    mem_cost = vnf_mem * ((10.0/3)*mem_uti+1.0/3)
                else:
                    mem_cost = vnf_mem * 3
                place_node.append(node)
                place_node.append([cpu_cost, mem_cost, 0, 0, G_execute.nodes[node]['process_d']])
                place_node.append(0)
            else:
                #包含CPU使用成本，MEM使用成本,STO使用成本，STO迁移成本，节点上的处理时延
                place_node.append(node)
                place_node.append([100000, 100000, 0, 0, 100000])
                place_node.append(0)

        else:
            #判断节点上计算资源，内存，和存储资源是否满足需求
            if G_execute.nodes[node]['cpu'] >= vnf_cpu and G_execute.nodes[node]['memory'] >= vnf_mem and G_execute.nodes[node]['storage'] >= vnf_software_sto:
            #如果满足需求则将最近的软件迁移到该节点上来，计算迁移成本
                cpu_uti = (G_initial.nodes[node]['cpu'] - G_execute.nodes[node]['cpu']) / G_initial.nodes[node]['cpu']
                mem_uti = (G_initial.nodes[node]['memory'] - G_execute.nodes[node]['memory']) / G_initial.nodes[node]['memory']
                sto_uti = (G_initial.nodes[node]['storage'] - G_execute.nodes[node]['storage']) / G_initial.nodes[node]['storage']
                # 计算cpu资源使用成本
                if cpu_uti <= 0.2:
                    cpu_cost = vnf_cpu * 1
                elif 0.2 < cpu_uti <= 0.8:
                    cpu_cost = vnf_cpu * ((10.0 / 3) * cpu_uti + 1.0 / 3)
                else:
                    cpu_cost = vnf_cpu * 3

                # 计算mem资源使用成本
                if mem_uti <= 0.2:
                    mem_cost = vnf_mem * 1
                elif 0.2 < mem_uti <= 0.8:
                    mem_cost = vnf_mem * ((10.0 / 3) * mem_uti + 1.0 / 3)
                else:
                    mem_cost = vnf_mem * 3

                if sto_uti <= 0.2:
                    sto_cost = vnf_software_sto * 1
                elif 0.2 < sto_uti <= 0.8:
                    sto_cost = vnf_software_sto * ((10.0 / 3) * sto_uti + 1.0 / 3)
                else:
                    sto_cost = vnf_software_sto * 3

                #获得vnf_software所在的物理节点

                vnf_software_nodes = Get_Network_Nodes(G_execute, vnf_software)
                vnf_software_migrate_delay = Get_Shortest_delay(G_execute, vnf_software_nodes[0],node)
                vnf_software_migrate_from_node = vnf_software_nodes[0]
                #计算从vnf_software_nodes到现在节点的最短距离，并返回最短距离对用的成本
                for vnf_software_node in vnf_software_nodes:
                    if Get_Shortest_delay(G_execute,vnf_software_node,node) <= vnf_software_migrate_delay:
                        vnf_software_migrate_delay = Get_Shortest_delay(G_execute,vnf_software_node,node)
                        vnf_software_migrate_from_node = vnf_software_node
                place_node.append(node)
                place_node.append([cpu_cost, mem_cost,sto_cost, vnf_software_migrate_delay, G_execute.nodes[node]['process_d']])
                place_node.append(vnf_software_migrate_from_node)
            #需要记录哪个节点上有软件资源
            else:
                place_node.append(node)
                place_node.append([100000, 100000, 0, 0, 100000])
                place_node.append(0)

        vnf_place_nodes.append(place_node)



    print("vnf_place_nodes:",vnf_place_nodes)
    # 计算处理时延
    # for item in vnf_place_nodes:
    # 求出值最小的节点，并记录是从哪里迁移过来的
    greedy_list = []
    for item in vnf_place_nodes:
        #print("item:",item)
        cost1 = (item[1][0] + item[1][1] +item[1][2]) / 2.0
        cost2 = item[1][3]
        cost3 = (item[1][0] + item[1][1]) / 2.0
        if item[1][2]!=0:
            cost3 = 3
        delay = item[1][4]
        greedy_list.append([item[0], cost3, cost2, delay, cost1+cost2 +delay, item[2], item[1][2]])
    #print(greedy_list)

    #根据列表中间的数字对列表进行排序,从低到高的顺序排序
    greedy_sorted_list = sorted(greedy_list, key=lambda x: x[4])
    #print(greedy_sorted_list)
    #print(greedy_sorted_list[0][0])

    greedy_best_node1 = greedy_sorted_list[0][0]
    print("greedy_best_node1_info:", greedy_sorted_list[0])


    #计算最好的节点和原来放置的节点间满足条件最好的链路，时延最短
    #
    greedy_best_link1 = Get_Shortest_delay_path(G_execute, location, greedy_best_node1, b_r)
    #print(greedy_best_link1)


    # print(G.nodes[node]['cpu'])
        # print(G.nodes[node]['memory'])
        # print(G.nodes[node]['storage'])
        # print(G.nodes[node]['domain'])
        # print(G.nodes[node]['software'])
        # print(G.nodes[node]['process_d'])
        # print(G.nodes[node]['cpu_cost'])
        # print(G.nodes[node]['mem_cost'])
        # print(G.nodes[node]['sto_cost'])





    return greedy_sorted_list[0], greedy_best_link1


#随机返回节点的集合和链路的集合
def Random_find_suitable_node1(G_initial, G_execute, vnf, location, b_r):
    #假设VNF可以部署在所有的节点上
    vnf_place_nodes = []
    #VNF的需求
    vnf_software = vnf[0][0]
    vnf_cpu = vnf[1][0]
    vnf_mem = vnf[1][1]
    vnf_software_sto = vnf[1][2]

    #成本函数的定义为 10/3*x+1/3

    #记录每个VNF放置在每个节点上的时延、资源使用成本以及软件迁移成本
    ##包含CPU使用成本，MEM使用成本,STO使用成本，STO迁移成本，节点上的处理时延
    #如果节点不满足条件，则将节点上的成本和时延以及迁移成本定义为无穷大
    for idex, node in enumerate(G_execute.nodes):
        place_node  = []
        #print(G_execute.nodes[node]['software'])
        if vnf_software in G_execute.nodes[node]['software']:
            if G_execute.nodes[node]['cpu'] >= vnf_cpu and G_execute.nodes[node]['memory'] >= vnf_mem:
                #计算cpu的利用率
                cpu_uti = (G_initial.nodes[node]['cpu']-G_execute.nodes[node]['cpu'])/G_initial.nodes[node]['cpu']
                mem_uti = (G_initial.nodes[node]['memory']-G_execute.nodes[node]['memory'])/G_initial.nodes[node]['memory']
                sto_uti = (G_initial.nodes[node]['storage'] - G_execute.nodes[node]['storage']) / G_initial.nodes[node]['storage']

                # 计算cpu资源使用成本
                if cpu_uti <= 0.2:
                    cpu_cost = vnf_cpu * 1
                elif 0.2 < cpu_uti<= 0.8:
                    cpu_cost = vnf_cpu * ((10.0/3)*cpu_uti+1.0/3)
                else:
                    cpu_cost = vnf_cpu * 3

                # 计算mem资源使用成本
                if mem_uti <= 0.2:
                    mem_cost = vnf_mem * 1
                elif 0.2 < mem_uti<= 0.8:
                    mem_cost = vnf_mem * ((10.0/3)*mem_uti+1.0/3)
                else:
                    mem_cost = vnf_mem * 3
                place_node.append(node)
                place_node.append([cpu_cost, mem_cost, 0, 0, G_execute.nodes[node]['process_d']])
                place_node.append(0)
            else:
                #包含CPU使用成本，MEM使用成本,STO使用成本，STO迁移成本，节点上的处理时延
                place_node.append(node)
                place_node.append([100000, 100000, 0, 0, 100000])
                place_node.append(0)

        else:
            #判断节点上计算资源，内存，和存储资源是否满足需求
            if G_execute.nodes[node]['cpu'] >= vnf_cpu and G_execute.nodes[node]['memory'] >= vnf_mem and G_execute.nodes[node]['storage'] >= vnf_software_sto:
            #如果满足需求则将最近的软件迁移到该节点上来，计算迁移成本
                cpu_uti = (G_initial.nodes[node]['cpu'] - G_execute.nodes[node]['cpu']) / G_initial.nodes[node]['cpu']
                mem_uti = (G_initial.nodes[node]['memory'] - G_execute.nodes[node]['memory']) / G_initial.nodes[node]['memory']
                sto_uti = (G_initial.nodes[node]['storage'] - G_execute.nodes[node]['storage']) / G_initial.nodes[node]['storage']
                # 计算cpu资源使用成本
                if cpu_uti <= 0.2:
                    cpu_cost = vnf_cpu * 1
                elif 0.2 < cpu_uti <= 0.8:
                    cpu_cost = vnf_cpu * ((10.0 / 3) * cpu_uti + 1.0 / 3)
                else:
                    cpu_cost = vnf_cpu * 3

                # 计算mem资源使用成本
                if mem_uti <= 0.2:
                    mem_cost = vnf_mem * 1
                elif 0.2 < mem_uti <= 0.8:
                    mem_cost = vnf_mem * ((10.0 / 3) * mem_uti + 1.0 / 3)
                else:
                    mem_cost = vnf_mem * 3

                if sto_uti <= 0.2:
                    sto_cost = vnf_software_sto * 1
                elif 0.2 < sto_uti <= 0.8:
                    sto_cost = vnf_software_sto * ((10.0 / 3) * sto_uti + 1.0 / 3)
                else:
                    sto_cost = vnf_software_sto * 3

                #获得vnf_software所在的物理节点

                vnf_software_nodes = Get_Network_Nodes(G_execute, vnf_software)
                vnf_software_migrate_delay = Get_Shortest_delay(G_execute, vnf_software_nodes[0],node)
                vnf_software_migrate_from_node = vnf_software_nodes[0]
                #计算从vnf_software_nodes到现在节点的最短距离，并返回最短距离对用的成本
                for vnf_software_node in vnf_software_nodes:
                    if Get_Shortest_delay(G_execute,vnf_software_node,node) <= vnf_software_migrate_delay:
                        vnf_software_migrate_delay = Get_Shortest_delay(G_execute,vnf_software_node,node)
                        vnf_software_migrate_from_node = vnf_software_node
                place_node.append(node)
                place_node.append([cpu_cost, mem_cost,sto_cost, vnf_software_migrate_delay, G_execute.nodes[node]['process_d']])
                place_node.append(vnf_software_migrate_from_node)
            #需要记录哪个节点上有软件资源
            else:
                place_node.append(node)
                place_node.append([100000, 100000, 0, 0, 100000])
                place_node.append(0)

        vnf_place_nodes.append(place_node)


    #[1, [38, 39, 0, 0, 35], 0]
    #print("vnf_place_nodes:",vnf_place_nodes)
    # 计算处理时延
    # for item in vnf_place_nodes:
    # 求出值最小的节点，并记录是从哪里迁移过来的
    greedy_list = []
    for item in vnf_place_nodes:
        #print("item:",item)
        cost1 = (item[1][0] + item[1][1] +item[1][2]) / 2.0
        cost2 = item[1][3]
        cost3 = (item[1][0] + item[1][1]) / 2.0
        if item[1][2]!=0:
            cost3 = 3
        delay = item[1][4]
        greedy_list.append([item[0], cost3, cost2, delay, cost1+cost2 +delay, item[2], item[1][2]])
    #print(greedy_list)

    #根据列表中间的数字对列表进行排序,从低到高的顺序排序
    #[1, 38.5, 0, 35, 73.5, 0]
    greedy_sorted_list = sorted(greedy_list, key=lambda x: x[4])
    #print(greedy_sorted_list)
    #print(greedy_sorted_list[0][0])

    random_suitable_node_info = random.choice([x for x in greedy_sorted_list if x[4] < 1000])
    print("random_suitable_node_info:",random_suitable_node_info)

    random_suitable_node1 = random_suitable_node_info[0]



    #计算最好的节点和原来放置的节点间满足条件最好的链路，时延最短
    #
    greedy_best_link1 = Get_Shortest_delay_path(G_execute, location, random_suitable_node1, b_r)
    #print(greedy_best_link1)


    # print(G.nodes[node]['cpu'])
        # print(G.nodes[node]['memory'])
        # print(G.nodes[node]['storage'])
        # print(G.nodes[node]['domain'])
        # print(G.nodes[node]['software'])
        # print(G.nodes[node]['process_d'])
        # print(G.nodes[node]['cpu_cost'])
        # print(G.nodes[node]['mem_cost'])
        # print(G.nodes[node]['sto_cost'])





    return random_suitable_node_info, greedy_best_link1

#基于Bestfit返回部署的节点和部署的链路
def Bestfit_find_node1(G_initial, G_execute, vnf, location, b_r):
    #假设VNF可以部署在所有的节点上
    vnf_place_nodes = []
    #VNF的需求
    vnf_software = vnf[0][0]
    vnf_cpu = vnf[1][0]
    vnf_mem = vnf[1][1]
    vnf_software_sto = vnf[1][2]

    #成本函数的定义为 10/3*x+1/3

    #记录每个VNF放置在每个节点上的时延、资源使用成本以及软件迁移成本
    ##包含CPU使用成本，MEM使用成本,STO使用成本，STO迁移成本，节点上的处理时延
    #如果节点不满足条件，则将节点上的成本和时延以及迁移成本定义为无穷大
    for idex, node in enumerate(G_execute.nodes):
        place_node  = []
        #print(G_execute.nodes[node]['software'])
        if vnf_software in G_execute.nodes[node]['software']:
            if G_execute.nodes[node]['cpu'] >= vnf_cpu and G_execute.nodes[node]['memory'] >= vnf_mem:
                #计算cpu的利用率
                cpu_uti = (G_initial.nodes[node]['cpu']-G_execute.nodes[node]['cpu'])/G_initial.nodes[node]['cpu']
                mem_uti = (G_initial.nodes[node]['memory']-G_execute.nodes[node]['memory'])/G_initial.nodes[node]['memory']
                sto_uti = (G_initial.nodes[node]['storage'] - G_execute.nodes[node]['storage']) / G_initial.nodes[node]['storage']

                # 计算cpu资源使用成本
                if cpu_uti <= 0.2:
                    cpu_cost = vnf_cpu * 1
                elif 0.2 < cpu_uti<= 0.8:
                    cpu_cost = vnf_cpu * ((10.0/3)*cpu_uti+1.0/3)
                else:
                    cpu_cost = vnf_cpu * 3

                # 计算mem资源使用成本
                if mem_uti <= 0.2:
                    mem_cost = vnf_mem * 1
                elif 0.2 < mem_uti<= 0.8:
                    mem_cost = vnf_mem * ((10.0/3)*mem_uti+1.0/3)
                else:
                    mem_cost = vnf_mem * 3
                place_node.append(node)
                place_node.append([cpu_cost, mem_cost, 0, 0, G_execute.nodes[node]['process_d']])
                place_node.append(0)
            else:
                #包含CPU使用成本，MEM使用成本,STO使用成本，STO迁移成本，节点上的处理时延
                place_node.append(node)
                place_node.append([100000, 100000, 0, 0, 100000])
                place_node.append(0)

        else:
            #判断节点上计算资源，内存，和存储资源是否满足需求
            if G_execute.nodes[node]['cpu'] >= vnf_cpu and G_execute.nodes[node]['memory'] >= vnf_mem and G_execute.nodes[node]['storage'] >= vnf_software_sto:
            #如果满足需求则将最近的软件迁移到该节点上来，计算迁移成本
                cpu_uti = (G_initial.nodes[node]['cpu'] - G_execute.nodes[node]['cpu']) / G_initial.nodes[node]['cpu']
                mem_uti = (G_initial.nodes[node]['memory'] - G_execute.nodes[node]['memory']) / G_initial.nodes[node]['memory']
                sto_uti = (G_initial.nodes[node]['storage'] - G_execute.nodes[node]['storage']) / G_initial.nodes[node]['storage']
                # 计算cpu资源使用成本
                if cpu_uti <= 0.2:
                    cpu_cost = vnf_cpu * 1
                elif 0.2 < cpu_uti <= 0.8:
                    cpu_cost = vnf_cpu * ((10.0 / 3) * cpu_uti + 1.0 / 3)
                else:
                    cpu_cost = vnf_cpu * 3

                # 计算mem资源使用成本
                if mem_uti <= 0.2:
                    mem_cost = vnf_mem * 1
                elif 0.2 < mem_uti <= 0.8:
                    mem_cost = vnf_mem * ((10.0 / 3) * mem_uti + 1.0 / 3)
                else:
                    mem_cost = vnf_mem * 3

                if sto_uti <= 0.2:
                    sto_cost = vnf_software_sto * 1
                elif 0.2 < sto_uti <= 0.8:
                    sto_cost = vnf_software_sto * ((10.0 / 3) * sto_uti + 1.0 / 3)
                else:
                    sto_cost = vnf_software_sto * 3



                vnf_software_nodes = Get_Network_Nodes(G_execute, vnf_software) #获得vnf_software所在的物理节点
                vnf_software_migrate_delay = Get_Shortest_delay(G_execute, vnf_software_nodes[0],node)
                vnf_software_migrate_from_node = vnf_software_nodes[0]
                #计算从vnf_software_nodes到现在节点的最短距离，并返回最短距离对用的成本
                for vnf_software_node in vnf_software_nodes:
                    if Get_Shortest_delay(G_execute,vnf_software_node,node) <= vnf_software_migrate_delay:
                        vnf_software_migrate_delay = Get_Shortest_delay(G_execute,vnf_software_node,node)
                        vnf_software_migrate_from_node = vnf_software_node
                place_node.append(node)
                place_node.append([cpu_cost, mem_cost,sto_cost, vnf_software_migrate_delay, G_execute.nodes[node]['process_d']])
                place_node.append(vnf_software_migrate_from_node)
            #需要记录哪个节点上有软件资源
            else:
                place_node.append(node)
                place_node.append([100000, 100000, 0, 0, 100000])
                place_node.append(0)

        vnf_place_nodes.append(place_node)



    #[1, [38, 39, 0, 0, 35], 0]
    #print("vnf_place_nodes:",vnf_place_nodes)
    # 计算处理时延
    # for item in vnf_place_nodes:
    # 求出值最小的节点，并记录是从哪里迁移过来的
    greedy_list = []
    for item in vnf_place_nodes:
        #print("item:",item)
        cost1 = (item[1][0] + item[1][1] +item[1][2]) / 2.0  #计算+内存+存储成本/2
        cost2 = item[1][3]  #迁移成本
        cost3 = (item[1][0] + item[1][1]) / 2.0 #计算+内存成本/2
        if item[1][2]!=0:
            cost3 = 3
            #print()
        delay = item[1][4]
        greedy_list.append([item[0], cost3, cost2, delay, cost1+cost2 +delay, item[2], item[1][2]])
    #print(greedy_list)

    #根据列表中间的数字对列表进行排序,从低到高的顺序排序
    #[1, 38.5, 0, 35, 73.5, 0]
    greedy_sorted_list = sorted(greedy_list, key=lambda x: x[4])
    #print("greedy_sorted_list:",greedy_sorted_list)
    #print(greedy_sorted_list[0][0])

    bestfit_list = copy.deepcopy(greedy_sorted_list)
    #print(bestfit_list)

    bestfit_node = greedy_sorted_list[0]


    #计算最好的节点和原来放置的节点间满足条件最好的链路，时延最短
    #
    for idex, node in enumerate(bestfit_list):
        greedy_best_link1 = Get_Shortest_delay_path(G_execute, location, node[0], b_r)
        #print(greedy_best_link1)
        #exit(0)
        if greedy_best_link1 == None:
            bestfit_list[idex][4] = 100000
        else:
            link_delay = 0
            for link_num in range(len(greedy_best_link1)-1):
                link_delay += G_execute.edges[(greedy_best_link1[link_num],greedy_best_link1[link_num+1])]["trans_d"]
            bestfit_list[idex][4] = bestfit_list[idex][4] + link_delay

    bestfit_list = sorted(bestfit_list, key=lambda x: x[4])
    #print("bestfit_list:",bestfit_list)
    bestfit_node = bestfit_list[0]
    bestfit_link = Get_Shortest_delay_path(G_execute, location, bestfit_node[0], b_r)

    #print(greedy_best_link1)





    # print(G.nodes[node]['cpu'])
        # print(G.nodes[node]['memory'])
        # print(G.nodes[node]['storage'])
        # print(G.nodes[node]['domain'])
        # print(G.nodes[node]['software'])
        # print(G.nodes[node]['process_d'])
        # print(G.nodes[node]['cpu_cost'])
        # print(G.nodes[node]['mem_cost'])
        # print(G.nodes[node]['sto_cost'])




    print("bestfit_node:",bestfit_node)
    return bestfit_node, bestfit_link

#基于SFCMAP获得部署的节点和最短的路径
def SFCMAP_find_node1(G_initial, G_execute, vnf, location, b_r):
    #假设VNF可以部署在所有的节点上
    vnf_place_nodes = []
    #VNF的需求
    vnf_software = vnf[0][0]
    vnf_cpu = vnf[1][0]
    vnf_mem = vnf[1][1]
    vnf_software_sto = vnf[1][2]

    #成本函数的定义为 10/3*x+1/3

    #记录每个VNF放置在每个节点上的时延、资源使用成本以及软件迁移成本
    ##包含CPU使用成本，MEM使用成本,STO使用成本，STO迁移成本，节点上的处理时延
    #如果节点不满足条件，则将节点上的成本和时延以及迁移成本定义为无穷大
    for idex, node in enumerate(G_execute.nodes):
        place_node  = []
        #print(G_execute.nodes[node]['software'])
        if vnf_software in G_execute.nodes[node]['software']:
            if G_execute.nodes[node]['cpu'] >= vnf_cpu and G_execute.nodes[node]['memory'] >= vnf_mem:
                #计算cpu的利用率
                cpu_uti = (G_initial.nodes[node]['cpu']-G_execute.nodes[node]['cpu'])/G_initial.nodes[node]['cpu']
                mem_uti = (G_initial.nodes[node]['memory']-G_execute.nodes[node]['memory'])/G_initial.nodes[node]['memory']
                sto_uti = (G_initial.nodes[node]['storage'] - G_execute.nodes[node]['storage']) / G_initial.nodes[node]['storage']

                # 计算cpu资源使用成本
                if cpu_uti <= 0.2:
                    cpu_cost = vnf_cpu * 1
                elif 0.2 < cpu_uti<= 0.8:
                    cpu_cost = vnf_cpu * ((10.0/3)*cpu_uti+1.0/3)
                else:
                    cpu_cost = vnf_cpu * 3

                # 计算mem资源使用成本
                if mem_uti <= 0.2:
                    mem_cost = vnf_mem * 1
                elif 0.2 < mem_uti<= 0.8:
                    mem_cost = vnf_mem * ((10.0/3)*mem_uti+1.0/3)
                else:
                    mem_cost = vnf_mem * 3
                place_node.append(node)
                place_node.append([cpu_cost, mem_cost, 0, 0, G_execute.nodes[node]['penalty_factor']])
                place_node.append(0)
            else:
                #包含CPU使用成本，MEM使用成本,STO使用成本，STO迁移成本，节点上的处理时延
                place_node.append(node)
                place_node.append([100000, 100000, 0, 0, 100000])
                place_node.append(0)

        else:
            #判断节点上计算资源，内存，和存储资源是否满足需求
            if G_execute.nodes[node]['cpu'] >= vnf_cpu and G_execute.nodes[node]['memory'] >= vnf_mem and G_execute.nodes[node]['storage'] >= vnf_software_sto:
            #如果满足需求则将最近的软件迁移到该节点上来，计算迁移成本
                cpu_uti = (G_initial.nodes[node]['cpu'] - G_execute.nodes[node]['cpu']) / G_initial.nodes[node]['cpu']
                mem_uti = (G_initial.nodes[node]['memory'] - G_execute.nodes[node]['memory']) / G_initial.nodes[node]['memory']
                sto_uti = (G_initial.nodes[node]['storage'] - G_execute.nodes[node]['storage']) / G_initial.nodes[node]['storage']
                # 计算cpu资源使用成本

                if cpu_uti <= 0.2:
                    cpu_cost = vnf_cpu * 1
                elif 0.2 < cpu_uti <= 0.8:
                    cpu_cost = vnf_cpu * ((10.0 / 3) * cpu_uti + 1.0 / 3)
                else:
                    cpu_cost = vnf_cpu * 3

                # 计算mem资源使用成本
                if mem_uti <= 0.2:
                    mem_cost = vnf_mem * 1
                elif 0.2 < mem_uti <= 0.8:
                    mem_cost = vnf_mem * ((10.0 / 3) * mem_uti + 1.0 / 3)
                else:
                    mem_cost = vnf_mem * 3

                if sto_uti <= 0.2:
                    sto_cost = vnf_software_sto * 1
                elif 0.2 < sto_uti <= 0.8:
                    sto_cost = vnf_software_sto * ((10.0 / 3) * sto_uti + 1.0 / 3)
                else:
                    sto_cost = vnf_software_sto * 3



                vnf_software_nodes = Get_Network_Nodes(G_execute, vnf_software) #获得vnf_software所在的物理节点
                vnf_software_migrate_delay = Get_Shortest_delay(G_execute, vnf_software_nodes[0],node)
                vnf_software_migrate_from_node = vnf_software_nodes[0]
                #计算从vnf_software_nodes到现在节点的最短距离，并返回最短距离对用的成本
                for vnf_software_node in vnf_software_nodes:
                    if Get_Shortest_delay(G_execute,vnf_software_node,node) <= vnf_software_migrate_delay:
                        vnf_software_migrate_delay = Get_Shortest_delay(G_execute,vnf_software_node,node)
                        vnf_software_migrate_from_node = vnf_software_node
                place_node.append(node)
                place_node.append([cpu_cost, mem_cost,sto_cost, vnf_software_migrate_delay, G_execute.nodes[node]['penalty_factor']])
                place_node.append(vnf_software_migrate_from_node)
            #需要记录哪个节点上有软件资源
            else:
                place_node.append(node)
                place_node.append([100000, 100000, 0, 0, 100000])
                place_node.append(0)

        vnf_place_nodes.append(place_node)



    #[1, [38, 39, 0, 0, 35], 0]
    #print("vnf_place_nodes:",vnf_place_nodes)
    # 计算处理时延
    # for item in vnf_place_nodes:
    # 求出值最小的节点，并记录是从哪里迁移过来的
    greedy_list = []
    for item in vnf_place_nodes:
        #print("item:",item)
        cost1 = (item[1][0] + item[1][1] + item[1][2]) / 2.0
        cost2 = item[1][3]
        cost3 = (item[1][0] + item[1][1]) / 2.0
        if item[1][2]!=0:
            cost3 = 3
        delay = item[1][4]
        greedy_list.append([item[0], cost3, cost2, delay, cost1+cost2 +delay, item[2], item[1][2]])
    #print(greedy_list)

    #根据列表中间的数字对列表进行排序,从低到高的顺序排序
    #[1, 38.5, 0, 35, 73.5, 0]
    greedy_sorted_list = sorted(greedy_list, key=lambda x: x[4])
    #print(greedy_sorted_list)
    #print(greedy_sorted_list[0][0])

    #print(bestfit_list)

    #计算最好的节点和原来放置的节点间满足条件最好的链路，时延最短
    #
    greedy_best_node1 = greedy_sorted_list[0][0]
    #print("sfcmap_best_node1_info:", greedy_sorted_list[0])

    # 计算最好的节点和原来放置的节点间满足条件最好的链路，时延最短
    #
    greedy_best_link, greedy_best_link1 = Get_Shortest_delay_path1(G_execute, location, greedy_best_node1, b_r)
    # print(greedy_best_link1)

    # print(G.nodes[node]['cpu'])
    # print(G.nodes[node]['memory'])
    # print(G.nodes[node]['storage'])
    # print(G.nodes[node]['domain'])
    # print(G.nodes[node]['software'])
    # print(G.nodes[node]['process_d'])
    # print(G.nodes[node]['cpu_cost'])
    # print(G.nodes[node]['mem_cost'])
    # print(G.nodes[node]['sto_cost'])

    return greedy_sorted_list[0], greedy_best_link, greedy_best_link1
    #print(greedy_best_link1)





    # print(G.nodes[node]['cpu'])
        # print(G.nodes[node]['memory'])
        # print(G.nodes[node]['storage'])
        # print(G.nodes[node]['domain'])
        # print(G.nodes[node]['software'])
        # print(G.nodes[node]['process_d'])
        # print(G.nodes[node]['cpu_cost'])
        # print(G.nodes[node]['mem_cost'])
        # print(G.nodes[node]['sto_cost'])
def AHR_Computerpower(list_set, num_indicators):
    #list_set是一个列表集合,列表的每一个元素代表了节点上的信息，比如第一个元素element_info
    #element_info是一个列表，其第一个值是元素的序号，第二个值是一个列表，列表里有这个元素（节点或边）上的信息，需要取出这个信息，对这个信息构建层次矩阵，有多少个指标构建多少个层次矩阵
    #对构建的层次矩阵进行一致性分析，如果满足一致性分析，则求出最大特征根对应的特征向量否则的话就重新构造层次矩阵直到满足一致性为止，然后再求出最大特征根对应的最大向量
    #通过求出的每个矩阵的最大特征向量，计算出每个元素的度量值，以列表形式返回，列表中应包含节点的索引和节点的度量值


    if num_indicators == 8:
        #初始化第一层矩阵
        A_Matrix = []
        #初始化第二层矩阵
        B_Matrix = []
        for i in range(num_indicators):
             B_Matrix.append([])
        #np.eye(8)
        #构造第一层矩阵，代表不同指标之间的关系，属于定性分析
        #cpu利用率 mem利用率 sto利用率 sto迁移成本 1/(cpu剩余资源+非常小的数)  1/mem剩余资源  1/storage剩余资源  处理时延
        # A_Matrix = [[1, 1, 1/2, 1/2, 1/2, 1/2, 1/2, 1/3],
        #             [1, 1, 1/2, 1/2, 1/2, 1/2, 1/2, 1/3],
        #             [2, 2, 1,   2,   1/2, 1/2, 1/2, 1/3],
        #             [2, 2, 1/2, 1,   1/2, 1/2, 1/2, 1/4],
        #             [2, 2, 2,   2,   1,   1,   1/2, 1/4],
        #             [2, 2, 2,   2,   1,   1,   1/2, 1/4],
        #             [2, 2, 2,   2,   2,   2,   1,   1/3],
        #             [3, 3, 3,   4,   4,   4,   3,   1]]

        #feasible solution1
        A_Matrix = [[1,  1,   1,   1/9, 7, 7, 7,   1/9],
                    [1,  1,   1,   1/9, 7, 7, 7,   1/9],
                    [1,  1,   1,   1/9, 7, 7, 7,   1/9],
                    [9,  9,   9,   1,   9, 9, 9,   1/9],
                    [1/7,1/7, 1/7, 1/9, 1, 1, 1/2, 1/9],
                    [1/7,1/7, 1/7, 1/9, 1, 1, 1/2, 1/9],
                    [1/7,1/7, 1/7, 1/9, 2, 2, 1,   1/9],
                    [9,  9,   9,   9,   9, 9, 9,   1]]
        # feasible solution2
        A_Matrix = [[1, 1, 1, 1 / 8, 7, 7, 7, 1 / 8],
                    [1, 1, 1, 1 / 8, 7, 7, 7, 1 / 8],
                    [1, 1, 1, 1 / 8, 7, 7, 7, 1 / 8],
                    [8, 8, 8, 1, 8, 8, 8, 1 / 8],
                    [1 / 7, 1 / 7, 1 / 7, 1 / 8, 1, 1, 1 / 2, 1 / 8],
                    [1 / 7, 1 / 7, 1 / 7, 1 / 8, 1, 1, 1 / 2, 1 / 8],
                    [1 / 7, 1 / 7, 1 / 7, 1 / 8, 2, 2, 1, 1 / 8],
                    [8, 8, 8, 8, 8, 8, 8, 1]]
        # feasible solution  xishu 11  时延173
        A_Matrix = [[1,  1,  1/5, 1/6, 7, 7, 7,   1/9],
                    [1,  1,  1/5, 1/6, 7, 7, 7,   1/9],
                    [5,  5,  1,   5/6, 8, 8, 8,   1/9],
                    [6,  6,  6/5, 1,   9, 9, 9,   1/9],
                    [1/7,1/7,1/8, 1/9, 1, 1, 1/2, 1/9],
                    [1/7,1/7,1/8, 1/9, 1, 1, 1/2, 1/9],
                    [1/7,1/7,1/8, 1/9, 2, 2, 1,   1/9],
                    [9,  9,  9,   9,   9, 9, 9,   1]]
        # feasible solution xishu 15 时延173
        A_Matrix = [[1,   1,    1/3,   1/4,   6,   6,   5,   1/9],
                    [1,   1,    1/3,   1/4,   6,   6,   5,   1/9],
                    [3,   3,    1,     4/3,   7,   7,   6,   1/9],
                    [4,   4,    3/4,   1,     8,   8,   9,   1/9],
                    [1/6, 1/6,  1/7,   1/8,   1,   1,   1/2, 1/9],
                    [1/6, 1/6,  1/7,   1/8,   1,   1,   1/2, 1/9],
                    [1/5, 1/5,  1/6,   1/9,   2,   2,   1,   1/9],
                    [9,   9,    9,     9,     9,   9,   9,   1]]
        # feasible solution xishu 11 174
        A_Matrix = [[1, 1, 1 / 5, 1 / 4, 6, 6, 5, 1 / 9],
                    [1, 1, 1 / 5, 1 / 4, 6, 6, 5, 1 / 9],
                    [5, 5, 1, 4 / 5, 7, 7, 6, 1 / 9],
                    [4, 4, 5 / 4, 1, 8, 8, 9, 1 / 9],
                    [1 / 6, 1 / 6, 1 / 7, 1 / 8, 1, 1, 1 / 2, 1 / 9],
                    [1 / 6, 1 / 6, 1 / 7, 1 / 8, 1, 1, 1 / 2, 1 / 9],
                    [1 / 5, 1 / 5, 1 / 6, 1 / 9, 2, 2, 1, 1 / 9],
                    [9, 9, 9, 9, 9, 9, 9, 1]]
        # feasible solution xishu 11 173 48 2.1
        A_Matrix = [[1,     1,      1 / 5,      1 / 6,      7,      7,      6,      1 / 9],
                    [1,     1,      1 / 5,      1 / 6,      7,      7,      6,      1 / 9],
                    [5,     5,      1,          6 / 5,      8,      8,      7,      1 / 9],
                    [6,     6,      5 / 6,      1,          9,      9,      8,      1 / 9],
                    [1 / 7, 1 / 7,  1 / 8,      1 / 9,      1,      1,      1 / 2,  1 / 9],
                    [1 / 7, 1 / 6,  1 / 8,      1 / 9,      1,      1,      1 / 2,  1 / 9],
                    [1 / 7, 1 / 6,  1 / 7,      1 / 8,      2,      2,      1,      1 / 9],
                    [9,     9,      9,          9,          9,      9,      9,      1]]


        # A_Matrix = [[1, 1, 1 / 5, 1 / 5, 7, 7, 6, 1 / 9],
        #             [1, 1, 1 / 5, 1 / 5, 7, 7, 6, 1 / 9],
        #             [5, 5, 1, 5, 8, 8, 7, 1 / 9],
        #             [5, 5, 5, 1, 9, 9, 8, 1 / 9],
        #             [1 / 7, 1 / 7, 1 / 8, 1 / 9, 1, 1, 1 / 2, 1 / 9],
        #             [1 / 7, 1 / 6, 1 / 8, 1 / 9, 1, 1, 1 / 2, 1 / 9],
        #             [1 / 7, 1 / 6, 1 / 7, 1 / 8, 2, 2, 1, 1 / 9],
        #             [9, 9, 9, 9, 9, 9, 9, 1]]


        #print("A_Matrix:",A_Matrix)
        #exit(0)
        #构造第二层矩阵,首先要计算各个节点中各种资源的比率，根据各种资源的比率构造比对矩阵
        #print("list_set:",list_set)

        for element_info in list_set:
            #print("element_info:",element_info)
            for i, element in enumerate(element_info[1]):
             #   print("element:",element)
                B_Matrix[i].append(element)
        #print("B_Matrix:",B_Matrix)
        #exit(0)

        C_Matrix = []
        for i in range(num_indicators):
            C_Matrix.append(np.eye(len(list_set)))
        for c_i,item in enumerate(B_Matrix):
            #ITEM是一个列表，计算列表中[0.1,0.2,0.6,0.7,0.9]
            #计算每两个元素之间的比率，
            for x_item in range(len(list_set)):
                for y_item in range(len(list_set)):
                    #C_Matrix[c_i][x_item][y_item] = 1/(item[x_item]/(item[y_item]+ϵ)+ϵ)
                    C_Matrix[c_i][x_item][y_item] = item[x_item] / (item[y_item] + ϵ)
        #print("C_Matrix:",len(C_Matrix[4]))

        #A矩阵是构造的定性的矩阵
        #B矩阵是获得的数据矩阵
        #C矩阵是构造的定量的矩阵

        #判断A矩阵的一致性
        #判断C矩阵的一致性

        #获得A矩阵的最大的特征根对应的特征向量
        A_eigenvalues, A_eigenvectors = np.linalg.eig(A_Matrix)
        # 找到最大特征值的索引
        A_max_eigenvalue_index = np.argmax(A_eigenvalues)
        # 获取最大特征值和对应的特征向量
        A_max_eigenvalue = A_eigenvalues[A_max_eigenvalue_index]
        A_max_eigenvector = A_eigenvectors[:, A_max_eigenvalue_index]
        norm = np.linalg.norm(A_max_eigenvector)
        A_max_eigenvector = A_max_eigenvector / norm
        A_max_eigenvector = np.abs(A_max_eigenvector)
        #print("A_max_eigenvector:",A_max_eigenvector)
        #获得C矩阵的各个特征根对应的特征向量
        C_Matrix_eigenvalue = []
        C_Matrix_eigenvector = []

        #获得每个节点的算力度量值
        for item in C_Matrix:
            c_eigenvalues, c_eigenvectors = np.linalg.eig(item)
            c_max_eigenvalue_index = np.argmax(c_eigenvalues)
            c_max_eigenvalue = c_eigenvalues[c_max_eigenvalue_index]
            c_max_eigenvector = c_eigenvectors[:, c_max_eigenvalue_index]
            C_Matrix_eigenvalue.append(c_max_eigenvalue)
            C_Matrix_eigenvector.append(c_max_eigenvector)
        for i, item in enumerate( C_Matrix_eigenvector):
            norm = np.linalg.norm( C_Matrix_eigenvector[i])
            C_Matrix_eigenvector[i] = C_Matrix_eigenvector[i]/norm
            C_Matrix_eigenvector[i] = np.abs(C_Matrix_eigenvector[i])
        #print("C_Matrix_eigenvector:",C_Matrix_eigenvector)

        D_Matrix = []

        for i in range(len(list_set)):
            D_Matrix.append([])
            for j in range(num_indicators):
                D_Matrix[i].append(C_Matrix_eigenvector[j][i]*A_max_eigenvector[j])
        #print("D_Matrix:",D_Matrix)
        #print("len(D_Ma):",len(D_Matrix))

        E_Matrix = []
        for item in D_Matrix:
            E_Matrix.append(np.sum(item))
        #print("E_Matrix:",E_Matrix)
        # exit(0)

        for idex, item in enumerate(E_Matrix):
            E_Matrix[idex] = E_Matrix[idex]*11
        #print("E_Matrix:", E_Matrix)

        return E_Matrix

    if num_indicators == 3:
        # 初始化第一层矩阵
        A_Matrix = []
        # 初始化第二层矩阵
        B_Matrix = []
        for i in range(num_indicators):
            B_Matrix.append([])
        # np.eye(8)
        # 构造第一层矩阵，代表不同指标之间的关系，属于定性分析
        # bandwidth利用率 1/bandwidth剩余资源 传输时延
        A_Matrix = [[1, 1/2, 1/3],
                    [2, 1,   1/4 ],
                    [3, 4,   1]]
        A_Matrix = [[1, 1 / 7, 1 / 5],
                    [7, 1, 1 / 9],
                    [5, 9, 1]]
        # A_Matrix = [[1,2,3],
        #             [1/2,1,4],
        #             [1/3,1/4,1]]

        # 构造第二层矩阵,首先要计算各个节点中各种资源的比率，根据各种资源的比率构造比对矩阵
        for element_info in list_set:
            # print(element_info)
            for i, element in enumerate(element_info[1]):
                # print(element)
                B_Matrix[i].append(element)
        #print("B_Matrix:", B_Matrix)

        C_Matrix = []
        for i in range(num_indicators):
            C_Matrix.append(np.eye(len(list_set)))
        for c_i, item in enumerate(B_Matrix):
            # ITEM是一个列表，计算列表中[0.1,0.2,0.6,0.7,0.9]
            # 计算每两个元素之间的比率，
            for x_item in range(len(list_set)):
                for y_item in range(len(list_set)):
                    #C_Matrix[c_i][x_item][y_item] = 1 / (item[x_item] / (item[y_item] + ϵ) + ϵ)
                    C_Matrix[c_i][x_item][y_item] = item[x_item] / (item[y_item] + ϵ)
        #print("C_Matrix:", len(C_Matrix[0]))

        # A矩阵是构造的定性的矩阵
        # B矩阵是获得的数据矩阵
        # C矩阵是构造的定量的矩阵

        # 判断A矩阵的一致性
        # 判断C矩阵的一致性

        # 获得A矩阵的最大的特征根对应的特征向量
        A_eigenvalues, A_eigenvectors = np.linalg.eig(A_Matrix)
        # 找到最大特征值的索引
        A_max_eigenvalue_index = np.argmax(A_eigenvalues)
        # 获取最大特征值和对应的特征向量
        A_max_eigenvalue = A_eigenvalues[A_max_eigenvalue_index]
        A_max_eigenvector = A_eigenvectors[:, A_max_eigenvalue_index]
        norm = np.linalg.norm(A_max_eigenvector)
        A_max_eigenvector = A_max_eigenvector / norm
        A_max_eigenvector = np.abs(A_max_eigenvector)
        #print("A_max_eigenvector:", A_max_eigenvector)
        # 获得C矩阵的各个特征根对应的特征向量
        C_Matrix_eigenvalue = []
        C_Matrix_eigenvector = []

        # 获得每个节点的算力度量值
        for item in C_Matrix:
            c_eigenvalues, c_eigenvectors = np.linalg.eig(item)
            c_max_eigenvalue_index = np.argmax(c_eigenvalues)
            c_max_eigenvalue = c_eigenvalues[c_max_eigenvalue_index]
            c_max_eigenvector = c_eigenvectors[:, c_max_eigenvalue_index]
            C_Matrix_eigenvalue.append(c_max_eigenvalue)
            C_Matrix_eigenvector.append(c_max_eigenvector)
        for i, item in enumerate(C_Matrix_eigenvector):
            norm = np.linalg.norm(C_Matrix_eigenvector[i])
            C_Matrix_eigenvector[i] = C_Matrix_eigenvector[i] / norm
            C_Matrix_eigenvector[i] = np.abs(C_Matrix_eigenvector[i])
        #print("C_Matrix_eigenvector:", C_Matrix_eigenvector)

        D_Matrix = []

        for i in range(len(list_set)):
            D_Matrix.append([])
            for j in range(num_indicators):
                D_Matrix[i].append(C_Matrix_eigenvector[j][i] * A_max_eigenvector[j])
        #print("D_Matrix:", D_Matrix)
        #print("len(D_Ma):", len(D_Matrix))

        E_Matrix = []
        for item in D_Matrix:
            E_Matrix.append(np.sum(item))
        #print("E_Matrix:", E_Matrix)


        return E_Matrix
def Generate_Multilayer_Network_NOAHR(G_initial,G_execute_initial,vnf_list,br):
    G_execute1 = copy.deepcopy(G_execute_initial)

    Multilayer_Network_List = []

    for vnf in vnf_list:
        # 假设VNF可以部署在所有的节点上
        vnf_place_nodes = []
        # VNF的需求
        vnf_software = vnf[0][0]  # vnf需要的软件
        vnf_cpu = vnf[1][0]  # vnf需要的计算资源
        vnf_mem = vnf[1][1]  # vnf需要的内存资源
        vnf_software_sto = vnf[1][2]  # vnf需要的存储资源

        for idex, node in enumerate(G_execute1.nodes):
            place_node = []
            # print(G_execute.nodes[node]['software'])
            if vnf_software in G_execute1.nodes[node]['software']:
                if G_execute1.nodes[node]['cpu'] >= vnf_cpu and G_execute1.nodes[node]['memory'] >= vnf_mem:
                    # 计算cpu的利用率
                    cpu_uti = (G_initial.nodes[node]['cpu'] - G_execute1.nodes[node]['cpu']) / G_initial.nodes[node][
                        'cpu']
                    mem_uti = (G_initial.nodes[node]['memory'] - G_execute1.nodes[node]['memory']) / \
                              G_initial.nodes[node]['memory']
                    sto_uti = (G_initial.nodes[node]['storage'] - G_execute1.nodes[node]['storage']) / \
                              G_initial.nodes[node]['storage']

                    cpu_remain = 1 / (G_execute1.nodes[node]['cpu'] + ϵ)
                    mem_remain = 1 / (G_execute1.nodes[node]['memory'] + ϵ)
                    sto_remain = 1 / (G_execute1.nodes[node]['storage'] + ϵ)

                    # 计算cpu资源使用成本
                    if cpu_uti <= 0.2:
                        cpu_cost = vnf_cpu * 1
                    elif 0.2 < cpu_uti <= 0.8:
                        cpu_cost = vnf_cpu * ((10.0 / 3) * cpu_uti + 1.0 / 3)
                    else:
                        cpu_cost = vnf_cpu * 3

                    # 计算mem资源使用成本
                    if mem_uti <= 0.2:
                        mem_cost = vnf_mem * 1
                    elif 0.2 < mem_uti <= 0.8:
                        mem_cost = vnf_mem * ((10.0 / 3) * mem_uti + 1.0 / 3)
                    else:
                        mem_cost = vnf_mem * 3

                    place_node.append(node)
                    # cpu的利用率，mem的利用率，sto的利用率，sto的迁移成本，cpu的剩余资源, mem的剩余资源，storage的剩余资源
                    place_node.append(
                        [(cpu_cost + mem_cost + 0) / 2.0, 0,
                         (cpu_cost + mem_cost + 0) / 2.0 + 0 + G_execute1.nodes[node][
                             "process_d"],
                         G_execute1.nodes[node]["process_d"]])
                    place_node.append(0)
                else:
                    # cpu的利用率，mem的利用率，sto的利用率，sto的迁移成本，包含CPU使用成本，MEM使用成本,STO使用成本，STO迁移成本，节点上的处理时延
                    place_node.append(node)
                    place_node.append([100000, 100000, 100000, G_execute1.nodes[node]["process_d"]])
                    place_node.append(0)

            else:
                # 判断节点上计算资源，内存，和存储资源是否满足需求
                if G_execute1.nodes[node]['cpu'] >= vnf_cpu and G_execute1.nodes[node]['memory'] >= vnf_mem and \
                        G_execute1.nodes[node]['storage'] >= vnf_software_sto:
                    # 如果满足需求则将最近的软件迁移到该节点上来，计算迁移成本
                    cpu_uti = (G_initial.nodes[node]['cpu'] - G_execute1.nodes[node]['cpu']) / G_initial.nodes[node][
                        'cpu']
                    mem_uti = (G_initial.nodes[node]['memory'] - G_execute1.nodes[node]['memory']) / \
                              G_initial.nodes[node]['memory']
                    sto_uti = (G_initial.nodes[node]['storage'] - G_execute1.nodes[node]['storage']) / \
                              G_initial.nodes[node]['storage']

                    cpu_remain = 1 / (G_execute1.nodes[node]['cpu'] + ϵ)
                    mem_remain = 1 / (G_execute1.nodes[node]['memory'] + ϵ)
                    sto_remain = 1 / (G_execute1.nodes[node]['storage'] + ϵ)
                    # 计算cpu资源使用成本

                    if cpu_uti <= 0.2:
                        cpu_cost = vnf_cpu * 1
                    elif 0.2 < cpu_uti <= 0.8:
                        cpu_cost = vnf_cpu * ((10.0 / 3) * cpu_uti + 1.0 / 3)
                    else:
                        cpu_cost = vnf_cpu * 3

                    # 计算mem资源使用成本
                    if mem_uti <= 0.2:
                        mem_cost = vnf_mem * 1
                    elif 0.2 < mem_uti <= 0.8:
                        mem_cost = vnf_mem * ((10.0 / 3) * mem_uti + 1.0 / 3)
                    else:
                        mem_cost = vnf_mem * 3

                    if sto_uti <= 0.2:
                        sto_cost = vnf_software_sto * 1
                    elif 0.2 < sto_uti <= 0.8:
                        sto_cost = vnf_software_sto * ((10.0 / 3) * sto_uti + 1.0 / 3)
                    else:
                        sto_cost = vnf_software_sto * 3

                    vnf_software_nodes = Get_Network_Nodes(G_execute1, vnf_software)  # 获得vnf_software所在的物理节点
                    # print("vnf_software_nodes:",vnf_software_nodes)
                    # print("node:",node)
                    vnf_software_migrate_delay = Get_Shortest_delay(G_execute1, vnf_software_nodes[0], node)
                    vnf_software_migrate_from_node = vnf_software_nodes[0]
                    # 计算从vnf_software_nodes到现在节点的最短距离，并返回最短距离对用的成本
                    for vnf_software_node in vnf_software_nodes:
                        if Get_Shortest_delay(G_execute1, vnf_software_node, node) <= vnf_software_migrate_delay:
                            vnf_software_migrate_delay = Get_Shortest_delay(G_execute1, vnf_software_node, node)
                            vnf_software_migrate_from_node = vnf_software_node
                    place_node.append(node)
                    place_node.append(
                        [(cpu_cost+mem_cost+sto_cost)/2.0, vnf_software_migrate_delay,(cpu_cost+mem_cost+sto_cost)/2.0+vnf_software_migrate_delay+G_execute1.nodes[node]["process_d"],
                         G_execute1.nodes[node]["process_d"]])
                    place_node.append(vnf_software_migrate_from_node)
                # 需要记录哪个节点上有软件资源
                else:
                    place_node.append(node)
                    # cpu的利用率，mem的利用率，sto的利用率，sto的迁移成本，cpu的剩余资源, mem的剩余资源，storage的剩余资源
                    place_node.append([100000, 100000, 100000, G_execute1.nodes[node]["process_d"]])
                    place_node.append(0)

            vnf_place_nodes.append(place_node)

        # vnf_place_nodes里面放置的每个节点上的信息，包括cpu的利用率，mem的利用率，sto的利用率，sto的迁移成本，cpu的剩余资源, mem的剩余资源，storage的剩余资源
        # 根据层次分析法对这些节点的算力进行度量,将每个节点的度量值放在每个物理节点的算力指标上面，并将这一层网络保存到多层网络中去
        # print("vnf_place_nodes:",vnf_place_nodes)
        #E = AHR_Computerpower(vnf_place_nodes, 8)
        # print("E:",E)
        for idex_node, compute_node in enumerate(G_execute1.nodes):
            G_execute1.nodes[compute_node]["compute_power"] = vnf_place_nodes[idex_node][1][2]
        # for idex_node, compute_node in enumerate(G_execute.nodes):
        #     print(G_execute.nodes[compute_node]["compute_power"])

        Multilayer_Network_List.append(G_execute1)
        G_execute1 = copy.deepcopy(G_execute_initial)

    # 对物理链路的算力进行度量
    map_edge = []
    sfc_map_edge = []

    for edge in G_execute1.edges:
        map_edge = []
        if G_execute1.edges[edge]['bandwidth'] >= br:
            edge_uti = (G_initial.edges[edge]['bandwidth'] - G_execute1.edges[edge]['bandwidth']) / \
                       G_initial.edges[edge]['bandwidth']
            edge_remain = 1 / (G_execute1.edges[edge]['bandwidth'] + ϵ)
            edge_delay = G_execute1.edges[edge]['trans_d']
            map_edge.append(edge)
            map_edge.append([edge_remain, edge_remain*100000+edge_delay, edge_delay])

        else:
            map_edge.append(edge)
            map_edge.append([100000, 100000, G_execute1.edges[edge]['trans_d']])

        sfc_map_edge.append(map_edge)
    # print("sfc_map_edge:",sfc_map_edge)
    #E1 = AHR_Computerpower(sfc_map_edge, 3)
    # print("E1:", E1)
    for layer_network in Multilayer_Network_List:
        # print(type(layer_network))
        for idex, edge in enumerate(layer_network.edges):
            layer_network.edges[edge]['compute_power'] = sfc_map_edge[idex][1][1]
    # print("11111")
    #
    # 用层次分析法对每条物理链路进行度量
    # 并把度量值赋值给每一层的网络
    # print(Multilayer_Network_List)
    Multilayer_Network = nx.Graph()
    mapping = dict()
    # 构建一个多层网络并返回，构建的多层网络要重新编号
    for idex_layer, layer_network in enumerate(Multilayer_Network_List):
        # print(type(layer_network))
        # print("layer_network_len:",len(layer_network.nodes))
        for node_num, layer_network_node in enumerate(layer_network.nodes):
            # print(layer_network.nodes[layer_network_node]['compute_power'])
            # print(layer_network.nodes[layer_network_node]['compute_power'])
            Multilayer_Network.add_node((idex_layer + 1) * 100 + layer_network_node,
                                        cpu=layer_network.nodes[layer_network_node]['cpu'],
                                        memory=layer_network.nodes[layer_network_node]['memory'],
                                        storage=layer_network.nodes[layer_network_node]['storage'],
                                        process_d=layer_network.nodes[layer_network_node]['process_d'],
                                        domain=layer_network.nodes[layer_network_node]['domain'],
                                        software=layer_network.nodes[layer_network_node]['software'],
                                        cpu_cost=layer_network.nodes[layer_network_node]['cpu_cost'],
                                        mem_cost=layer_network.nodes[layer_network_node]['mem_cost'],
                                        sto_cost=layer_network.nodes[layer_network_node]['sto_cost'],
                                        compute_power=layer_network.nodes[layer_network_node]['compute_power'],
                                        penalty_factor=layer_network.nodes[layer_network_node]['penalty_factor'])
            # print(Multilayer_Network.nodes[(idex_layer+1)*100+layer_network_node])
        # print(Multilayer_Network.nodes)
        for edge_num, layer_network_edge in enumerate(layer_network.edges()):
            # print(layer_network_edge)
            # print(layer_network_edge[0])
            Multilayer_Network.add_edge((idex_layer + 1) * 100 + layer_network_edge[0],
                                        (idex_layer + 1) * 100 + layer_network_edge[1],
                                        bandwidth=layer_network.edges[layer_network_edge]['reci_bandwidth'],
                                        reci_bandwidth=layer_network.edges[layer_network_edge]['reci_bandwidth'],
                                        penalty_factor=layer_network.edges[layer_network_edge]['penalty_factor'],
                                        trans_d=layer_network.edges[layer_network_edge]['trans_d'],
                                        type=layer_network.edges[layer_network_edge]['type'],
                                        compute_power=layer_network.edges[layer_network_edge]['compute_power'])

        # print( Multilayer_Network.edges)

    # print(Multilayer_Network.nodes)
    # print(Multilayer_Network.edges)
    # print(len(Multilayer_Network.edges))
    # 构建多层网络中的链接
    for idex_layer, layer_network in enumerate(Multilayer_Network_List):

        if idex_layer < len(Multilayer_Network_List) - 1:
            for item1, item2 in zip(layer_network.nodes, Multilayer_Network_List[idex_layer + 1].nodes):
                Multilayer_Network.add_edge((idex_layer + 1) * 100 + item1,
                                            (idex_layer + 2) * 100 + item2,
                                            bandwidth=100000,
                                            reci_bandwidth=0,
                                            penalty_factor=0,
                                            trans_d=0,
                                            type=3,
                                            compute_power=0)
    # print(len(Multilayer_Network.edges))
    # print(Multilayer_Network.edges)
    # draw_graph(Multilayer_Network)
    return Multilayer_Network

#针对一个业务功能链中每个VNF，构建一个多层的加权网络
def Genetate_Multilayer_Network(G_initial,G_execute_initial,vnf_list,br):
    #初始的网络
    #执行的网络
    G_execute1 = copy.deepcopy(G_execute_initial)

    Multilayer_Network_List = []

    for vnf in vnf_list:
        # 假设VNF可以部署在所有的节点上
        vnf_place_nodes = []
        # VNF的需求
        vnf_software = vnf[0][0] #vnf需要的软件
        vnf_cpu = vnf[1][0] #vnf需要的计算资源
        vnf_mem = vnf[1][1] #vnf需要的内存资源
        vnf_software_sto = vnf[1][2] #vnf需要的存储资源

        for idex, node in enumerate(G_execute1.nodes):
            place_node = []
            # print(G_execute.nodes[node]['software'])
            if vnf_software in G_execute1.nodes[node]['software']:
                if G_execute1.nodes[node]['cpu'] >= vnf_cpu and G_execute1.nodes[node]['memory'] >= vnf_mem:
                    # 计算cpu的利用率
                    cpu_uti = (G_initial.nodes[node]['cpu'] - G_execute1.nodes[node]['cpu']) / G_initial.nodes[node][
                        'cpu']
                    mem_uti = (G_initial.nodes[node]['memory'] - G_execute1.nodes[node]['memory']) / \
                              G_initial.nodes[node]['memory']
                    sto_uti = (G_initial.nodes[node]['storage'] - G_execute1.nodes[node]['storage']) / \
                              G_initial.nodes[node]['storage']

                    cpu_remain = 1/(G_execute1.nodes[node]['cpu']+ϵ)
                    mem_remain = 1/(G_execute1.nodes[node]['memory']+ϵ)
                    sto_remain = 1/(G_execute1.nodes[node]['storage']+ϵ)



                    # 计算cpu资源使用成本
                    if cpu_uti <= 0.2:
                        cpu_cost = vnf_cpu * 1
                    elif 0.2 < cpu_uti <= 0.8:
                        cpu_cost = vnf_cpu * ((10.0 / 3) * cpu_uti + 1.0 / 3)
                    else:
                        cpu_cost = vnf_cpu * 3

                    # 计算mem资源使用成本
                    if mem_uti <= 0.2:
                        mem_cost = vnf_mem * 1
                    elif 0.2 < mem_uti <= 0.8:
                        mem_cost = vnf_mem * ((10.0 / 3) * mem_uti + 1.0 / 3)
                    else:
                        mem_cost = vnf_mem * 3



                    place_node.append(node)
                    #cpu的利用率，mem的利用率，sto的利用率，sto的迁移成本，cpu的剩余资源, mem的剩余资源，storage的剩余资源
                    place_node.append([cpu_uti, mem_uti, 0, 0, cpu_remain, mem_remain, 1, G_execute1.nodes[node]["process_d"]])
                    place_node.append(0)
                else:
                    # cpu的利用率，mem的利用率，sto的利用率，sto的迁移成本，包含CPU使用成本，MEM使用成本,STO使用成本，STO迁移成本，节点上的处理时延
                    place_node.append(node)
                    place_node.append([1, 1, 1, 100, 1, 1, 1,G_execute1.nodes[node]["process_d"]])
                    place_node.append(0)

            else:
                # 判断节点上计算资源，内存，和存储资源是否满足需求
                if G_execute1.nodes[node]['cpu'] >= vnf_cpu and G_execute1.nodes[node]['memory'] >= vnf_mem and \
                        G_execute1.nodes[node]['storage'] >= vnf_software_sto:
                    # 如果满足需求则将最近的软件迁移到该节点上来，计算迁移成本
                    cpu_uti = (G_initial.nodes[node]['cpu'] - G_execute1.nodes[node]['cpu']) / G_initial.nodes[node][
                        'cpu']
                    mem_uti = (G_initial.nodes[node]['memory'] - G_execute1.nodes[node]['memory']) / \
                              G_initial.nodes[node]['memory']
                    sto_uti = (G_initial.nodes[node]['storage'] - G_execute1.nodes[node]['storage']) / \
                              G_initial.nodes[node]['storage']

                    cpu_remain = 1/(G_execute1.nodes[node]['cpu']+ϵ)
                    mem_remain = 1/(G_execute1.nodes[node]['memory']+ϵ)
                    sto_remain = 1/(G_execute1.nodes[node]['storage']+ϵ)
                    # 计算cpu资源使用成本

                    if cpu_uti <= 0.2:
                        cpu_cost = vnf_cpu * 1
                    elif 0.2 < cpu_uti <= 0.8:
                        cpu_cost = vnf_cpu * ((10.0 / 3) * cpu_uti + 1.0 / 3)
                    else:
                        cpu_cost = vnf_cpu * 3

                    # 计算mem资源使用成本
                    if mem_uti <= 0.2:
                        mem_cost = vnf_mem * 1
                    elif 0.2 < mem_uti <= 0.8:
                        mem_cost = vnf_mem * ((10.0 / 3) * mem_uti + 1.0 / 3)
                    else:
                        mem_cost = vnf_mem * 3

                    if sto_uti <= 0.2:
                        sto_cost = vnf_software_sto * 1
                    elif 0.2 < sto_uti <= 0.8:
                        sto_cost = vnf_software_sto * ((10.0 / 3) * sto_uti + 1.0 / 3)
                    else:
                        sto_cost = vnf_software_sto * 3

                    vnf_software_nodes = Get_Network_Nodes(G_execute1, vnf_software)  # 获得vnf_software所在的物理节点
                    # print("vnf_software_nodes:",vnf_software_nodes)
                    # print("node:",node)
                    vnf_software_migrate_delay = Get_Shortest_delay(G_execute1, vnf_software_nodes[0], node)
                    vnf_software_migrate_from_node = vnf_software_nodes[0]
                    # 计算从vnf_software_nodes到现在节点的最短距离，并返回最短距离对用的成本
                    for vnf_software_node in vnf_software_nodes:
                        if Get_Shortest_delay(G_execute1, vnf_software_node, node) <= vnf_software_migrate_delay:
                            vnf_software_migrate_delay = Get_Shortest_delay(G_execute1, vnf_software_node, node)
                            vnf_software_migrate_from_node = vnf_software_node
                    place_node.append(node)
                    place_node.append([cpu_uti, mem_uti, sto_uti, vnf_software_migrate_delay, cpu_remain, mem_remain, sto_remain, G_execute1.nodes[node]["process_d"]])
                    place_node.append(vnf_software_migrate_from_node)
                # 需要记录哪个节点上有软件资源
                else:
                    place_node.append(node)
                    # cpu的利用率，mem的利用率，sto的利用率，sto的迁移成本，cpu的剩余资源, mem的剩余资源，storage的剩余资源
                    place_node.append([1, 1, 1, 100, 1, 1, 1, G_execute1.nodes[node]["process_d"]])
                    place_node.append(0)

            vnf_place_nodes.append(place_node)

        #vnf_place_nodes里面放置的每个节点上的信息，包括cpu的利用率，mem的利用率，sto的利用率，sto的迁移成本，cpu的剩余资源, mem的剩余资源，storage的剩余资源
        #根据层次分析法对这些节点的算力进行度量,将每个节点的度量值放在每个物理节点的算力指标上面，并将这一层网络保存到多层网络中去
        #print("vnf_place_nodes:",vnf_place_nodes)
        E = AHR_Computerpower(vnf_place_nodes, 8)
        print("E:",E)
        for idex_node,compute_node in enumerate(G_execute1.nodes):
            G_execute1.nodes[compute_node]["compute_power"] = E[idex_node]
        # for idex_node, compute_node in enumerate(G_execute.nodes):
        #     print(G_execute.nodes[compute_node]["compute_power"])

        Multilayer_Network_List.append(G_execute1)
        G_execute1 = copy.deepcopy(G_execute_initial)

    #对物理链路的算力进行度量
    map_edge = []
    sfc_map_edge = []

    for edge in G_execute1.edges:
        map_edge = []
        if G_execute1.edges[edge]['bandwidth'] >= br:
            edge_uti = (G_initial.edges[edge]['bandwidth'] - G_execute1.edges[edge]['bandwidth'])/G_initial.edges[edge]['bandwidth']
            edge_remain = 1/(G_execute1.edges[edge]['bandwidth']+ϵ)
            edge_delay = G_execute1.edges[edge]['trans_d']
            map_edge.append(edge)
            map_edge.append([edge_uti, edge_remain, edge_delay])

        else:
            map_edge.append(edge)
            map_edge.append([1,1,G_execute1.edges[edge]['trans_d']])

        sfc_map_edge.append(map_edge)
    #print("sfc_map_edge:",sfc_map_edge)
    E1 = AHR_Computerpower(sfc_map_edge, 3)
    print("E1:", E1)
    #exit(0)
    for layer_network in Multilayer_Network_List:
        #print(type(layer_network))
        for idex, edge in enumerate(layer_network.edges):
            layer_network.edges[edge]['compute_power'] = E1[idex]
    #print("11111")
    #
    #用层次分析法对每条物理链路进行度量
    #并把度量值赋值给每一层的网络
    #print(Multilayer_Network_List)
    Multilayer_Network = nx.Graph()
    mapping = dict()
    #构建一个多层网络并返回，构建的多层网络要重新编号
    for idex_layer, layer_network in enumerate(Multilayer_Network_List):
        #print(type(layer_network))
        #print("layer_network_len:",len(layer_network.nodes))
        for node_num, layer_network_node in enumerate(layer_network.nodes):
            #print(layer_network.nodes[layer_network_node]['compute_power'])
            #print(layer_network.nodes[layer_network_node]['compute_power'])
            Multilayer_Network.add_node((idex_layer+1)*100+layer_network_node, cpu=layer_network.nodes[layer_network_node]['cpu'],memory=layer_network.nodes[layer_network_node]['memory'],
                                        storage=layer_network.nodes[layer_network_node]['storage'],process_d=layer_network.nodes[layer_network_node]['process_d'],
                                        domain = layer_network.nodes[layer_network_node]['domain'],software = layer_network.nodes[layer_network_node]['software'],
                                        cpu_cost = layer_network.nodes[layer_network_node]['cpu_cost'],mem_cost = layer_network.nodes[layer_network_node]['mem_cost'],
                                        sto_cost = layer_network.nodes[layer_network_node]['sto_cost'],compute_power = layer_network.nodes[layer_network_node]['compute_power'],
                                        penalty_factor = layer_network.nodes[layer_network_node]['penalty_factor'])
            # print(Multilayer_Network.nodes[(idex_layer+1)*100+layer_network_node])
        #print(Multilayer_Network.nodes)
        for edge_num, layer_network_edge in enumerate(layer_network.edges()):
            # print(layer_network_edge)
            # print(layer_network_edge[0])
            Multilayer_Network.add_edge((idex_layer+1) * 100 + layer_network_edge[0],
                                        (idex_layer+1) * 100 + layer_network_edge[1],
                                        bandwidth=layer_network.edges[layer_network_edge]['reci_bandwidth'],
                                        reci_bandwidth=layer_network.edges[layer_network_edge]['reci_bandwidth'],
                                        penalty_factor=layer_network.edges[layer_network_edge]['penalty_factor'],
                                        trans_d=layer_network.edges[layer_network_edge]['trans_d'],
                                        type=layer_network.edges[layer_network_edge]['type'],
                                        compute_power=layer_network.edges[layer_network_edge]['compute_power'])

        #print( Multilayer_Network.edges)


    print("Multilayer_Network.nodes:",Multilayer_Network.nodes)
    # print(Multilayer_Network.edges)
    # print(len(Multilayer_Network.edges))
    #构建多层网络中的链接
    for idex_layer, layer_network in enumerate(Multilayer_Network_List):

        if idex_layer < len(Multilayer_Network_List)-1:
            for item1, item2 in zip(layer_network.nodes, Multilayer_Network_List[idex_layer+1].nodes):
                Multilayer_Network.add_edge((idex_layer+1)*100+item1,
                                            (idex_layer+2)*100+item2,
                                            bandwidth=100000,
                                            reci_bandwidth=0,
                                            penalty_factor=0,
                                            trans_d=0,
                                            type=3,
                                            compute_power=0)
    # print(len(Multilayer_Network.edges))
    # print(Multilayer_Network.edges)
    # draw_graph(Multilayer_Network)

    return Multilayer_Network




    #返回一个多层的网络


    #在主程序中调用这个网络
    #初始节点已经在第一层中确定了

    #结束节点已经在最后一层中确定了

    #需要将每个VNF放置在每层的物理节点上，使从开始节点经过多层网络到最终节点的节点上的算力和链路上的算力和最小，并返回最终部署的节点和部署的链路，对节点和链路进行处理，更新网络资源，判断时延是否能够满足条件，满足就接收，不满足就不接受












#根据每一个VNF构建一层加权的网络
#将基于多个VNF构建的多个单层加权网络

#start节点和end节点分别放在第一层和最后一层








def DP_generate_alg(network, start_node, end_node, Layer_Node):
    #Multilayer_Network有72个节点，节点的标号分别为，101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324
    #Multilayer Network的物理链路随机生成
    #Multilayer Network的物理节点和物理链路有算力性能指标
    #strat_node和end_node是具体值，已经确定，分别表示Multilayer Network上对应的物理节点
    #Layer_Node是一个二维列表，[[101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124], [201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224], [301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324]]
    #需要从Layer_Node的每一维中选择一个物理节点，假设选择到的节点分别用n1,n2,n3表示，并选择从start_node到n1,n1到n2,n2到n3,n3到end_node的链路，使得最终选择的节点和链路的算力性能指标和最小

    # 定义起始和结束节点
    start_node = 100+start_node
    end_node = 300+end_node
    layer1_nodes = Layer_Node[0]
    layer2_nodes = Layer_Node[1]
    layer3_nodes = Layer_Node[2]
    # 初始化最小容量和对应的路径
    min_total_capacity = float('inf')
    optimal_path = None
    optimal_nodes = None

    # 遍历所有可能的节点组合
    for n1 in layer1_nodes:
        for n2 in layer2_nodes:
            for n3 in layer3_nodes:
                # 确保节点编号对 100 取余后的值不相等
                if len({n1 % 100, n2 % 100, n3 % 100}) == 3:
                    try:
                        # 计算路径
                        path_l1 = nx.shortest_path(network, start_node, n1, weight='compute_power')
                        path_l2 = nx.shortest_path(network, n1, n2, weight='compute_power')
                        path_l3 = nx.shortest_path(network, n2, n3, weight='compute_power')
                        path_l4 = nx.shortest_path(network, n3, end_node, weight='compute_power')

                        # 计算总容量
                        total_capacity = network.nodes[n1]['compute_power'] + network.nodes[n2]['compute_power'] + \
                                         network.nodes[n3]['compute_power']
                        total_capacity += sum(network[u][v]['compute_power'] for u, v in zip(path_l1, path_l1[1:]))
                        total_capacity += sum(network[u][v]['compute_power'] for u, v in zip(path_l2, path_l2[1:]))
                        total_capacity += sum(network[u][v]['compute_power'] for u, v in zip(path_l3, path_l3[1:]))
                        total_capacity += sum(network[u][v]['compute_power'] for u, v in zip(path_l4, path_l4[1:]))

                        # 更新最小容量和对应的路径
                        if total_capacity < min_total_capacity:
                            min_total_capacity = total_capacity
                            optimal_path = (path_l1, path_l2, path_l3, path_l4)
                            optimal_nodes = (n1, n2, n3)

                    except nx.NetworkXNoPath:
                       # 如果没有路径，则跳过此组合
                        continue
    Length = []
    for length in optimal_path:
        for item in length:
            Length.append(item)
    #print(Length)

    for i, item in enumerate(Length):
        Length[i] = item % 100

    #print(Length)

    # 对列表中的元素去重

    # 使用有序方法去重
    unique_list = [Length[0]]

    for i in range(1, len(Length)):
        if Length[i] != Length[i - 1]:
            unique_list.append(Length[i])

    deploy_node = []
    for node in optimal_nodes:
        deploy_node.append(node % 100)

    #print(deploy_node)
    #print(unique_list)

    return deploy_node, unique_list, min_total_capacity


def DP_generate_alg2(network, start_node, end_node, Layer_Node):
    #Multilayer_Network有72个节点，节点的标号分别为，101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324
    #Multilayer Network的物理链路随机生成
    #Multilayer Network的物理节点和物理链路有算力性能指标
    #strat_node和end_node是具体值，已经确定，分别表示Multilayer Network上对应的物理节点
    #Layer_Node是一个二维列表，[[101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124], [201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224], [301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324]]
    #需要从Layer_Node的每一维中选择一个物理节点，假设选择到的节点分别用n1,n2,n3表示，并选择从start_node到n1,n1到n2,n2到n3,n3到end_node的链路，使得最终选择的节点和链路的算力性能指标和最小

    # 定义起始和结束节点
    start_node = 100+start_node
    end_node = 200+end_node
    layer1_nodes = Layer_Node[0]
    layer2_nodes = Layer_Node[1]
    #layer3_nodes = Layer_Node[2]
    # 初始化最小容量和对应的路径
    min_total_capacity = float('inf')
    optimal_path = None
    optimal_nodes = None

    # 遍历所有可能的节点组合
    for n1 in layer1_nodes:
        for n2 in layer2_nodes:
            if len({n1 % 100, n2 % 100}) == 2:
                try:
                    # 计算路径
                    path_l1 = nx.shortest_path(network, start_node, n1, weight='compute_power')
                    path_l2 = nx.shortest_path(network, n1, n2, weight='compute_power')
                    path_l3 = nx.shortest_path(network, n2, end_node, weight='compute_power')


                    # 计算总容量
                    total_capacity = network.nodes[n1]['compute_power'] + network.nodes[n2]['compute_power']
                    total_capacity += sum(network[u][v]['compute_power'] for u, v in zip(path_l1, path_l1[1:]))
                    total_capacity += sum(network[u][v]['compute_power'] for u, v in zip(path_l2, path_l2[1:]))
                    total_capacity += sum(network[u][v]['compute_power'] for u, v in zip(path_l3, path_l3[1:]))


                    # 更新最小容量和对应的路径
                    if total_capacity < min_total_capacity:
                        min_total_capacity = total_capacity
                        optimal_path = (path_l1, path_l2, path_l3)
                        optimal_nodes = (n1, n2)

                except nx.NetworkXNoPath:
                   # 如果没有路径，则跳过此组合
                    continue
    Length = []
    for length in optimal_path:
        for item in length:
            Length.append(item)
    #print(Length)

    for i, item in enumerate(Length):
        Length[i] = item % 100

    #print(Length)

    # 对列表中的元素去重

    # 使用有序方法去重
    unique_list = [Length[0]]

    for i in range(1, len(Length)):
        if Length[i] != Length[i - 1]:
            unique_list.append(Length[i])

    deploy_node = []
    for node in optimal_nodes:
        deploy_node.append(node % 100)

    #print(deploy_node)
    #print(unique_list)

    return deploy_node, unique_list, min_total_capacity

def DP_generate_alg4(network, start_node, end_node, Layer_Node):
    #Multilayer_Network有72个节点，节点的标号分别为，101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324
    #Multilayer Network的物理链路随机生成
    #Multilayer Network的物理节点和物理链路有算力性能指标
    #strat_node和end_node是具体值，已经确定，分别表示Multilayer Network上对应的物理节点
    #Layer_Node是一个二维列表，[[101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124], [201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224], [301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324]]
    #需要从Layer_Node的每一维中选择一个物理节点，假设选择到的节点分别用n1,n2,n3表示，并选择从start_node到n1,n1到n2,n2到n3,n3到end_node的链路，使得最终选择的节点和链路的算力性能指标和最小

    # 定义起始和结束节点
    start_node = 100+start_node
    end_node = 300+end_node
    layer1_nodes = Layer_Node[0]
    layer2_nodes = Layer_Node[1]
    layer3_nodes = Layer_Node[2]
    #layer4_nodes = Layer_Node[3]
    #print("layer4_nodes:",layer4_nodes)
    # 初始化最小容量和对应的路径
    min_total_capacity = float('inf')
    optimal_path = None
    optimal_nodes = None
    print("optimal_nodes:",optimal_nodes)
    # 遍历所有可能的节点组合
    for n1 in layer1_nodes:
        for n2 in layer2_nodes:
            for n3 in layer3_nodes:
                    # 确保节点编号对 100 取余后的值不相等
                    if len({n1 % 100, n2 % 100, n3 % 100}) == 3:
                        try:
                            # 计算路径
                            path_l1 = nx.shortest_path(network, start_node, n1, weight='compute_power')
                            path_l2 = nx.shortest_path(network, n1, n2, weight='compute_power')
                            path_l3 = nx.shortest_path(network, n2, n3, weight='compute_power')
                            path_l4 = nx.shortest_path(network, n3, end_node, weight='compute_power')
                            #path_l5 = nx.shortest_path(network, n4, , weight='compute_power')

                            # 计算总容量
                            total_capacity = network.nodes[n1]['compute_power'] + network.nodes[n2]['compute_power'] + \
                                             network.nodes[n3]['compute_power']
                            total_capacity += sum(network[u][v]['compute_power'] for u, v in zip(path_l1, path_l1[1:]))
                            total_capacity += sum(network[u][v]['compute_power'] for u, v in zip(path_l2, path_l2[1:]))
                            total_capacity += sum(network[u][v]['compute_power'] for u, v in zip(path_l3, path_l3[1:]))
                            total_capacity += sum(network[u][v]['compute_power'] for u, v in zip(path_l4, path_l4[1:]))
                            #total_capacity += sum(network[u][v]['compute_power'] for u, v in zip(path_l5, path_l5[1:]))
                            #print("total_capacity:",total_capacity)
                            # 更新最小容量和对应的路径
                            if total_capacity < min_total_capacity:
                                min_total_capacity = total_capacity
                                optimal_path = (path_l1, path_l2, path_l3, path_l4)
                                optimal_nodes = (n1, n2, n3)

                        except nx.NetworkXNoPath:
                           # 如果没有路径，则跳过此组合
                            continue
    print("optimal_path:",optimal_path)
    #exit(1)
    Length = []
    for length in optimal_path:
        for item in length:
            Length.append(item)
    #print(Length)

    for i, item in enumerate(Length):
        Length[i] = item % 100

    #print(Length)

    # 对列表中的元素去重

    # 使用有序方法去重
    unique_list = [Length[0]]

    for i in range(1, len(Length)):
        if Length[i] != Length[i - 1]:
            unique_list.append(Length[i])

    deploy_node = []
    for node in optimal_nodes:
        deploy_node.append(node % 100)

    #print(deploy_node)
    #print(unique_list)

    return deploy_node, unique_list, min_total_capacity


def Generat_layer_node(Multilayer_Network, start, end, sfc_len):
    Layer_Node = []
    for item in range(sfc_len):
        Layer_Node.append([])
    for node in Multilayer_Network.nodes:
        #print(node)
        if math.floor(node/(100)) == 1:
            Layer_Node[0].append(node)
        elif math.floor(node/(100)) == 2:
            Layer_Node[1].append(node)
        elif math.floor(node/(100)) == 3:
            Layer_Node[2].append(node)
        else:Layer_Node[3].append(node)
    #print("Layer_Node:",Layer_Node)
    return Layer_Node









#打印当前网络的拓扑信息
def Get_Network_information(G):
    for node in G.nodes:
        print("node:", node, "cpu:",G.nodes[node]['cpu'], "memory:",G.nodes[node]['memory'], "storage:",G.nodes[node]['storage'], "software:",G.nodes[node]['software'], "process_d:",G.nodes[node]["process_d"], "domain:",G.nodes[node]["domain"])
    for edge in G.edges:
        print("edge:",edge,"bandwidth:",G.edges[edge]["bandwidth"],"trans_d:",G.edges[edge]["trans_d"])


# 示例数据
# data = {
#     'Name': ['John', 'Alice', 'Bob'],
#     'Age': [28, 22, 32],
#     'City': ['New York', 'San Francisco', 'Los Angeles']
# }
#将数据保存到execl文件中去
def Save_accept_data_to_execl(data, filename):
    df = pd.DataFrame(data)
    df.to_excel(filename,index=True)






#根据每个SFC构建剪裁图，并根据剪裁图构建一个多层网络



#层次分析法
#首先建立指标之间的矩阵
#根据所有的物理节点建立指标之前的矩阵
#根据所有链路建立指标之间的矩阵
#获得物理节点的度量值
#获得物理链路的度量值




#根据层次分析法获得多层加权网络


if __name__ == '__main__':
    np.random.seed(SEED)  # 随机种子设定，可以通过随机种子的设定来重复实验

    parser = argparse.ArgumentParser()
    parser.add_argument('--inputfile', type=str, nargs='?',
                        const=1,
                        default="D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Initialization/network_USA.gml")
    parser.add_argument('--outputfile', type=str, nargs='?',
                        const=1,
                        default=r'D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Initialization/network_USA.gpickle')
    args = parser.parse_args()  # 网络环境的链接
    if args.inputfile.endswith(".gml"):
        G = gml_reader(SEED, args.inputfile, args.outputfile)  # 生成网络拓扑
    else:
        pass

    # random_node, random_link = Random_find_suitable_node1(G, G, [['BandwidthShaper'], [38, 39, 46]],2,30)
    # print(random_node, random_link)
    #
    # greedy_node, greedy_link = Greedy_find_best_node1(G, G, [['BandwidthShaper'], [38, 39, 46]],2,30)
    # print(greedy_node, greedy_link)
    # Get_Network_information(G)

    # bestfit_node, bestfit_link = Bestfit_find_node1(G, G, [['BandwidthShaper'], [38, 39, 46]],2,30)
    # print(bestfit_node,bestfit_link)

    # SFCMAP_node, SFCMAP_link, SFCMAP_link1 = SFCMAP_find_node1(G, G, [['BandwidthShaper'], [38, 39, 46]], 2, 30)
    # print(SFCMAP_node, SFCMAP_link,SFCMAP_link1)

    Multilayer_Network = Genetate_Multilayer_Network(G, G, [[['BandwidthShaper'], [38, 39, 46]],[['IPFilter'], [30, 39, 20]]],40)
    draw_graph(Multilayer_Network)









