#贪心算法
#对于每个VNF，首先将它放置在上一个节点放置的位置，如果这个步骤失败了，根据物理节点的资源对所有的物理节点排序
#每个VNF的候选的贪心节点都不一样
#每个VNF的候选的贪心节点的排序步骤如下，计算每个VNF节点距离上一个VNF节点的放置位置的距离，距离用链路时延表示，并且存在链路上的带宽大于业务请求的带宽，否则，将时延定义为负数；这里的链路的选择的是两个物理节点之间满足带宽需求的最短的路径
#将每个物理节点的资源进行平均
#如果节点上有这个VNF的软件资源，则不用减去VNF-依赖的软件需要的存储资源，否则在这个节点上减去VNF-依赖的软件所需的存储资源
#先对CPU/时延进行降序排序，在此基础上对memory进行降序排序，在此基础上对storage进行降序排序
#去掉CPU/时延小于0的节点
#获得候选的VNF放置的物理节点

#获得业务功能链
#用来跑最终实验结果的脚本
#初始化业务功能链
#调用算法脚本
#记录数据
#画图
import numpy as np
from Multidomain_SFC_deployment.Initialization.Class_SFC import *
from Multidomain_SFC_deployment.Initialization.generate_network import *
from Multidomain_SFC_deployment.Initialization.Global import *
from Multidomain_SFC_deployment.Algorithm.utils import *
import argparse
import copy
import pandas as pd

np.random.seed(SEED)   #随机种子设定，可以通过随机种子的设定来重复实验

parser = argparse.ArgumentParser()
parser.add_argument('--inputfile', type=str, nargs='?',
                        const=1, default="D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Initialization/network_USA.gml")
parser.add_argument('--outputfile', type=str, nargs='?',
                        const=1,
                        default=r'D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Initialization/network_USA.gpickle')
args = parser.parse_args()  #网络环境的链接
if args.inputfile.endswith(".gml"):
    G_initial = gml_reader(SEED, args.inputfile, args.outputfile) #生成网络拓扑
else:
    pass

G_success = copy.deepcopy(G_initial) #深拷贝网络，使G_success用来表示上一次成功执行的业务功能链之后的网络的状态
G_execute = copy.deepcopy(G_success) #深拷贝网络，使用G_execute表示当前用来执行的网络的状态


poisson_samples = np.random.poisson(lam=λ, size=SLOT_NUM_L)     #获得每个时隙中的业务功能链的数量，可以通过改变业务功能链到达的速率来重复实验

#需要将所有请求的业务功能链保存到一个文档中去
Request_total_SFCs = []  #用来保存所有请求的SFC的列表
Accept_SFCs = [] #用来保存所有被成功接收的SFC的列表
Reject_SFCs = [] #用来保存所有被拒绝的SFC的列表

#获得所有VNF需要的信息
cpu = [R_C_L, R_C_H]
mem = [R_M_L, R_M_H]
All_Vnfs_Info = Get_VNFs_INFO(cpu, mem, R_S_L, R_S_H)
#print(All_Vnfs_Info)

for t in range(SLOT_NUM_L):
    sfc_t_nums = poisson_samples[t] #获得当前时隙中的需要部署的业务功能链的数量
    SFCs_Info = Generate_SFCs_Info(args.inputfile, sfc_t_nums) #获得当前时隙中的业务功能链的信息

    print("****************time slot****************",t)

    # 依次部署业务功能链，记录业务功能链部署时的时延，部署的成本，迁移的成本，迁移的次数
    for sfc_num,sfc in enumerate(SFCs_Info): #这个循环中部署请求的业务功能链
        print("##########sfc", sfc_num)
        FLAG = True #业务可以被成功部署
        sfc.arrival = t #给定业务到达的时间
        Request_total_SFCs.append(sfc.return_list()) #添加新到达的SFC
        #print(Request_total_SFCs)

        start = sfc.start_point
        end = sfc.end_point

        b_r = sfc.bandwidth_demand  #业务功能链的带宽请求
        d_r = sfc.latency_demand    #业务功能链的时延需求
        VNF_List = sfc.vnf_list #获取业务功能链每个VNF需要的信息

        # print("开始节点：", start," ","结束节点：", end," ", "带宽请求：", b_r," ", "时延请求：",d_r)
        #print("请求的VNFs：", VNF_List)
        VNF_List_info = []
        #获得请求的VNF_List的信息
        for idex, vnf in enumerate(VNF_List):
            vnf_request = All_Vnfs_Info[vnf]
            VNF_List_info.append(vnf_request)
        #print("VNF_List_info:",VNF_List_info)
        #获得VNFlist需要的团建，VNF_List_Software_info是这些软件的集合
        VNF_List_Software_info = []
        for item in VNF_List_info:
            VNF_List_Software_info.append(item[0][0])
        #print("VNF_List_Software_info:",VNF_List_Software_info)


        Multilayer_Network = Generate_Multilayer_Network_NOAHR(G_initial, G_execute, VNF_List_info,b_r)
        #draw_graph(Multilayer_Network)
        #给定一个网络，逻辑上是多层图网络，实际上是一个网络，用节点编号除以100，向下取整获得网络的编号，通过编号来区分网络的层数，以及每个物理节点所在的层，网络中的每个节点和每条链路都有算力指标，每个对应的VNF只能放置在对应的层节点上，
        # 比如第一个VNF只能放置在第一层的任意一个节点上，第二个VNF只能放置在第二层的任意节点上，第三个VNF只能放置在第三层的任意节点上，源节点和目的节点分别放在第一层和最后一层，已经确定了源节点和目的节点的位置，目的是找到VNF在多层网络中的放置位置，
        # 以及VNF通信使用的物理链路，使从源节点到目的节点的VNF放置的节点和链路的位置最小，返回VNF放置的节点和使用的物理链路
        #给定一个网络，逻辑上是多层图网络，实际上是一个网络，用节点编号除以100，向下取整获得网络的编号，
        # 通过编号来区分网络的层数，以及每个物理节点所在的层，网络中的每个节点和每条链路都有算力指标，
        # 每个对应的VNF只能放置在对应的层节点上，比如第一个VNF只能放置在第一层的任意一个节点上，第二个VNF只能放置在第二层的任意节点上，
        # 第三个VNF只能放置在第三层的任意节点上，源节点和目的节点分别放在第一层和最后一层，已经确定了源节点和目的节点的位置，目的是找到VNF在多层网络中的放置位置，
        # 以及VNF通信使用的物理链路，使从源节点到目的节点的VNF放置的节点和链路的位置最小，返回VNF放置的节点和使用的物理链路
        # 给定一个网络，逻辑上是多层图网络，实际上是一个网络，用节点编号除以100，向下取整获得网络的编号
        #网络中的每个节点和每条链路都有算力指标
        #每个对应的VNF只能放置在对应的层节点上，比如第一个VNF只能放置在第一层的任意一个节点上，第二个VNF只能放置在第二层的任意节点上，第三个VNF只能放置在第三层的任意节点上

        #源节点和目的节点分别放在第一层和最后一层，已经确定了源节点和目的节点的位置
        #目的是找到VNF在多层网络中的放置位置，以及VNF通信使用的物理链路，使从源节点到目的节点的VNF放置的节点和链路的位置最小，返回VNF放置的节点和使用的物理链路

        #给定一个网络，网络中的节点和链路都具有算力属性，网络中的节点有三种类型，分别为type1, type2, type3, 在第一种类型的网络节点中找一个物理节点作为开始节点n1，在第三种类型的网络节点中找一个物理节点作为结束节点n3
        #此外，在每种类型的网络节点中分别找出一个物理节点，分别为n11, n21, n31, 在n1和n11,n11和n21,n21和n31,n31和n3之间找到通信的简单物理路径，使选中的物理节点上和选中的物理链路上的算力和最小
        #
        Layer_Node = Generat_layer_node(Multilayer_Network, start, end, SFC_LEN_L)
        deploy_node, unique_list, min_total_capacity = DP_generate_alg(Multilayer_Network, start, end, Layer_Node)
        print("deploy_node：",deploy_node)
        print("unique_list：",unique_list)
        print("min_total_capacity：",min_total_capacity)

        for num_vnf, place_node in enumerate(deploy_node):
            #添加节点资源并更新节点资源
            #print("VNF_List_Software_info[num_vnf]:",VNF_List_Software_info[num_vnf])
            if VNF_List_Software_info[num_vnf] in G_execute.nodes[place_node]['software']:
                #print("VNF_List_Software_info[num_vnf]:", VNF_List_Software_info[num_vnf])
                #print("G_execute.nodes[place_node]['software']:",G_execute.nodes[place_node]['software'])
                #exit(1)
                if G_execute.nodes[place_node]['cpu'] >= VNF_List_info[num_vnf][1][0] and G_execute.nodes[place_node]['memory'] >= VNF_List_info[num_vnf][1][1]:
                    sfc.deploy_nodes.append(place_node)
                    sfc.deploy_nodes_delay.append(G_execute.nodes[place_node]['process_d'])
                    # 计算cpu的利用率
                    cpu_uti = (G_initial.nodes[place_node]['cpu'] - G_execute.nodes[place_node]['cpu']) / G_initial.nodes[place_node][
                        'cpu']
                    mem_uti = (G_initial.nodes[place_node]['memory'] - G_execute.nodes[place_node]['memory']) / \
                              G_initial.nodes[place_node]['memory']
                    sto_uti = (G_initial.nodes[place_node]['storage'] - G_execute.nodes[place_node]['storage']) / \
                              G_initial.nodes[place_node]['storage']

                    # 计算cpu资源使用成本
                    if cpu_uti <= 0.2:
                        cpu_cost = VNF_List_info[num_vnf][1][0] * 1
                    elif 0.2 < cpu_uti <= 0.8:
                        cpu_cost = VNF_List_info[num_vnf][1][0] * ((10.0 / 3) * cpu_uti + 1.0 / 3)
                    else:
                        cpu_cost = VNF_List_info[num_vnf][1][0] * 3

                    # 计算mem资源使用成本
                    if mem_uti <= 0.2:
                        mem_cost = VNF_List_info[num_vnf][1][1] * 1
                    elif 0.2 < mem_uti <= 0.8:
                        mem_cost = VNF_List_info[num_vnf][1][1] * ((10.0 / 3) * mem_uti + 1.0 / 3)
                    else:
                        mem_cost = VNF_List_info[num_vnf][1][1] * 3
                    sfc.deploy_nodes_cost.append((cpu_cost+mem_cost+0)/2.0)
                    sfc.deploy_nodes_sto_cost.append(0)
                    sfc.migrate_nodes.append(0)
                    sfc.migrate_cost.append(0)


                    #更新网络资源
                    G_execute.nodes[place_node]['cpu'] = G_execute.nodes[place_node]['cpu'] - VNF_List_info[num_vnf][1][0]
                    G_execute.nodes[place_node]['memory'] = G_execute.nodes[place_node]['memory'] - VNF_List_info[num_vnf][1][1]
                else:
                    FLAG = False
                    break

            else:
                #获得迁移的节点和迁移的成本
                #print(VNF_List_info)
                if G_execute.nodes[place_node]['cpu'] >= VNF_List_info[num_vnf][1][0] and G_execute.nodes[place_node]['memory'] >= VNF_List_info[num_vnf][1][1] and \
                        G_execute.nodes[place_node]['storage'] >= VNF_List_info[num_vnf][1][2]:
                    # 如果满足需求则将最近的软件迁移到该节点上来，计算迁移成本
                    cpu_uti = (G_initial.nodes[place_node]['cpu'] - G_execute.nodes[place_node]['cpu']) / G_initial.nodes[place_node][
                        'cpu']
                    mem_uti = (G_initial.nodes[place_node]['memory'] - G_execute.nodes[place_node]['memory']) / \
                              G_initial.nodes[place_node]['memory']
                    sto_uti = (G_initial.nodes[place_node]['storage'] - G_execute.nodes[place_node]['storage']) / \
                              G_initial.nodes[place_node]['storage']
                    # 计算cpu资源使用成本
                    if cpu_uti <= 0.2:
                        cpu_cost = VNF_List_info[num_vnf][1][0] * 1
                    elif 0.2 < cpu_uti <= 0.8:
                        cpu_cost = VNF_List_info[num_vnf][1][0] * ((10.0 / 3) * cpu_uti + 1.0 / 3)
                    else:
                        cpu_cost = VNF_List_info[num_vnf][1][0] * 3

                    # 计算mem资源使用成本
                    if mem_uti <= 0.2:
                        mem_cost = VNF_List_info[num_vnf][1][1] * 1
                    elif 0.2 < mem_uti <= 0.8:
                        mem_cost = VNF_List_info[num_vnf][1][1] * ((10.0 / 3) * mem_uti + 1.0 / 3)
                    else:
                        mem_cost = VNF_List_info[num_vnf][1][1] * 3

                    if sto_uti <= 0.2:
                        sto_cost = VNF_List_info[num_vnf][1][2] * 1
                    elif 0.2 < sto_uti <= 0.8:
                        sto_cost = VNF_List_info[num_vnf][1][2] * ((10.0 / 3) * sto_uti + 1.0 / 3)
                    else:
                        sto_cost = VNF_List_info[num_vnf][1][2] * 3

                    vnf_software_nodes = Get_Network_Nodes(G_execute, VNF_List_Software_info[num_vnf])
                    vnf_software_migrate_delay = Get_Shortest_delay(G_execute, vnf_software_nodes[0], place_node)
                    vnf_software_migrate_from_node = vnf_software_nodes[0]

                    # 计算从vnf_software_nodes到现在节点的最短距离，并返回最短距离对用的成本
                    for vnf_software_node in vnf_software_nodes:
                        if Get_Shortest_delay(G_execute, vnf_software_node, place_node) <= vnf_software_migrate_delay:
                            vnf_software_migrate_delay = Get_Shortest_delay(G_execute, vnf_software_node, place_node)
                            vnf_software_migrate_from_node = vnf_software_node
                    sfc.deploy_nodes.append(place_node)
                    sfc.deploy_nodes_delay.append(G_execute.nodes[place_node]['process_d'])
                    sfc.migrate_nodes.append(vnf_software_migrate_from_node)
                    sfc.migrate_cost.append(vnf_software_migrate_delay)
                    sfc.deploy_nodes_cost.append((cpu_cost+mem_cost)/2.0)
                    sfc.deploy_nodes_sto_cost.append(sto_cost)


                    #更新网络资源
                    G_execute.nodes[place_node]['cpu'] = G_execute.nodes[place_node]['cpu'] - VNF_List_info[num_vnf][1][0]
                    G_execute.nodes[place_node]['memory'] = G_execute.nodes[place_node]['memory'] - VNF_List_info[num_vnf][1][1]
                    G_execute.nodes[place_node]['storage'] = G_execute.nodes[place_node]['storage'] - VNF_List_info[num_vnf][1][2]
                    G_execute.nodes[place_node]['software'].append(VNF_List_Software_info[num_vnf])
                else:
                    FLAG = False
                    break

        zero_count = sfc.migrate_nodes.count(0)
        sfc.migrate_total_number = len(sfc.migrate_nodes) - zero_count

        #添加边资源并更新边的资源
        sfc.deploy_edges = unique_list
        for link_index in range(len(unique_list)-1):
            if G_execute.edges[(unique_list[link_index],unique_list[link_index+1])]['bandwidth'] >= b_r:
                sfc.deploy_edges_delay.append(G_execute.edges[(unique_list[link_index],unique_list[link_index+1])]['trans_d'])
                #更新链路资源
                G_execute.edges[(unique_list[link_index], unique_list[link_index + 1])]['bandwidth'] -= b_r
            else:
                FLAG = False
                break
        #Get_Network_information(G_execute)
        #
        if FLAG:
            #计算sfc的时延
            print(1111111111)
            sfc_total_delay = 0
            vnf_process_delay = 0
            link_commu_delay = 0
            for idex, place_node in enumerate(sfc.deploy_nodes):
                # sfc.deploy_nodes_delay.append(G_execute.nodes[sfc.deploy_nodes[idex]]['process_d'])
                # vnf_process_delay += G_execute.nodes[sfc.deploy_nodes[idex]]['process_d']
                vnf_process_delay += sfc.deploy_nodes_delay[idex]
            #print("sfc.deploy_edges:", sfc.deploy_edges)
            link_commu_delay = 0
            for link_index in range(len(sfc.deploy_edges)-1):
                link_commu_delay +=  G_execute.edges[(sfc.deploy_edges[link_index], sfc.deploy_edges[link_index+1])][
                        'trans_d']
            sfc_total_delay = vnf_process_delay + link_commu_delay
            sfc.deploy_total_delay = sfc_total_delay
            sfc.deploy_total_link_delay = link_commu_delay
            sfc.deploy_total_vnf_delay = vnf_process_delay

            # print("vnf_process_delay:", vnf_process_delay)
            # print("link_commu_delay:", link_commu_delay)
            # print("sfc_total_delay:", sfc_total_delay)
            # print("sfc.deploy_nodes_delay", sfc.deploy_nodes_delay)
            # print("sfc.deploy_edges_delay", sfc.deploy_edges_delay)

            # 当时延不满足需求时，则不计算成本，将SFC保存到被拒绝的队列中去，更新G_execute
            if sfc_total_delay < d_r:
                Accept_SFCs.append(sfc)  # 将sfc添加到被接收的集合中去
                G_success = copy.deepcopy(G_execute)

                total_cost = 0
                deploy_total_cost = 0
                migrate_total_cost = 0
                sto_total_cost = 0
                # 计算部署的成本
                for idex in range(len(sfc.deploy_nodes_cost)):
                    deploy_total_cost += sfc.deploy_nodes_cost[idex]
                    migrate_total_cost += sfc.migrate_cost[idex]
                    sto_total_cost += sfc.deploy_nodes_sto_cost[idex]
                total_cost = deploy_total_cost + migrate_total_cost
                sfc.deploy_total_cost = deploy_total_cost
                sfc.migrate_total_cost = migrate_total_cost
                sfc.deploy_sto_cost = sto_total_cost


                zero_count = sfc.migrate_nodes.count(0)
                sfc.migrate_total_number = len(sfc.migrate_nodes) - zero_count
            else:
                Reject_SFCs.append(sfc)
                G_execute = copy.deepcopy(G_success)
        else:
            Reject_SFCs.append(sfc)
            G_execute = copy.deepcopy(G_success)

#保存所有的被接收的业务功能链的信息
print("所有请求的业务功能链的数量：",len(Request_total_SFCs))
print("被拒绝的业务功能链的数量：",len(Reject_SFCs))
#计算被接收的业务功能链的数量，以及业务功能链的各项指标
print("被接收的业务功能链的数量：",len(Accept_SFCs))

# for sfc in Reject_SFCs:
#     print(sfc.latency_demand)
#     print(sfc.deploy_total_delay)
# for sfc in Reject_SFCs:
#     print("sfc.start_point:",sfc.start_point)
#     print("sfc.end_point",sfc.end_point)

#Get_Network_information(G_execute)

#将被接受的业务功能链的信息保存到以Geedy_lambda_seed_lensfc的.xlsx文件中去
# 使用字符串格式化构建文件名
Accept_SFCs_data = {}
Accept_SFCs_data["到达时间"] = []
Accept_SFCs_data["起点"] = []
Accept_SFCs_data["终点"] = []
Accept_SFCs_data["带宽需求"] = []
Accept_SFCs_data["时延需求"] = []
Accept_SFCs_data["生命周期"] = []
Accept_SFCs_data["VNFs列表"] = []

Accept_SFCs_data["部署的节点的位置"] = []
Accept_SFCs_data["部署的链路的位置"] = []
Accept_SFCs_data["软件从哪里迁移过来"] = []

Accept_SFCs_data["每个VNF放置的时延"] = []
Accept_SFCs_data["相邻VNF间的链路时延"] = []
Accept_SFCs_data["每个VNF放置后的资源使用成本"] = []
Accept_SFCs_data["每个VNF放置后使用的storage成本"] = []
Accept_SFCs_data["每个VNF放置后的迁移的软件的成本"] = []

Accept_SFCs_data["部署的总通信时延，包含链路时延和处理时延"] = []
Accept_SFCs_data["部署的VNF总时延，包含处理时延"] = []
Accept_SFCs_data["部署的link链路总时延，包含传输时延"] = []
Accept_SFCs_data["部署的总通信成本，包括节点资源使用成本"] = []
Accept_SFCs_data["部署后的总资源使用成本"] = []
Accept_SFCs_data["每个VNF放置后所需要的软件的迁移成本总和"] = []
Accept_SFCs_data["每个VNF放置后所需要迁移的软件的次数"] = []

accept_file_name = f'D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Evaluation_data/NEWALO_NOAHR/NEWALO_NOAHR_accept_{λ}_{SEED}_{SFC_LEN_L}.xlsx'

for sfc in Accept_SFCs:
    Accept_SFCs_data["到达时间"].append(sfc.arrival)
    Accept_SFCs_data["起点"].append(sfc.start_point)
    Accept_SFCs_data["终点"].append(sfc.end_point)
    Accept_SFCs_data["带宽需求"].append(sfc.bandwidth_demand)
    Accept_SFCs_data["时延需求"].append(sfc.latency_demand)
    Accept_SFCs_data["生命周期"].append(sfc.lifecycle)
    Accept_SFCs_data["VNFs列表"].append(sfc.vnf_list)

    Accept_SFCs_data["部署的节点的位置"].append(sfc.deploy_nodes)
    Accept_SFCs_data["部署的链路的位置"].append(sfc.deploy_edges)
    Accept_SFCs_data["软件从哪里迁移过来"].append(sfc.migrate_nodes)

    Accept_SFCs_data["每个VNF放置的时延"].append(sfc.deploy_nodes_delay)
    Accept_SFCs_data["相邻VNF间的链路时延"].append(sfc.deploy_edges_delay)
    Accept_SFCs_data["每个VNF放置后的资源使用成本"].append(sfc.deploy_nodes_cost)
    Accept_SFCs_data["每个VNF放置后使用的storage成本"].append(sfc.deploy_nodes_sto_cost)

    Accept_SFCs_data["每个VNF放置后的迁移的软件的成本"].append(sfc.migrate_cost)

    Accept_SFCs_data["部署的总通信时延，包含链路时延和处理时延"].append(sfc.deploy_total_delay)
    Accept_SFCs_data["部署的VNF总时延，包含处理时延"].append(sfc.deploy_total_vnf_delay)
    Accept_SFCs_data["部署的link链路总时延，包含传输时延"].append(sfc.deploy_total_link_delay)
    Accept_SFCs_data["部署的总通信成本，包括节点资源使用成本"].append(sfc.deploy_total_cost)
    Accept_SFCs_data["部署后的总资源使用成本"].append(sfc.deploy_sto_cost)
    Accept_SFCs_data["每个VNF放置后所需要的软件的迁移成本总和"].append(sfc.migrate_total_cost)
    Accept_SFCs_data["每个VNF放置后所需要迁移的软件的次数"].append(sfc.migrate_total_number)

Save_accept_data_to_execl(Accept_SFCs_data, accept_file_name)

network_status_filename = f'D:/zyh/PycharmProjects/pythonProject/SFC_Deployment/Multidomain_SFC_deployment/Evaluation_data/NEWALO_NOAHR/Network_status_NEWALO_AHR_{λ}_{SEED}_{SFC_LEN_L}.xlsx'
Network_status_data = {}

Network_status_data["节点"] = []
Network_status_data["cpu"] = []
Network_status_data["memory"] = []
Network_status_data["storage"] = []
Network_status_data["cpu_uti"] = []
Network_status_data["memory_uti"] = []
Network_status_data["storage_uti"] = []
Network_status_data["domain"] = []

for node in G_execute.nodes:
    Network_status_data["节点"].append(node)
    Network_status_data["cpu"].append(G_initial.nodes[node]['cpu']-G_execute.nodes[node]['cpu'])
    Network_status_data["memory"].append(G_initial.nodes[node]['memory']-G_execute.nodes[node]['memory'])
    Network_status_data["storage"].append(G_initial.nodes[node]['storage']-G_execute.nodes[node]['storage'])
    Network_status_data["cpu_uti"].append((G_initial.nodes[node]['cpu']-G_execute.nodes[node]['cpu'])*1.0/G_initial.nodes[node]['cpu'])
    Network_status_data["memory_uti"].append((G_initial.nodes[node]['memory']-G_execute.nodes[node]['memory'])*1.0/G_initial.nodes[node]['memory'])
    Network_status_data["storage_uti"].append((G_initial.nodes[node]['storage']-G_execute.nodes[node]['storage'])*1.0/G_initial.nodes[node]['storage'])
    Network_status_data["domain"].append(G_execute.nodes[node]['domain'])


Save_accept_data_to_execl(Network_status_data, network_status_filename)























